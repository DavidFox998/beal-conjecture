// Lean compiler output
// Module: ProofWidgets.Data.Html
// Imports: Init Lean.Data.Json.FromToJson Lean.Parser Lean.PrettyPrinter.Delaborator.Basic Lean.Server.Rpc.Basic ProofWidgets.Component.Basic ProofWidgets.Util
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
LEAN_EXPORT lean_object* l_Lean_Parser_Category_jsxChild;
lean_object* l_Lean_PrettyPrinter_Delaborator_annotateTermLikeInfo___rarg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_string_utf8_extract(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__3(lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__1___closed__2;
static lean_object* l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__1;
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
static lean_object* l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__5;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlOfComponent(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxChild__;
static lean_object* l_ProofWidgets_Jsx_jsxText___closed__3;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxAttr_quot;
static lean_object* l_ProofWidgets_Jsx_delabJsxChildren___lambda__5___closed__3;
static lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__8;
lean_object* l_Lean_Macro_throwErrorAt___rarg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabJsxChildren___lambda__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
uint32_t lean_string_utf8_get(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml___closed__1;
static lean_object* l_ProofWidgets_Jsx_jsxElement_quot___closed__3;
static lean_object* l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__9;
lean_object* lean_mk_empty_array_with_capacity(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxChild____1;
static lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__5___closed__2;
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__4;
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__9___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__3;
static lean_object* l_ProofWidgets_Jsx_jsxText___lambda__1___closed__3;
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___lambda__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_____closed__4;
lean_object* l___private_Lean_Expr_0__Lean_Expr_getAppNumArgsAux(lean_object*, lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__7;
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__13;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_transformTag___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__2;
lean_object* l_Lean_Json_mkObj(lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__3;
static lean_object* l_ProofWidgets_Jsx_transformTag___lambda__2___closed__5;
static lean_object* l_ProofWidgets_Jsx_jsxText___closed__4;
LEAN_EXPORT uint8_t l_String_anyAux___at_ProofWidgets_Jsx_delabHtmlText___spec__1(lean_object*, lean_object*, lean_object*);
lean_object* lean_string_utf8_get_opt(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__3___closed__4;
static lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__16;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__6___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_getExpr___at_Lean_PrettyPrinter_Delaborator_getExprKind___spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_getPos___at_Lean_PrettyPrinter_Delaborator_getOptionsAtCurrPos___spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189_(lean_object*);
static lean_object* l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__1;
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__2;
static lean_object* l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml___closed__3;
static lean_object* l_ProofWidgets_Jsx_jsxElement_quot___closed__7;
static lean_object* l_ProofWidgets_Jsx_jsxElement_quot___closed__15;
static lean_object* l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__1;
uint8_t l_Lean_Exception_isInterrupt(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____boxed(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__9;
uint64_t lean_uint64_of_nat(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxChild_x7b___x7d;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__4(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml;
static lean_object* l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__3___closed__3;
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__7___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxElement_quot___closed__9;
static lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__11;
static lean_object* l_ProofWidgets_Jsx_jsxAttr_quot___closed__7;
static lean_object* l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__7;
static lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__17;
static lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__12;
static lean_object* l_ProofWidgets_Jsx_delabHtmlText___lambda__1___closed__1;
uint8_t l_Lean_Expr_isApp(lean_object*);
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Name_toString(lean_object*, uint8_t);
static lean_object* l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__8;
static lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__1;
lean_object* l_not___boxed(lean_object*);
lean_object* l_Lean_Syntax_getId(lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__10;
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__7;
static lean_object* l_ProofWidgets_Jsx_transformTag___lambda__3___closed__6;
lean_object* l_Lean_Expr_sort___override(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabJsxChildren___lambda__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instInhabitedHtml___closed__2;
lean_object* lean_array_push(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__3;
LEAN_EXPORT lean_object* l_ProofWidgets_ProofWidgets_Html_instFromJsonRpcEncodablePacket;
LEAN_EXPORT lean_object* l_ProofWidgets_LayoutKind_noConfusion___rarg(uint8_t, uint8_t, lean_object*);
static lean_object* l_ProofWidgets_Jsx_term_____closed__1;
lean_object* lean_mk_array(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2;
uint8_t lean_usize_dec_eq(size_t, size_t);
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___at_ProofWidgets_Jsx_transformTag___spec__2(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Syntax_getArgs(lean_object*);
lean_object* lean_array_fget(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxText___closed__2;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_getJsxText___boxed(lean_object*);
static lean_object* l_ProofWidgets_Jsx_transformTag___lambda__3___closed__12;
static lean_object* l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__4;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabJsxChildren___lambda__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_getExpr___at_Lean_PrettyPrinter_Delaborator_getExprKind___spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____lambda__1(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__1___closed__1;
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5____spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__3;
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__6;
static lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__14;
static lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__7;
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__4___boxed(lean_object*, lean_object*, lean_object*);
uint64_t lean_string_hash(lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxElement_quot___closed__8;
static lean_object* l_ProofWidgets_LayoutKind_noConfusion___rarg___closed__1;
static lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__4;
static lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__4;
extern lean_object* l_Lean_instInhabitedJson;
uint8_t l_Lean_Syntax_isOfKind(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_____closed__1;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabJsxChildren___lambda__4(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Expr_cleanupAnnotations(lean_object*);
static lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___closed__1;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabJsxChildren___lambda__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1(size_t, size_t, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__5;
static lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__3;
static lean_object* l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_toJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_457____closed__1;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxElement_quot;
uint8_t lean_string_dec_eq(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__6;
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
static lean_object* l_ProofWidgets_Jsx_transformTag___lambda__2___closed__3;
static lean_object* l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__3___closed__2;
static lean_object* l_ProofWidgets_Jsx_jsxAttr_quot___closed__9;
static lean_object* l_ProofWidgets_instInhabitedHtml___closed__1;
static lean_object* l_ProofWidgets_Jsx_delabHtmlText___closed__1;
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__7___boxed(lean_object*, lean_object*, lean_object*);
lean_object* lean_string_utf8_byte_size(lean_object*);
lean_object* l_Lean_Expr_appArg_x21(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_instInhabitedHtml;
static lean_object* l_ProofWidgets_Jsx_jsxChild_quot___closed__10;
LEAN_EXPORT lean_object* l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__3___boxed(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__6;
lean_object* l_Lean_PrettyPrinter_Delaborator_withAnnotateTermLikeInfo___rarg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_____closed__7;
LEAN_EXPORT lean_object* l_ProofWidgets_LayoutKind_noConfusion___rarg___boxed(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttr_quot___closed__5;
static lean_object* l_ProofWidgets_Jsx_jsxText___lambda__1___closed__2;
LEAN_EXPORT lean_object* l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_toJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_457_(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_MonadExcept_ofExcept___at_Lean_Widget_Lean_Widget_WidgetInstance_instRpcEncodableWidgetInstance_dec____x40_Lean_Widget_Types___hyg_3____spec__1(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_instInhabitedHtml___closed__3;
static lean_object* l_ProofWidgets_Jsx_delabJsxChildren___lambda__5___closed__1;
static lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__5;
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Json_getStr_x3f(lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxElement_quot___closed__18;
LEAN_EXPORT lean_object* l_Array_sequenceMap___at_ProofWidgets_Jsx___aux__ProofWidgets__Data__Html______macroRules__ProofWidgets__Jsx__term____1___spec__1(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__10;
lean_object* l_Lean_Name_mkStr3(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_Parser_Category_jsxAttr;
static lean_object* l_ProofWidgets_Jsx_jsxChild_____closed__3;
static lean_object* l_ProofWidgets_Jsx_transformTag___lambda__3___closed__13;
static lean_object* l_ProofWidgets_Jsx_jsxChild_x7b___x7d___closed__2;
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__12;
static lean_object* l_ProofWidgets_Jsx_transformTag___closed__1;
static lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__3;
LEAN_EXPORT lean_object* l_ProofWidgets_LayoutKind_noConfusion(lean_object*);
size_t lean_usize_of_nat(lean_object*);
static lean_object* l_ProofWidgets_Jsx_transformTag___lambda__3___closed__10;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_transformTag___lambda__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent(lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxElement_quot___closed__4;
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___at_ProofWidgets_Jsx_transformTag___spec__6___lambda__1(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__3;
static lean_object* l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__2;
LEAN_EXPORT lean_object* l_Array_filterMapM___at_ProofWidgets_Jsx_transformTag___spec__8___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__3___closed__1;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlText___lambda__3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_transformTag___lambda__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxText___closed__5;
static lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__4;
uint8_t l_instDecidableNot___rarg(uint8_t);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlText___lambda__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__5___closed__3;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d;
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_____closed__3;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__5;
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* lean_string_utf8_next(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___at_ProofWidgets_Jsx_transformTag___spec__6(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Array_zip___rarg(lean_object*, lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__19;
static lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__1;
static lean_object* l_ProofWidgets_Jsx_transformTag___lambda__3___closed__2;
static lean_object* l_ProofWidgets_Jsx_jsxElement_quot___closed__19;
lean_object* l_Lean_SourceInfo_fromRef(lean_object*, uint8_t);
uint8_t lean_uint32_dec_le(uint32_t, uint32_t);
static lean_object* l_ProofWidgets_Jsx_jsxAttr_quot___closed__8;
lean_object* l_Lean_Syntax_node6(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__6;
static lean_object* l_ProofWidgets_Jsx_transformTag___lambda__3___closed__5;
lean_object* l_Lean_Syntax_getAtomVal(lean_object*);
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_____closed__8;
lean_object* l_Array_mapMUnsafe_map___at___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_fromJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1645____spec__2(size_t, size_t, lean_object*);
static lean_object* l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__1___closed__1;
static lean_object* l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__7;
static lean_object* l_ProofWidgets_Jsx_jsxAttr_quot___closed__4;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_transformTag___lambda__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__8;
LEAN_EXPORT lean_object* l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5_(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_LayoutKind_toCtorIdx(uint8_t);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_ProofWidgets_Html_instFromJsonRpcEncodablePacket___closed__1;
static lean_object* l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__7;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Syntax_mkStrLit(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__13;
static lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__3___closed__2;
static lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__5;
static lean_object* l_ProofWidgets_Jsx_jsxElement_quot___closed__11;
static lean_object* l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__3___closed__3;
LEAN_EXPORT lean_object* l_Array_sequenceMap___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__2___boxed(lean_object*, lean_object*);
lean_object* l_Lean_PrettyPrinter_Parenthesizer_visitToken___rarg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__6(lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_transformTag(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_sequenceMap_loop___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxElement_quot___closed__1;
static lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__1___closed__1;
static lean_object* l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__6;
lean_object* lean_uint64_to_nat(uint64_t);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__4(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabJsxChildren___lambda__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxText_parenthesizer(lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxChild_____closed__2;
lean_object* l_Lean_Expr_appArg(lean_object*, lean_object*);
lean_object* l_Lean_PrettyPrinter_Formatter_visitAtom(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__14;
lean_object* l_outOfBounds___rarg(lean_object*);
static lean_object* l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____closed__1;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d;
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__3;
static lean_object* l_ProofWidgets_Jsx___aux__ProofWidgets__Data__Html______macroRules__ProofWidgets__Jsx__term____1___closed__1;
static lean_object* l_ProofWidgets_Jsx_jsxChild_____closed__4;
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__15;
LEAN_EXPORT lean_object* l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5_(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxElement_quot___closed__16;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlText(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__9;
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__1;
static lean_object* l_ProofWidgets_Jsx_transformTag___lambda__3___closed__11;
lean_object* l_Lean_Expr_appFnCleanup(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_object* l_Lean_Syntax_node3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_PrettyPrinter_Delaborator_delab(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_toJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_457____closed__2;
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___elambda__1___rarg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_getJsxText(lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__1;
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5____spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__8;
LEAN_EXPORT lean_object* l_Array_sequenceMap_loop___at_ProofWidgets_Jsx___aux__ProofWidgets__Data__Html______macroRules__ProofWidgets__Jsx__term____1___spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_delabJsxChildren___closed__2;
static lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__18;
static lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__11;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_transformTag___lambda__1(lean_object*, size_t, lean_object*, lean_object*, lean_object*, lean_object*);
extern lean_object* l_Lean_levelZero;
extern lean_object* l_Lean_instInhabitedExpr;
LEAN_EXPORT lean_object* l_Array_filterMapM___at_ProofWidgets_Jsx_transformTag___spec__8(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxElement_quot___closed__10;
static lean_object* l_ProofWidgets_Jsx_jsxElement_quot___closed__17;
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___lambda__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxChild_____closed__1;
static lean_object* l_ProofWidgets_Jsx_delabJsxChildren___lambda__5___closed__4;
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_descend___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__5(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__1;
lean_object* l_Lean_Parser_withAntiquot(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_transformTag___lambda__3___closed__3;
lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_Lean_PrettyPrinter_Delaborator_delabLetFun___spec__5(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_addMacroScope(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_____closed__2;
static lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__2;
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__10;
static lean_object* l_ProofWidgets_Jsx_term_____closed__2;
static lean_object* l_ProofWidgets_Jsx_transformTag___lambda__2___closed__1;
uint8_t lean_name_eq(lean_object*, lean_object*);
lean_object* l_Lean_Name_str___override(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_transformTag___lambda__2___closed__2;
static lean_object* l_ProofWidgets_Jsx_jsxChild_quot___closed__2;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxText_parenthesizer___boxed(lean_object*);
static lean_object* l_ProofWidgets_Jsx_transformTag___lambda__3___closed__9;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabJsxChildren___lambda__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml___closed__2;
static lean_object* l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___closed__1;
lean_object* l_Lean_Syntax_node2(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__7(size_t, size_t, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxChild_quot___closed__4;
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__7;
static lean_object* l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__3___closed__2;
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___at_ProofWidgets_Jsx_transformTag___spec__2___boxed(lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Syntax_getTailInfo(lean_object*);
static lean_object* l_ProofWidgets_Jsx_transformTag___lambda__2___closed__6;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxAttr___x3d__;
lean_object* l_Lean_Syntax_getArg(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxElement_quot___closed__2;
static lean_object* l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__4;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxText;
uint8_t l_Lean_Syntax_matchesNull(lean_object*, lean_object*);
static lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__1;
static lean_object* l_ProofWidgets_Jsx_jsxAttr_quot___closed__3;
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5____spec__2(size_t, size_t, lean_object*, lean_object*);
lean_object* l_Lean_bignumFromJson_x3f(lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__7;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxText_parenthesizer___rarg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
uint8_t l_Lean_Syntax_isIdent(lean_object*);
lean_object* l_Lean_SubExpr_Pos_pushNaryArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_ProofWidgets_Html_instToJsonRpcEncodablePacket;
lean_object* l_Lean_PrettyPrinter_Delaborator_delabArrayLiteral___rarg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__5(size_t, size_t, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxChild_quot___closed__1;
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___rarg___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlText___lambda__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_MonadExcept_ofExcept___at_Lean_Widget_Lean_Widget_WidgetInstance_instRpcEncodableWidgetInstance_dec____x40_Lean_Widget_Types___hyg_3____spec__2(lean_object*, lean_object*);
lean_object* lean_mk_syntax_ident(lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__9;
static lean_object* l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__3___closed__1;
static lean_object* l_ProofWidgets_Jsx_jsxChild_quot___closed__9;
static lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__3;
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__6;
lean_object* l_Lean_Parser_takeWhile1Fn(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttr_quot___closed__1;
lean_object* l_Array_append___rarg(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__5___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxElement_quot___closed__12;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_SubExpr_Pos_push(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__2(size_t, size_t, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttr_quot___closed__10;
LEAN_EXPORT lean_object* l_Array_filterMapM___at_ProofWidgets_Jsx_transformTag___spec__10___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttr_quot___closed__6;
lean_object* l_Lean_Syntax_node4(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxChild_x7b___x7d___closed__1;
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__7(lean_object*, lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__1;
static lean_object* l_ProofWidgets_Util_foldInlsM___at_ProofWidgets_Jsx_transformTag___spec__6___closed__1;
static lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__8;
static lean_object* l_ProofWidgets_Jsx_jsxElement_quot___closed__13;
static lean_object* l_ProofWidgets_Jsx_jsxChild____1___closed__2;
lean_object* l_Lean_Json_parseTagged(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxText___closed__1;
static lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__12;
static lean_object* l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
static lean_object* l_ProofWidgets_Jsx_jsxChild_quot___closed__7;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e;
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__1;
static lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__11;
static lean_object* l_ProofWidgets_Jsx_transformTag___lambda__3___closed__7;
LEAN_EXPORT lean_object* l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__1___boxed(lean_object*);
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__4;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d;
static lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__3;
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__8;
LEAN_EXPORT lean_object* l_Array_sequenceMap___at_ProofWidgets_Jsx___aux__ProofWidgets__Data__Html______macroRules__ProofWidgets__Jsx__term____1___spec__1___boxed(lean_object*, lean_object*);
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
static lean_object* l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2___closed__2;
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__7___lambda__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__2;
lean_object* l_Array_mapMUnsafe_map___at___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1590____spec__2(size_t, size_t, lean_object*);
lean_object* l_Lean_Syntax_SepArray_ofElems(lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11(lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxChild_quot___closed__6;
lean_object* l_Lean_PrettyPrinter_Delaborator_failure___rarg(lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__4(size_t, size_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx___aux__ProofWidgets__Data__Html______macroRules__ProofWidgets__Jsx__term____1___lambda__1(lean_object*);
LEAN_EXPORT lean_object* l_String_anyAux___at_ProofWidgets_Jsx_delabHtmlText___spec__2___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__3;
static lean_object* l_ProofWidgets_Jsx_transformTag___lambda__3___closed__8;
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_____closed__5;
uint8_t lean_uint32_dec_eq(uint32_t, uint32_t);
lean_object* l_id___rarg___boxed(lean_object*);
lean_object* l_Lean_Name_mkStr2(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxChild_quot___closed__8;
lean_object* l_String_contains___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__6___boxed(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_delabJsxChildren___closed__3;
LEAN_EXPORT lean_object* l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e;
lean_object* l_Lean_Syntax_node1(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__10;
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5____spec__1(size_t, size_t, lean_object*, lean_object*);
uint8_t l_Lean_Expr_isConstOf(lean_object*, lean_object*);
lean_object* l_Lean_PrettyPrinter_Delaborator_annotateTermLikeInfo___rarg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__5(lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxElement_quot___closed__6;
static lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__9;
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__2(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___rarg(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__1;
LEAN_EXPORT lean_object* l_Lean_Parser_Category_jsxElement;
static lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__3___closed__1;
lean_object* l_Except_orElseLazy___rarg(lean_object*, lean_object*);
lean_object* l_MonadExcept_ofExcept___at_Lean_Widget_Lean_Widget_InteractiveHypothesisBundle_instRpcEncodableInteractiveHypothesisBundle_dec____x40_Lean_Widget_InteractiveGoal___hyg_5____spec__1(lean_object*, lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_sequenceMap___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__2(lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabJsxChildren___lambda__5(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_transformTag___lambda__3___closed__4;
static lean_object* l_ProofWidgets_Util_foldInlsM___at_ProofWidgets_Jsx_transformTag___spec__6___closed__2;
static lean_object* l_ProofWidgets_Jsx_transformTag___lambda__2___closed__4;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_transformTag___lambda__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlText___lambda__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_filterMapM___at_ProofWidgets_Jsx_transformTag___spec__10(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__5___closed__1;
static lean_object* l_ProofWidgets_Jsx_transformTag___lambda__3___closed__1;
static lean_object* l_ProofWidgets_Jsx_jsxChild____1___closed__1;
lean_object* l_Lean_Meta_instantiateMVarsIfMVarApp(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__5;
static lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__2___closed__1;
static lean_object* l_ProofWidgets_Jsx_jsxAttr_quot___closed__2;
LEAN_EXPORT lean_object* l_Lean_Parser_Category_jsxAttrVal;
lean_object* lean_erase_macro_scopes(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxTextForbidden;
static lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__2;
lean_object* l_Lean_bignumToJson(lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___elambda__1(lean_object*);
static lean_object* l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__4;
LEAN_EXPORT lean_object* l_Array_sequenceMap_loop___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__3___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabJsxChildren___lambda__3(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxText___lambda__1___closed__4;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxChild_quot;
static lean_object* l_ProofWidgets_Jsx_jsxTextForbidden___closed__1;
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___at_ProofWidgets_Jsx_transformTag___spec__6___lambda__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__12;
static lean_object* l_ProofWidgets_Jsx_jsxChild_quot___closed__5;
lean_object* l_Function_comp___rarg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__7___lambda__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_transformTag___lambda__3(lean_object*, size_t, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
size_t lean_usize_add(size_t, size_t);
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__15;
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__9(lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__1(lean_object*);
static lean_object* l_String_anyAux___at_ProofWidgets_Jsx_delabHtmlText___spec__1___closed__1;
lean_object* l_Lean_Syntax_node8(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__4___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__13;
lean_object* l_Lean_Parser_mkAntiquot(lean_object*, lean_object*, uint8_t, uint8_t);
LEAN_EXPORT lean_object* l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____lambda__1___boxed(lean_object*, lean_object*);
lean_object* lean_array_uget(lean_object*, size_t);
size_t lean_array_size(lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__5;
static lean_object* l_ProofWidgets_Jsx_jsxChild____1___closed__3;
static lean_object* l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__10;
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___at_ProofWidgets_Jsx_transformTag___spec__6___boxed(lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__10;
static lean_object* l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__2;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_term__;
static lean_object* l_ProofWidgets_ProofWidgets_Html_instToJsonRpcEncodablePacket___closed__1;
lean_object* l_Lean_Name_mkStr4(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1(lean_object*, lean_object*, size_t, size_t, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__5(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__2;
lean_object* l___private_Lean_Expr_0__Lean_Expr_getAppArgsAux(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlText___lambda__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_transformTag___lambda__4(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_LayoutKind_noConfusion___rarg___lambda__1___boxed(lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__13;
lean_object* lean_string_append(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_____closed__6;
static lean_object* l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2___closed__1;
lean_object* l_ReaderT_bind___at_Lean_PrettyPrinter_Delaborator_delabMVar___spec__1___rarg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__5___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxAttrVal_quot;
lean_object* l_Array_foldlMUnsafe_fold___at_Lean_Syntax_SepArray_getElems___spec__1(lean_object*, size_t, size_t, lean_object*);
lean_object* lean_array_get_size(lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxElement_quot___closed__5;
static lean_object* l_ProofWidgets_Jsx_jsxElement_quot___closed__14;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx___aux__ProofWidgets__Data__Html______macroRules__ProofWidgets__Jsx__term____1(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_delabHtmlText___closed__2;
static lean_object* l_ProofWidgets_Jsx_jsxText___lambda__1___closed__1;
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
static lean_object* l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__4;
uint8_t lean_usize_dec_lt(size_t, size_t);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__4(size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__6(size_t, size_t, lean_object*);
LEAN_EXPORT lean_object* l_String_anyAux___at_ProofWidgets_Jsx_delabHtmlText___spec__1___boxed(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__3___closed__3;
lean_object* lean_nat_add(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxChild_quot___closed__3;
uint8_t l_Lean_Exception_isRuntime(lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__5;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabJsxChildren(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_Lean_Json_pretty(lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxChild_x7b___x7d___closed__3;
lean_object* l_Lean_Parser_mkNodeToken(lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_String_toSubstring_x27(lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
LEAN_EXPORT lean_object* l_ProofWidgets_LayoutKind_toCtorIdx___boxed(lean_object*);
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withAppArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__4(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__8;
lean_object* lean_array_uset(lean_object*, size_t, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxText_formatter(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t l_String_anyAux___at_ProofWidgets_Jsx_delabHtmlText___spec__2(uint32_t, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__2;
static lean_object* l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__3___closed__1;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxText_parenthesizer___rarg(lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxText___lambda__1(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__2;
static lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__1;
LEAN_EXPORT lean_object* l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__3(lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_term_____closed__3;
static lean_object* l_ProofWidgets_Jsx_delabJsxChildren___lambda__5___closed__2;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlOfComponent_x27(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxAttrVal__;
static lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__5;
static lean_object* l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__4;
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlText___lambda__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlElement(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
lean_object* l_StateT_pure___at_Lean_Server_instRpcEncodableStateMRpcObjectStore___spec__1___rarg(lean_object*, lean_object*);
static lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
LEAN_EXPORT lean_object* l_Array_sequenceMap_loop___at_ProofWidgets_Jsx___aux__ProofWidgets__Data__Html______macroRules__ProofWidgets__Jsx__term____1___spec__2(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_object* l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__9;
LEAN_EXPORT lean_object* l_ProofWidgets_LayoutKind_noConfusion___rarg___lambda__1(lean_object*);
uint8_t l_Array_isEmpty___rarg(lean_object*);
static lean_object* l_ProofWidgets_Jsx_delabJsxChildren___closed__1;
static lean_object* _init_l_ProofWidgets_instInhabitedHtml___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(0u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_instInhabitedHtml___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("", 0, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_instInhabitedHtml___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_instInhabitedHtml___closed__2;
x_2 = l_ProofWidgets_instInhabitedHtml___closed__1;
x_3 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
lean_ctor_set(x_3, 2, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_instInhabitedHtml() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_instInhabitedHtml___closed__3;
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__1___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("no inductive constructor matched", 32, 32);
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__1___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__1___closed__1;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__1(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__1___closed__2;
return x_2;
}
}
static lean_object* _init_l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("component", 9, 9);
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__1___boxed), 1, 0);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_4 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2___closed__1;
x_5 = lean_unsigned_to_nat(4u);
x_6 = l_Lean_Json_parseTagged(x_1, x_4, x_5, x_2);
if (lean_obj_tag(x_6) == 0)
{
uint8_t x_7; 
x_7 = !lean_is_exclusive(x_6);
if (x_7 == 0)
{
lean_object* x_8; lean_object* x_9; 
x_8 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2___closed__2;
x_9 = l_Except_orElseLazy___rarg(x_6, x_8);
return x_9;
}
else
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; 
x_10 = lean_ctor_get(x_6, 0);
lean_inc(x_10);
lean_dec(x_6);
x_11 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_11, 0, x_10);
x_12 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2___closed__2;
x_13 = l_Except_orElseLazy___rarg(x_11, x_12);
return x_13;
}
}
else
{
lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; uint8_t x_18; lean_object* x_19; uint8_t x_20; lean_object* x_21; uint8_t x_22; lean_object* x_23; uint8_t x_24; lean_object* x_25; lean_object* x_51; lean_object* x_52; 
x_14 = lean_ctor_get(x_6, 0);
lean_inc(x_14);
if (lean_is_exclusive(x_6)) {
 lean_ctor_release(x_6, 0);
 x_15 = x_6;
} else {
 lean_dec_ref(x_6);
 x_15 = lean_box(0);
}
x_16 = lean_array_get_size(x_14);
x_17 = lean_unsigned_to_nat(0u);
x_18 = lean_nat_dec_lt(x_17, x_16);
x_19 = lean_unsigned_to_nat(1u);
x_20 = lean_nat_dec_lt(x_19, x_16);
x_21 = lean_unsigned_to_nat(2u);
x_22 = lean_nat_dec_lt(x_21, x_16);
x_23 = lean_unsigned_to_nat(3u);
x_24 = lean_nat_dec_lt(x_23, x_16);
lean_dec(x_16);
if (x_18 == 0)
{
lean_object* x_79; lean_object* x_80; 
x_79 = l_Lean_instInhabitedJson;
x_80 = l_outOfBounds___rarg(x_79);
if (x_20 == 0)
{
x_25 = x_80;
goto block_50;
}
else
{
lean_dec(x_15);
x_51 = x_80;
x_52 = lean_box(0);
goto block_78;
}
}
else
{
lean_object* x_81; 
x_81 = lean_array_fget(x_14, x_17);
if (x_20 == 0)
{
x_25 = x_81;
goto block_50;
}
else
{
lean_dec(x_15);
x_51 = x_81;
x_52 = lean_box(0);
goto block_78;
}
}
block_50:
{
lean_object* x_26; lean_object* x_27; 
x_26 = l_Lean_instInhabitedJson;
x_27 = l_outOfBounds___rarg(x_26);
if (x_22 == 0)
{
lean_object* x_28; 
x_28 = l_outOfBounds___rarg(x_26);
if (x_24 == 0)
{
lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; 
lean_dec(x_14);
x_29 = l_outOfBounds___rarg(x_26);
x_30 = lean_alloc_ctor(2, 4, 0);
lean_ctor_set(x_30, 0, x_25);
lean_ctor_set(x_30, 1, x_27);
lean_ctor_set(x_30, 2, x_28);
lean_ctor_set(x_30, 3, x_29);
if (lean_is_scalar(x_15)) {
 x_31 = lean_alloc_ctor(1, 1, 0);
} else {
 x_31 = x_15;
}
lean_ctor_set(x_31, 0, x_30);
x_32 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2___closed__2;
x_33 = l_Except_orElseLazy___rarg(x_31, x_32);
return x_33;
}
else
{
lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; 
x_34 = lean_array_fget(x_14, x_23);
lean_dec(x_14);
x_35 = lean_alloc_ctor(2, 4, 0);
lean_ctor_set(x_35, 0, x_25);
lean_ctor_set(x_35, 1, x_27);
lean_ctor_set(x_35, 2, x_28);
lean_ctor_set(x_35, 3, x_34);
if (lean_is_scalar(x_15)) {
 x_36 = lean_alloc_ctor(1, 1, 0);
} else {
 x_36 = x_15;
}
lean_ctor_set(x_36, 0, x_35);
x_37 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2___closed__2;
x_38 = l_Except_orElseLazy___rarg(x_36, x_37);
return x_38;
}
}
else
{
lean_object* x_39; 
x_39 = lean_array_fget(x_14, x_21);
if (x_24 == 0)
{
lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; 
lean_dec(x_14);
x_40 = l_outOfBounds___rarg(x_26);
x_41 = lean_alloc_ctor(2, 4, 0);
lean_ctor_set(x_41, 0, x_25);
lean_ctor_set(x_41, 1, x_27);
lean_ctor_set(x_41, 2, x_39);
lean_ctor_set(x_41, 3, x_40);
if (lean_is_scalar(x_15)) {
 x_42 = lean_alloc_ctor(1, 1, 0);
} else {
 x_42 = x_15;
}
lean_ctor_set(x_42, 0, x_41);
x_43 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2___closed__2;
x_44 = l_Except_orElseLazy___rarg(x_42, x_43);
return x_44;
}
else
{
lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; 
x_45 = lean_array_fget(x_14, x_23);
lean_dec(x_14);
x_46 = lean_alloc_ctor(2, 4, 0);
lean_ctor_set(x_46, 0, x_25);
lean_ctor_set(x_46, 1, x_27);
lean_ctor_set(x_46, 2, x_39);
lean_ctor_set(x_46, 3, x_45);
if (lean_is_scalar(x_15)) {
 x_47 = lean_alloc_ctor(1, 1, 0);
} else {
 x_47 = x_15;
}
lean_ctor_set(x_47, 0, x_46);
x_48 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2___closed__2;
x_49 = l_Except_orElseLazy___rarg(x_47, x_48);
return x_49;
}
}
}
block_78:
{
lean_object* x_53; 
x_53 = lean_array_fget(x_14, x_19);
if (x_22 == 0)
{
lean_object* x_54; lean_object* x_55; 
x_54 = l_Lean_instInhabitedJson;
x_55 = l_outOfBounds___rarg(x_54);
if (x_24 == 0)
{
lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; 
lean_dec(x_14);
x_56 = l_outOfBounds___rarg(x_54);
x_57 = lean_alloc_ctor(2, 4, 0);
lean_ctor_set(x_57, 0, x_51);
lean_ctor_set(x_57, 1, x_53);
lean_ctor_set(x_57, 2, x_55);
lean_ctor_set(x_57, 3, x_56);
x_58 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_58, 0, x_57);
x_59 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2___closed__2;
x_60 = l_Except_orElseLazy___rarg(x_58, x_59);
return x_60;
}
else
{
lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; lean_object* x_65; 
x_61 = lean_array_fget(x_14, x_23);
lean_dec(x_14);
x_62 = lean_alloc_ctor(2, 4, 0);
lean_ctor_set(x_62, 0, x_51);
lean_ctor_set(x_62, 1, x_53);
lean_ctor_set(x_62, 2, x_55);
lean_ctor_set(x_62, 3, x_61);
x_63 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_63, 0, x_62);
x_64 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2___closed__2;
x_65 = l_Except_orElseLazy___rarg(x_63, x_64);
return x_65;
}
}
else
{
lean_object* x_66; 
x_66 = lean_array_fget(x_14, x_21);
if (x_24 == 0)
{
lean_object* x_67; lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; 
lean_dec(x_14);
x_67 = l_Lean_instInhabitedJson;
x_68 = l_outOfBounds___rarg(x_67);
x_69 = lean_alloc_ctor(2, 4, 0);
lean_ctor_set(x_69, 0, x_51);
lean_ctor_set(x_69, 1, x_53);
lean_ctor_set(x_69, 2, x_66);
lean_ctor_set(x_69, 3, x_68);
x_70 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_70, 0, x_69);
x_71 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2___closed__2;
x_72 = l_Except_orElseLazy___rarg(x_70, x_71);
return x_72;
}
else
{
lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; 
x_73 = lean_array_fget(x_14, x_23);
lean_dec(x_14);
x_74 = lean_alloc_ctor(2, 4, 0);
lean_ctor_set(x_74, 0, x_51);
lean_ctor_set(x_74, 1, x_53);
lean_ctor_set(x_74, 2, x_66);
lean_ctor_set(x_74, 3, x_73);
x_75 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_75, 0, x_74);
x_76 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2___closed__2;
x_77 = l_Except_orElseLazy___rarg(x_75, x_76);
return x_77;
}
}
}
}
}
}
static lean_object* _init_l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__3___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("element", 7, 7);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__3(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; 
x_4 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__3___closed__1;
x_5 = lean_unsigned_to_nat(3u);
lean_inc(x_1);
x_6 = l_Lean_Json_parseTagged(x_1, x_4, x_5, x_2);
x_7 = lean_alloc_closure((void*)(l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2___boxed), 3, 2);
lean_closure_set(x_7, 0, x_1);
lean_closure_set(x_7, 1, x_2);
if (lean_obj_tag(x_6) == 0)
{
uint8_t x_8; 
x_8 = !lean_is_exclusive(x_6);
if (x_8 == 0)
{
lean_object* x_9; 
x_9 = l_Except_orElseLazy___rarg(x_6, x_7);
return x_9;
}
else
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_10 = lean_ctor_get(x_6, 0);
lean_inc(x_10);
lean_dec(x_6);
x_11 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_11, 0, x_10);
x_12 = l_Except_orElseLazy___rarg(x_11, x_7);
return x_12;
}
}
else
{
uint8_t x_13; 
x_13 = !lean_is_exclusive(x_6);
if (x_13 == 0)
{
lean_object* x_14; lean_object* x_15; lean_object* x_16; uint8_t x_17; lean_object* x_18; uint8_t x_19; lean_object* x_20; uint8_t x_21; 
x_14 = lean_ctor_get(x_6, 0);
x_15 = lean_array_get_size(x_14);
x_16 = lean_unsigned_to_nat(0u);
x_17 = lean_nat_dec_lt(x_16, x_15);
x_18 = lean_unsigned_to_nat(1u);
x_19 = lean_nat_dec_lt(x_18, x_15);
x_20 = lean_unsigned_to_nat(2u);
x_21 = lean_nat_dec_lt(x_20, x_15);
lean_dec(x_15);
if (x_17 == 0)
{
lean_object* x_22; lean_object* x_23; 
x_22 = l_Lean_instInhabitedJson;
x_23 = l_outOfBounds___rarg(x_22);
if (x_19 == 0)
{
lean_object* x_24; 
x_24 = l_outOfBounds___rarg(x_22);
if (x_21 == 0)
{
lean_object* x_25; lean_object* x_26; lean_object* x_27; 
lean_dec(x_14);
x_25 = l_outOfBounds___rarg(x_22);
x_26 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_26, 0, x_23);
lean_ctor_set(x_26, 1, x_24);
lean_ctor_set(x_26, 2, x_25);
lean_ctor_set(x_6, 0, x_26);
x_27 = l_Except_orElseLazy___rarg(x_6, x_7);
return x_27;
}
else
{
lean_object* x_28; lean_object* x_29; lean_object* x_30; 
x_28 = lean_array_fget(x_14, x_20);
lean_dec(x_14);
x_29 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_29, 0, x_23);
lean_ctor_set(x_29, 1, x_24);
lean_ctor_set(x_29, 2, x_28);
lean_ctor_set(x_6, 0, x_29);
x_30 = l_Except_orElseLazy___rarg(x_6, x_7);
return x_30;
}
}
else
{
lean_object* x_31; 
x_31 = lean_array_fget(x_14, x_18);
if (x_21 == 0)
{
lean_object* x_32; lean_object* x_33; lean_object* x_34; 
lean_dec(x_14);
x_32 = l_outOfBounds___rarg(x_22);
x_33 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_33, 0, x_23);
lean_ctor_set(x_33, 1, x_31);
lean_ctor_set(x_33, 2, x_32);
lean_ctor_set(x_6, 0, x_33);
x_34 = l_Except_orElseLazy___rarg(x_6, x_7);
return x_34;
}
else
{
lean_object* x_35; lean_object* x_36; lean_object* x_37; 
x_35 = lean_array_fget(x_14, x_20);
lean_dec(x_14);
x_36 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_36, 0, x_23);
lean_ctor_set(x_36, 1, x_31);
lean_ctor_set(x_36, 2, x_35);
lean_ctor_set(x_6, 0, x_36);
x_37 = l_Except_orElseLazy___rarg(x_6, x_7);
return x_37;
}
}
}
else
{
lean_object* x_38; 
x_38 = lean_array_fget(x_14, x_16);
if (x_19 == 0)
{
lean_object* x_39; lean_object* x_40; 
x_39 = l_Lean_instInhabitedJson;
x_40 = l_outOfBounds___rarg(x_39);
if (x_21 == 0)
{
lean_object* x_41; lean_object* x_42; lean_object* x_43; 
lean_dec(x_14);
x_41 = l_outOfBounds___rarg(x_39);
x_42 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_42, 0, x_38);
lean_ctor_set(x_42, 1, x_40);
lean_ctor_set(x_42, 2, x_41);
lean_ctor_set(x_6, 0, x_42);
x_43 = l_Except_orElseLazy___rarg(x_6, x_7);
return x_43;
}
else
{
lean_object* x_44; lean_object* x_45; lean_object* x_46; 
x_44 = lean_array_fget(x_14, x_20);
lean_dec(x_14);
x_45 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_45, 0, x_38);
lean_ctor_set(x_45, 1, x_40);
lean_ctor_set(x_45, 2, x_44);
lean_ctor_set(x_6, 0, x_45);
x_46 = l_Except_orElseLazy___rarg(x_6, x_7);
return x_46;
}
}
else
{
lean_object* x_47; 
x_47 = lean_array_fget(x_14, x_18);
if (x_21 == 0)
{
lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; 
lean_dec(x_14);
x_48 = l_Lean_instInhabitedJson;
x_49 = l_outOfBounds___rarg(x_48);
x_50 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_50, 0, x_38);
lean_ctor_set(x_50, 1, x_47);
lean_ctor_set(x_50, 2, x_49);
lean_ctor_set(x_6, 0, x_50);
x_51 = l_Except_orElseLazy___rarg(x_6, x_7);
return x_51;
}
else
{
lean_object* x_52; lean_object* x_53; lean_object* x_54; 
x_52 = lean_array_fget(x_14, x_20);
lean_dec(x_14);
x_53 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_53, 0, x_38);
lean_ctor_set(x_53, 1, x_47);
lean_ctor_set(x_53, 2, x_52);
lean_ctor_set(x_6, 0, x_53);
x_54 = l_Except_orElseLazy___rarg(x_6, x_7);
return x_54;
}
}
}
}
else
{
lean_object* x_55; lean_object* x_56; lean_object* x_57; uint8_t x_58; lean_object* x_59; uint8_t x_60; lean_object* x_61; uint8_t x_62; 
x_55 = lean_ctor_get(x_6, 0);
lean_inc(x_55);
lean_dec(x_6);
x_56 = lean_array_get_size(x_55);
x_57 = lean_unsigned_to_nat(0u);
x_58 = lean_nat_dec_lt(x_57, x_56);
x_59 = lean_unsigned_to_nat(1u);
x_60 = lean_nat_dec_lt(x_59, x_56);
x_61 = lean_unsigned_to_nat(2u);
x_62 = lean_nat_dec_lt(x_61, x_56);
lean_dec(x_56);
if (x_58 == 0)
{
lean_object* x_63; lean_object* x_64; 
x_63 = l_Lean_instInhabitedJson;
x_64 = l_outOfBounds___rarg(x_63);
if (x_60 == 0)
{
lean_object* x_65; 
x_65 = l_outOfBounds___rarg(x_63);
if (x_62 == 0)
{
lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; 
lean_dec(x_55);
x_66 = l_outOfBounds___rarg(x_63);
x_67 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_67, 0, x_64);
lean_ctor_set(x_67, 1, x_65);
lean_ctor_set(x_67, 2, x_66);
x_68 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_68, 0, x_67);
x_69 = l_Except_orElseLazy___rarg(x_68, x_7);
return x_69;
}
else
{
lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; 
x_70 = lean_array_fget(x_55, x_61);
lean_dec(x_55);
x_71 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_71, 0, x_64);
lean_ctor_set(x_71, 1, x_65);
lean_ctor_set(x_71, 2, x_70);
x_72 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_72, 0, x_71);
x_73 = l_Except_orElseLazy___rarg(x_72, x_7);
return x_73;
}
}
else
{
lean_object* x_74; 
x_74 = lean_array_fget(x_55, x_59);
if (x_62 == 0)
{
lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; 
lean_dec(x_55);
x_75 = l_outOfBounds___rarg(x_63);
x_76 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_76, 0, x_64);
lean_ctor_set(x_76, 1, x_74);
lean_ctor_set(x_76, 2, x_75);
x_77 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_77, 0, x_76);
x_78 = l_Except_orElseLazy___rarg(x_77, x_7);
return x_78;
}
else
{
lean_object* x_79; lean_object* x_80; lean_object* x_81; lean_object* x_82; 
x_79 = lean_array_fget(x_55, x_61);
lean_dec(x_55);
x_80 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_80, 0, x_64);
lean_ctor_set(x_80, 1, x_74);
lean_ctor_set(x_80, 2, x_79);
x_81 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_81, 0, x_80);
x_82 = l_Except_orElseLazy___rarg(x_81, x_7);
return x_82;
}
}
}
else
{
lean_object* x_83; 
x_83 = lean_array_fget(x_55, x_57);
if (x_60 == 0)
{
lean_object* x_84; lean_object* x_85; 
x_84 = l_Lean_instInhabitedJson;
x_85 = l_outOfBounds___rarg(x_84);
if (x_62 == 0)
{
lean_object* x_86; lean_object* x_87; lean_object* x_88; lean_object* x_89; 
lean_dec(x_55);
x_86 = l_outOfBounds___rarg(x_84);
x_87 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_87, 0, x_83);
lean_ctor_set(x_87, 1, x_85);
lean_ctor_set(x_87, 2, x_86);
x_88 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_88, 0, x_87);
x_89 = l_Except_orElseLazy___rarg(x_88, x_7);
return x_89;
}
else
{
lean_object* x_90; lean_object* x_91; lean_object* x_92; lean_object* x_93; 
x_90 = lean_array_fget(x_55, x_61);
lean_dec(x_55);
x_91 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_91, 0, x_83);
lean_ctor_set(x_91, 1, x_85);
lean_ctor_set(x_91, 2, x_90);
x_92 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_92, 0, x_91);
x_93 = l_Except_orElseLazy___rarg(x_92, x_7);
return x_93;
}
}
else
{
lean_object* x_94; 
x_94 = lean_array_fget(x_55, x_59);
if (x_62 == 0)
{
lean_object* x_95; lean_object* x_96; lean_object* x_97; lean_object* x_98; lean_object* x_99; 
lean_dec(x_55);
x_95 = l_Lean_instInhabitedJson;
x_96 = l_outOfBounds___rarg(x_95);
x_97 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_97, 0, x_83);
lean_ctor_set(x_97, 1, x_94);
lean_ctor_set(x_97, 2, x_96);
x_98 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_98, 0, x_97);
x_99 = l_Except_orElseLazy___rarg(x_98, x_7);
return x_99;
}
else
{
lean_object* x_100; lean_object* x_101; lean_object* x_102; lean_object* x_103; 
x_100 = lean_array_fget(x_55, x_61);
lean_dec(x_55);
x_101 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_101, 0, x_83);
lean_ctor_set(x_101, 1, x_94);
lean_ctor_set(x_101, 2, x_100);
x_102 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_102, 0, x_101);
x_103 = l_Except_orElseLazy___rarg(x_102, x_7);
return x_103;
}
}
}
}
}
}
}
static lean_object* _init_l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("text", 4, 4);
return x_1;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189_(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_2 = lean_box(0);
x_3 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____closed__1;
x_4 = lean_unsigned_to_nat(1u);
lean_inc(x_1);
x_5 = l_Lean_Json_parseTagged(x_1, x_3, x_4, x_2);
x_6 = lean_alloc_closure((void*)(l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__3___boxed), 3, 2);
lean_closure_set(x_6, 0, x_1);
lean_closure_set(x_6, 1, x_2);
if (lean_obj_tag(x_5) == 0)
{
uint8_t x_7; 
x_7 = !lean_is_exclusive(x_5);
if (x_7 == 0)
{
lean_object* x_8; 
x_8 = l_Except_orElseLazy___rarg(x_5, x_6);
return x_8;
}
else
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_9 = lean_ctor_get(x_5, 0);
lean_inc(x_9);
lean_dec(x_5);
x_10 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_10, 0, x_9);
x_11 = l_Except_orElseLazy___rarg(x_10, x_6);
return x_11;
}
}
else
{
uint8_t x_12; 
x_12 = !lean_is_exclusive(x_5);
if (x_12 == 0)
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; uint8_t x_16; 
x_13 = lean_ctor_get(x_5, 0);
x_14 = lean_array_get_size(x_13);
x_15 = lean_unsigned_to_nat(0u);
x_16 = lean_nat_dec_lt(x_15, x_14);
lean_dec(x_14);
if (x_16 == 0)
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; 
lean_dec(x_13);
x_17 = l_Lean_instInhabitedJson;
x_18 = l_outOfBounds___rarg(x_17);
x_19 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_19, 0, x_18);
lean_ctor_set(x_5, 0, x_19);
x_20 = l_Except_orElseLazy___rarg(x_5, x_6);
return x_20;
}
else
{
lean_object* x_21; lean_object* x_22; lean_object* x_23; 
x_21 = lean_array_fget(x_13, x_15);
lean_dec(x_13);
x_22 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_22, 0, x_21);
lean_ctor_set(x_5, 0, x_22);
x_23 = l_Except_orElseLazy___rarg(x_5, x_6);
return x_23;
}
}
else
{
lean_object* x_24; lean_object* x_25; lean_object* x_26; uint8_t x_27; 
x_24 = lean_ctor_get(x_5, 0);
lean_inc(x_24);
lean_dec(x_5);
x_25 = lean_array_get_size(x_24);
x_26 = lean_unsigned_to_nat(0u);
x_27 = lean_nat_dec_lt(x_26, x_25);
lean_dec(x_25);
if (x_27 == 0)
{
lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; 
lean_dec(x_24);
x_28 = l_Lean_instInhabitedJson;
x_29 = l_outOfBounds___rarg(x_28);
x_30 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_30, 0, x_29);
x_31 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_31, 0, x_30);
x_32 = l_Except_orElseLazy___rarg(x_31, x_6);
return x_32;
}
else
{
lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; 
x_33 = lean_array_fget(x_24, x_26);
lean_dec(x_24);
x_34 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_34, 0, x_33);
x_35 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_35, 0, x_34);
x_36 = l_Except_orElseLazy___rarg(x_35, x_6);
return x_36;
}
}
}
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__1___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__1(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2(x_1, x_2, x_3);
lean_dec(x_3);
lean_dec(x_2);
return x_4;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__3___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__3(x_1, x_2, x_3);
lean_dec(x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_ProofWidgets_Html_instFromJsonRpcEncodablePacket___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_ProofWidgets_Html_instFromJsonRpcEncodablePacket() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_ProofWidgets_Html_instFromJsonRpcEncodablePacket___closed__1;
return x_1;
}
}
static lean_object* _init_l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_toJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_457____closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(3u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
static lean_object* _init_l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_toJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_457____closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(4u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_toJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_457_(lean_object* x_1) {
_start:
{
switch (lean_obj_tag(x_1)) {
case 0:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; 
x_2 = lean_ctor_get(x_1, 0);
lean_inc(x_2);
x_3 = lean_ctor_get(x_1, 1);
lean_inc(x_3);
x_4 = lean_ctor_get(x_1, 2);
lean_inc(x_4);
lean_dec(x_1);
x_5 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_toJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_457____closed__1;
x_6 = lean_array_push(x_5, x_2);
x_7 = lean_array_push(x_6, x_3);
x_8 = lean_array_push(x_7, x_4);
x_9 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_9, 0, x_8);
x_10 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__3___closed__1;
x_11 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_11, 0, x_10);
lean_ctor_set(x_11, 1, x_9);
x_12 = lean_box(0);
x_13 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_13, 0, x_11);
lean_ctor_set(x_13, 1, x_12);
x_14 = l_Lean_Json_mkObj(x_13);
return x_14;
}
case 1:
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; 
x_15 = lean_ctor_get(x_1, 0);
lean_inc(x_15);
lean_dec(x_1);
x_16 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____closed__1;
x_17 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_17, 0, x_16);
lean_ctor_set(x_17, 1, x_15);
x_18 = lean_box(0);
x_19 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_19, 0, x_17);
lean_ctor_set(x_19, 1, x_18);
x_20 = l_Lean_Json_mkObj(x_19);
return x_20;
}
default: 
{
lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; 
x_21 = lean_ctor_get(x_1, 0);
lean_inc(x_21);
x_22 = lean_ctor_get(x_1, 1);
lean_inc(x_22);
x_23 = lean_ctor_get(x_1, 2);
lean_inc(x_23);
x_24 = lean_ctor_get(x_1, 3);
lean_inc(x_24);
lean_dec(x_1);
x_25 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_toJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_457____closed__2;
x_26 = lean_array_push(x_25, x_21);
x_27 = lean_array_push(x_26, x_22);
x_28 = lean_array_push(x_27, x_23);
x_29 = lean_array_push(x_28, x_24);
x_30 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_30, 0, x_29);
x_31 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2___closed__1;
x_32 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_32, 0, x_31);
lean_ctor_set(x_32, 1, x_30);
x_33 = lean_box(0);
x_34 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_34, 0, x_32);
lean_ctor_set(x_34, 1, x_33);
x_35 = l_Lean_Json_mkObj(x_34);
return x_35;
}
}
}
}
static lean_object* _init_l_ProofWidgets_ProofWidgets_Html_instToJsonRpcEncodablePacket___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_toJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_457_), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_ProofWidgets_Html_instToJsonRpcEncodablePacket() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_ProofWidgets_Html_instToJsonRpcEncodablePacket___closed__1;
return x_1;
}
}
static lean_object* _init_l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(2u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5____spec__1(size_t x_1, size_t x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
uint8_t x_5; 
x_5 = lean_usize_dec_lt(x_2, x_1);
if (x_5 == 0)
{
lean_object* x_6; 
x_6 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_6, 0, x_3);
lean_ctor_set(x_6, 1, x_4);
return x_6;
}
else
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; size_t x_17; size_t x_18; lean_object* x_19; 
x_7 = lean_array_uget(x_3, x_2);
x_8 = lean_unsigned_to_nat(0u);
x_9 = lean_array_uset(x_3, x_2, x_8);
x_10 = lean_ctor_get(x_7, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_7, 1);
lean_inc(x_11);
lean_dec(x_7);
x_12 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_12, 0, x_10);
x_13 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__1;
x_14 = lean_array_push(x_13, x_12);
x_15 = lean_array_push(x_14, x_11);
x_16 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_16, 0, x_15);
x_17 = 1;
x_18 = lean_usize_add(x_2, x_17);
x_19 = lean_array_uset(x_9, x_2, x_16);
x_2 = x_18;
x_3 = x_19;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5____spec__2(size_t x_1, size_t x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
uint8_t x_5; 
x_5 = lean_usize_dec_lt(x_2, x_1);
if (x_5 == 0)
{
lean_object* x_6; 
x_6 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_6, 0, x_3);
lean_ctor_set(x_6, 1, x_4);
return x_6;
}
else
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; size_t x_13; size_t x_14; lean_object* x_15; 
x_7 = lean_array_uget(x_3, x_2);
x_8 = lean_unsigned_to_nat(0u);
x_9 = lean_array_uset(x_3, x_2, x_8);
x_10 = l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5_(x_7, x_4);
x_11 = lean_ctor_get(x_10, 0);
lean_inc(x_11);
x_12 = lean_ctor_get(x_10, 1);
lean_inc(x_12);
lean_dec(x_10);
x_13 = 1;
x_14 = lean_usize_add(x_2, x_13);
x_15 = lean_array_uset(x_9, x_2, x_11);
x_2 = x_14;
x_3 = x_15;
x_4 = x_12;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5_(lean_object* x_1, lean_object* x_2) {
_start:
{
switch (lean_obj_tag(x_1)) {
case 0:
{
uint8_t x_3; 
x_3 = !lean_is_exclusive(x_1);
if (x_3 == 0)
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; size_t x_8; size_t x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; size_t x_13; lean_object* x_14; lean_object* x_15; size_t x_16; lean_object* x_17; uint8_t x_18; 
x_4 = lean_ctor_get(x_1, 0);
x_5 = lean_ctor_get(x_1, 1);
x_6 = lean_ctor_get(x_1, 2);
x_7 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_7, 0, x_4);
x_8 = lean_array_size(x_5);
x_9 = 0;
x_10 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5____spec__1(x_8, x_9, x_5, x_2);
x_11 = lean_ctor_get(x_10, 0);
lean_inc(x_11);
x_12 = lean_ctor_get(x_10, 1);
lean_inc(x_12);
lean_dec(x_10);
x_13 = lean_array_size(x_11);
x_14 = l_Array_mapMUnsafe_map___at___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1590____spec__2(x_13, x_9, x_11);
x_15 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_15, 0, x_14);
x_16 = lean_array_size(x_6);
x_17 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5____spec__2(x_16, x_9, x_6, x_12);
x_18 = !lean_is_exclusive(x_17);
if (x_18 == 0)
{
lean_object* x_19; size_t x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; 
x_19 = lean_ctor_get(x_17, 0);
x_20 = lean_array_size(x_19);
x_21 = l_Array_mapMUnsafe_map___at___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1590____spec__2(x_20, x_9, x_19);
x_22 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_22, 0, x_21);
lean_ctor_set(x_1, 2, x_22);
lean_ctor_set(x_1, 1, x_15);
lean_ctor_set(x_1, 0, x_7);
x_23 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_toJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_457_(x_1);
lean_ctor_set(x_17, 0, x_23);
return x_17;
}
else
{
lean_object* x_24; lean_object* x_25; size_t x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; 
x_24 = lean_ctor_get(x_17, 0);
x_25 = lean_ctor_get(x_17, 1);
lean_inc(x_25);
lean_inc(x_24);
lean_dec(x_17);
x_26 = lean_array_size(x_24);
x_27 = l_Array_mapMUnsafe_map___at___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1590____spec__2(x_26, x_9, x_24);
x_28 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_28, 0, x_27);
lean_ctor_set(x_1, 2, x_28);
lean_ctor_set(x_1, 1, x_15);
lean_ctor_set(x_1, 0, x_7);
x_29 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_toJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_457_(x_1);
x_30 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_30, 0, x_29);
lean_ctor_set(x_30, 1, x_25);
return x_30;
}
}
else
{
lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; size_t x_35; size_t x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; size_t x_40; lean_object* x_41; lean_object* x_42; size_t x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; size_t x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; 
x_31 = lean_ctor_get(x_1, 0);
x_32 = lean_ctor_get(x_1, 1);
x_33 = lean_ctor_get(x_1, 2);
lean_inc(x_33);
lean_inc(x_32);
lean_inc(x_31);
lean_dec(x_1);
x_34 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_34, 0, x_31);
x_35 = lean_array_size(x_32);
x_36 = 0;
x_37 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5____spec__1(x_35, x_36, x_32, x_2);
x_38 = lean_ctor_get(x_37, 0);
lean_inc(x_38);
x_39 = lean_ctor_get(x_37, 1);
lean_inc(x_39);
lean_dec(x_37);
x_40 = lean_array_size(x_38);
x_41 = l_Array_mapMUnsafe_map___at___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1590____spec__2(x_40, x_36, x_38);
x_42 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_42, 0, x_41);
x_43 = lean_array_size(x_33);
x_44 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5____spec__2(x_43, x_36, x_33, x_39);
x_45 = lean_ctor_get(x_44, 0);
lean_inc(x_45);
x_46 = lean_ctor_get(x_44, 1);
lean_inc(x_46);
if (lean_is_exclusive(x_44)) {
 lean_ctor_release(x_44, 0);
 lean_ctor_release(x_44, 1);
 x_47 = x_44;
} else {
 lean_dec_ref(x_44);
 x_47 = lean_box(0);
}
x_48 = lean_array_size(x_45);
x_49 = l_Array_mapMUnsafe_map___at___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1590____spec__2(x_48, x_36, x_45);
x_50 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_50, 0, x_49);
x_51 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_51, 0, x_34);
lean_ctor_set(x_51, 1, x_42);
lean_ctor_set(x_51, 2, x_50);
x_52 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_toJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_457_(x_51);
if (lean_is_scalar(x_47)) {
 x_53 = lean_alloc_ctor(0, 2, 0);
} else {
 x_53 = x_47;
}
lean_ctor_set(x_53, 0, x_52);
lean_ctor_set(x_53, 1, x_46);
return x_53;
}
}
case 1:
{
uint8_t x_54; 
x_54 = !lean_is_exclusive(x_1);
if (x_54 == 0)
{
lean_object* x_55; lean_object* x_56; lean_object* x_57; 
lean_ctor_set_tag(x_1, 3);
x_55 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_55, 0, x_1);
x_56 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_toJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_457_(x_55);
x_57 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_57, 0, x_56);
lean_ctor_set(x_57, 1, x_2);
return x_57;
}
else
{
lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; 
x_58 = lean_ctor_get(x_1, 0);
lean_inc(x_58);
lean_dec(x_1);
x_59 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_59, 0, x_58);
x_60 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_60, 0, x_59);
x_61 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_toJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_457_(x_60);
x_62 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_62, 0, x_61);
lean_ctor_set(x_62, 1, x_2);
return x_62;
}
}
default: 
{
uint64_t x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; size_t x_73; size_t x_74; lean_object* x_75; uint8_t x_76; 
x_63 = lean_ctor_get_uint64(x_1, sizeof(void*)*3);
x_64 = lean_ctor_get(x_1, 0);
lean_inc(x_64);
x_65 = lean_ctor_get(x_1, 1);
lean_inc(x_65);
x_66 = lean_ctor_get(x_1, 2);
lean_inc(x_66);
lean_dec(x_1);
x_67 = lean_uint64_to_nat(x_63);
x_68 = l_Lean_bignumToJson(x_67);
x_69 = lean_alloc_ctor(3, 1, 0);
lean_ctor_set(x_69, 0, x_64);
x_70 = lean_apply_1(x_65, x_2);
x_71 = lean_ctor_get(x_70, 0);
lean_inc(x_71);
x_72 = lean_ctor_get(x_70, 1);
lean_inc(x_72);
lean_dec(x_70);
x_73 = lean_array_size(x_66);
x_74 = 0;
x_75 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5____spec__2(x_73, x_74, x_66, x_72);
x_76 = !lean_is_exclusive(x_75);
if (x_76 == 0)
{
lean_object* x_77; size_t x_78; lean_object* x_79; lean_object* x_80; lean_object* x_81; lean_object* x_82; 
x_77 = lean_ctor_get(x_75, 0);
x_78 = lean_array_size(x_77);
x_79 = l_Array_mapMUnsafe_map___at___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1590____spec__2(x_78, x_74, x_77);
x_80 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_80, 0, x_79);
x_81 = lean_alloc_ctor(2, 4, 0);
lean_ctor_set(x_81, 0, x_68);
lean_ctor_set(x_81, 1, x_69);
lean_ctor_set(x_81, 2, x_71);
lean_ctor_set(x_81, 3, x_80);
x_82 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_toJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_457_(x_81);
lean_ctor_set(x_75, 0, x_82);
return x_75;
}
else
{
lean_object* x_83; lean_object* x_84; size_t x_85; lean_object* x_86; lean_object* x_87; lean_object* x_88; lean_object* x_89; lean_object* x_90; 
x_83 = lean_ctor_get(x_75, 0);
x_84 = lean_ctor_get(x_75, 1);
lean_inc(x_84);
lean_inc(x_83);
lean_dec(x_75);
x_85 = lean_array_size(x_83);
x_86 = l_Array_mapMUnsafe_map___at___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_toJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1590____spec__2(x_85, x_74, x_83);
x_87 = lean_alloc_ctor(4, 1, 0);
lean_ctor_set(x_87, 0, x_86);
x_88 = lean_alloc_ctor(2, 4, 0);
lean_ctor_set(x_88, 0, x_68);
lean_ctor_set(x_88, 1, x_69);
lean_ctor_set(x_88, 2, x_71);
lean_ctor_set(x_88, 3, x_87);
x_89 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_toJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_457_(x_88);
x_90 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_90, 0, x_89);
lean_ctor_set(x_90, 1, x_84);
return x_90;
}
}
}
}
}
static lean_object* _init_l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("expected pair, got '", 20, 20);
return x_1;
}
}
static lean_object* _init_l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("'", 1, 1);
return x_1;
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1(size_t x_1, size_t x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
uint8_t x_5; 
x_5 = lean_usize_dec_lt(x_2, x_1);
if (x_5 == 0)
{
lean_object* x_6; 
x_6 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_6, 0, x_3);
return x_6;
}
else
{
lean_object* x_7; 
x_7 = lean_array_uget(x_3, x_2);
switch (lean_obj_tag(x_7)) {
case 0:
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; 
lean_dec(x_3);
x_8 = lean_unsigned_to_nat(80u);
x_9 = l_Lean_Json_pretty(x_7, x_8);
x_10 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__1;
x_11 = lean_string_append(x_10, x_9);
lean_dec(x_9);
x_12 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__2;
x_13 = lean_string_append(x_11, x_12);
x_14 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_14, 0, x_13);
return x_14;
}
case 1:
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; 
lean_dec(x_3);
x_15 = lean_unsigned_to_nat(80u);
x_16 = l_Lean_Json_pretty(x_7, x_15);
x_17 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__1;
x_18 = lean_string_append(x_17, x_16);
lean_dec(x_16);
x_19 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__2;
x_20 = lean_string_append(x_18, x_19);
x_21 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_21, 0, x_20);
return x_21;
}
case 4:
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; uint8_t x_27; 
x_22 = lean_ctor_get(x_7, 0);
lean_inc(x_22);
x_23 = lean_unsigned_to_nat(0u);
x_24 = lean_array_uset(x_3, x_2, x_23);
x_25 = lean_array_get_size(x_22);
x_26 = lean_unsigned_to_nat(2u);
x_27 = lean_nat_dec_eq(x_25, x_26);
lean_dec(x_25);
if (x_27 == 0)
{
lean_object* x_28; lean_object* x_29; uint8_t x_30; 
lean_dec(x_24);
lean_dec(x_22);
x_28 = lean_unsigned_to_nat(80u);
lean_inc(x_7);
x_29 = l_Lean_Json_pretty(x_7, x_28);
x_30 = !lean_is_exclusive(x_7);
if (x_30 == 0)
{
lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; 
x_31 = lean_ctor_get(x_7, 0);
lean_dec(x_31);
x_32 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__1;
x_33 = lean_string_append(x_32, x_29);
lean_dec(x_29);
x_34 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__2;
x_35 = lean_string_append(x_33, x_34);
lean_ctor_set_tag(x_7, 0);
lean_ctor_set(x_7, 0, x_35);
return x_7;
}
else
{
lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; 
lean_dec(x_7);
x_36 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__1;
x_37 = lean_string_append(x_36, x_29);
lean_dec(x_29);
x_38 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__2;
x_39 = lean_string_append(x_37, x_38);
x_40 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_40, 0, x_39);
return x_40;
}
}
else
{
lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; 
lean_dec(x_7);
x_41 = lean_array_fget(x_22, x_23);
x_42 = lean_unsigned_to_nat(1u);
x_43 = lean_array_fget(x_22, x_42);
lean_dec(x_22);
x_44 = l_Lean_Json_getStr_x3f(x_41);
x_45 = l_MonadExcept_ofExcept___at_Lean_Widget_Lean_Widget_InteractiveHypothesisBundle_instRpcEncodableInteractiveHypothesisBundle_dec____x40_Lean_Widget_InteractiveGoal___hyg_5____spec__1(x_44, x_4);
if (lean_obj_tag(x_45) == 0)
{
uint8_t x_46; 
lean_dec(x_43);
lean_dec(x_24);
x_46 = !lean_is_exclusive(x_45);
if (x_46 == 0)
{
return x_45;
}
else
{
lean_object* x_47; lean_object* x_48; 
x_47 = lean_ctor_get(x_45, 0);
lean_inc(x_47);
lean_dec(x_45);
x_48 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_48, 0, x_47);
return x_48;
}
}
else
{
uint8_t x_49; 
x_49 = !lean_is_exclusive(x_45);
if (x_49 == 0)
{
lean_object* x_50; lean_object* x_51; 
x_50 = lean_ctor_get(x_45, 0);
lean_ctor_set(x_45, 0, x_43);
x_51 = l_MonadExcept_ofExcept___at_Lean_Widget_Lean_Widget_WidgetInstance_instRpcEncodableWidgetInstance_dec____x40_Lean_Widget_Types___hyg_3____spec__2(x_45, x_4);
if (lean_obj_tag(x_51) == 0)
{
uint8_t x_52; 
lean_dec(x_50);
lean_dec(x_24);
x_52 = !lean_is_exclusive(x_51);
if (x_52 == 0)
{
return x_51;
}
else
{
lean_object* x_53; lean_object* x_54; 
x_53 = lean_ctor_get(x_51, 0);
lean_inc(x_53);
lean_dec(x_51);
x_54 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_54, 0, x_53);
return x_54;
}
}
else
{
lean_object* x_55; lean_object* x_56; size_t x_57; size_t x_58; lean_object* x_59; 
x_55 = lean_ctor_get(x_51, 0);
lean_inc(x_55);
lean_dec(x_51);
x_56 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_56, 0, x_50);
lean_ctor_set(x_56, 1, x_55);
x_57 = 1;
x_58 = lean_usize_add(x_2, x_57);
x_59 = lean_array_uset(x_24, x_2, x_56);
x_2 = x_58;
x_3 = x_59;
goto _start;
}
}
else
{
lean_object* x_61; lean_object* x_62; lean_object* x_63; 
x_61 = lean_ctor_get(x_45, 0);
lean_inc(x_61);
lean_dec(x_45);
x_62 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_62, 0, x_43);
x_63 = l_MonadExcept_ofExcept___at_Lean_Widget_Lean_Widget_WidgetInstance_instRpcEncodableWidgetInstance_dec____x40_Lean_Widget_Types___hyg_3____spec__2(x_62, x_4);
if (lean_obj_tag(x_63) == 0)
{
lean_object* x_64; lean_object* x_65; lean_object* x_66; 
lean_dec(x_61);
lean_dec(x_24);
x_64 = lean_ctor_get(x_63, 0);
lean_inc(x_64);
if (lean_is_exclusive(x_63)) {
 lean_ctor_release(x_63, 0);
 x_65 = x_63;
} else {
 lean_dec_ref(x_63);
 x_65 = lean_box(0);
}
if (lean_is_scalar(x_65)) {
 x_66 = lean_alloc_ctor(0, 1, 0);
} else {
 x_66 = x_65;
}
lean_ctor_set(x_66, 0, x_64);
return x_66;
}
else
{
lean_object* x_67; lean_object* x_68; size_t x_69; size_t x_70; lean_object* x_71; 
x_67 = lean_ctor_get(x_63, 0);
lean_inc(x_67);
lean_dec(x_63);
x_68 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_68, 0, x_61);
lean_ctor_set(x_68, 1, x_67);
x_69 = 1;
x_70 = lean_usize_add(x_2, x_69);
x_71 = lean_array_uset(x_24, x_2, x_68);
x_2 = x_70;
x_3 = x_71;
goto _start;
}
}
}
}
}
default: 
{
lean_object* x_73; lean_object* x_74; uint8_t x_75; 
lean_dec(x_3);
x_73 = lean_unsigned_to_nat(80u);
lean_inc(x_7);
x_74 = l_Lean_Json_pretty(x_7, x_73);
x_75 = !lean_is_exclusive(x_7);
if (x_75 == 0)
{
lean_object* x_76; lean_object* x_77; lean_object* x_78; lean_object* x_79; lean_object* x_80; 
x_76 = lean_ctor_get(x_7, 0);
lean_dec(x_76);
x_77 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__1;
x_78 = lean_string_append(x_77, x_74);
lean_dec(x_74);
x_79 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__2;
x_80 = lean_string_append(x_78, x_79);
lean_ctor_set_tag(x_7, 0);
lean_ctor_set(x_7, 0, x_80);
return x_7;
}
else
{
lean_object* x_81; lean_object* x_82; lean_object* x_83; lean_object* x_84; lean_object* x_85; 
lean_dec(x_7);
x_81 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__1;
x_82 = lean_string_append(x_81, x_74);
lean_dec(x_74);
x_83 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__2;
x_84 = lean_string_append(x_82, x_83);
x_85 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_85, 0, x_84);
return x_85;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__2(size_t x_1, size_t x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
uint8_t x_5; 
x_5 = lean_usize_dec_lt(x_2, x_1);
if (x_5 == 0)
{
lean_object* x_6; 
x_6 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_6, 0, x_3);
return x_6;
}
else
{
lean_object* x_7; lean_object* x_8; lean_object* x_9; lean_object* x_10; 
x_7 = lean_array_uget(x_3, x_2);
x_8 = lean_unsigned_to_nat(0u);
x_9 = lean_array_uset(x_3, x_2, x_8);
x_10 = l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5_(x_7, x_4);
if (lean_obj_tag(x_10) == 0)
{
uint8_t x_11; 
lean_dec(x_9);
x_11 = !lean_is_exclusive(x_10);
if (x_11 == 0)
{
return x_10;
}
else
{
lean_object* x_12; lean_object* x_13; 
x_12 = lean_ctor_get(x_10, 0);
lean_inc(x_12);
lean_dec(x_10);
x_13 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_13, 0, x_12);
return x_13;
}
}
else
{
lean_object* x_14; size_t x_15; size_t x_16; lean_object* x_17; 
x_14 = lean_ctor_get(x_10, 0);
lean_inc(x_14);
lean_dec(x_10);
x_15 = 1;
x_16 = lean_usize_add(x_2, x_15);
x_17 = lean_array_uset(x_9, x_2, x_14);
x_2 = x_16;
x_3 = x_17;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____lambda__1(lean_object* x_1, lean_object* x_2) {
_start:
{
uint64_t x_3; lean_object* x_4; lean_object* x_5; 
x_3 = lean_uint64_of_nat(x_1);
x_4 = lean_box_uint64(x_3);
x_5 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_5, 0, x_4);
return x_5;
}
}
static lean_object* _init_l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("expected JSON array, got '", 26, 26);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_cstr_to_nat("18446744073709551616");
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("value '{j}' is too large for `UInt64`", 37, 37);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__3;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5_(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189_(x_1);
if (lean_obj_tag(x_3) == 0)
{
uint8_t x_4; 
x_4 = !lean_is_exclusive(x_3);
if (x_4 == 0)
{
return x_3;
}
else
{
lean_object* x_5; lean_object* x_6; 
x_5 = lean_ctor_get(x_3, 0);
lean_inc(x_5);
lean_dec(x_3);
x_6 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_6, 0, x_5);
return x_6;
}
}
else
{
lean_object* x_7; 
x_7 = lean_ctor_get(x_3, 0);
lean_inc(x_7);
lean_dec(x_3);
switch (lean_obj_tag(x_7)) {
case 0:
{
uint8_t x_8; 
x_8 = !lean_is_exclusive(x_7);
if (x_8 == 0)
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; 
x_9 = lean_ctor_get(x_7, 0);
x_10 = lean_ctor_get(x_7, 1);
x_11 = lean_ctor_get(x_7, 2);
x_12 = l_Lean_Json_getStr_x3f(x_9);
x_13 = l_MonadExcept_ofExcept___at_Lean_Widget_Lean_Widget_InteractiveHypothesisBundle_instRpcEncodableInteractiveHypothesisBundle_dec____x40_Lean_Widget_InteractiveGoal___hyg_5____spec__1(x_12, x_2);
if (lean_obj_tag(x_13) == 0)
{
uint8_t x_14; 
lean_free_object(x_7);
lean_dec(x_11);
lean_dec(x_10);
x_14 = !lean_is_exclusive(x_13);
if (x_14 == 0)
{
return x_13;
}
else
{
lean_object* x_15; lean_object* x_16; 
x_15 = lean_ctor_get(x_13, 0);
lean_inc(x_15);
lean_dec(x_13);
x_16 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_16, 0, x_15);
return x_16;
}
}
else
{
if (lean_obj_tag(x_10) == 4)
{
lean_object* x_17; lean_object* x_18; size_t x_19; size_t x_20; lean_object* x_21; lean_object* x_22; size_t x_23; lean_object* x_24; 
x_17 = lean_ctor_get(x_13, 0);
lean_inc(x_17);
lean_dec(x_13);
x_18 = lean_ctor_get(x_10, 0);
lean_inc(x_18);
lean_dec(x_10);
x_19 = lean_array_size(x_18);
x_20 = 0;
x_21 = l_Array_mapMUnsafe_map___at___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_fromJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1645____spec__2(x_19, x_20, x_18);
x_22 = lean_ctor_get(x_21, 0);
lean_inc(x_22);
lean_dec(x_21);
x_23 = lean_array_size(x_22);
x_24 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1(x_23, x_20, x_22, x_2);
if (lean_obj_tag(x_24) == 0)
{
uint8_t x_25; 
lean_dec(x_17);
lean_free_object(x_7);
lean_dec(x_11);
x_25 = !lean_is_exclusive(x_24);
if (x_25 == 0)
{
return x_24;
}
else
{
lean_object* x_26; lean_object* x_27; 
x_26 = lean_ctor_get(x_24, 0);
lean_inc(x_26);
lean_dec(x_24);
x_27 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_27, 0, x_26);
return x_27;
}
}
else
{
if (lean_obj_tag(x_11) == 4)
{
lean_object* x_28; lean_object* x_29; size_t x_30; lean_object* x_31; lean_object* x_32; size_t x_33; lean_object* x_34; 
x_28 = lean_ctor_get(x_24, 0);
lean_inc(x_28);
lean_dec(x_24);
x_29 = lean_ctor_get(x_11, 0);
lean_inc(x_29);
lean_dec(x_11);
x_30 = lean_array_size(x_29);
x_31 = l_Array_mapMUnsafe_map___at___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_fromJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1645____spec__2(x_30, x_20, x_29);
x_32 = lean_ctor_get(x_31, 0);
lean_inc(x_32);
lean_dec(x_31);
x_33 = lean_array_size(x_32);
x_34 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__2(x_33, x_20, x_32, x_2);
if (lean_obj_tag(x_34) == 0)
{
uint8_t x_35; 
lean_dec(x_28);
lean_dec(x_17);
lean_free_object(x_7);
x_35 = !lean_is_exclusive(x_34);
if (x_35 == 0)
{
return x_34;
}
else
{
lean_object* x_36; lean_object* x_37; 
x_36 = lean_ctor_get(x_34, 0);
lean_inc(x_36);
lean_dec(x_34);
x_37 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_37, 0, x_36);
return x_37;
}
}
else
{
uint8_t x_38; 
x_38 = !lean_is_exclusive(x_34);
if (x_38 == 0)
{
lean_object* x_39; 
x_39 = lean_ctor_get(x_34, 0);
lean_ctor_set(x_7, 2, x_39);
lean_ctor_set(x_7, 1, x_28);
lean_ctor_set(x_7, 0, x_17);
lean_ctor_set(x_34, 0, x_7);
return x_34;
}
else
{
lean_object* x_40; lean_object* x_41; 
x_40 = lean_ctor_get(x_34, 0);
lean_inc(x_40);
lean_dec(x_34);
lean_ctor_set(x_7, 2, x_40);
lean_ctor_set(x_7, 1, x_28);
lean_ctor_set(x_7, 0, x_17);
x_41 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_41, 0, x_7);
return x_41;
}
}
}
else
{
uint8_t x_42; 
lean_dec(x_17);
lean_free_object(x_7);
x_42 = !lean_is_exclusive(x_24);
if (x_42 == 0)
{
lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; 
x_43 = lean_ctor_get(x_24, 0);
lean_dec(x_43);
x_44 = lean_unsigned_to_nat(80u);
x_45 = l_Lean_Json_pretty(x_11, x_44);
x_46 = l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__1;
x_47 = lean_string_append(x_46, x_45);
lean_dec(x_45);
x_48 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__2;
x_49 = lean_string_append(x_47, x_48);
lean_ctor_set_tag(x_24, 0);
lean_ctor_set(x_24, 0, x_49);
return x_24;
}
else
{
lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; 
lean_dec(x_24);
x_50 = lean_unsigned_to_nat(80u);
x_51 = l_Lean_Json_pretty(x_11, x_50);
x_52 = l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__1;
x_53 = lean_string_append(x_52, x_51);
lean_dec(x_51);
x_54 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__2;
x_55 = lean_string_append(x_53, x_54);
x_56 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_56, 0, x_55);
return x_56;
}
}
}
}
else
{
uint8_t x_57; 
lean_free_object(x_7);
lean_dec(x_11);
x_57 = !lean_is_exclusive(x_13);
if (x_57 == 0)
{
lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; 
x_58 = lean_ctor_get(x_13, 0);
lean_dec(x_58);
x_59 = lean_unsigned_to_nat(80u);
x_60 = l_Lean_Json_pretty(x_10, x_59);
x_61 = l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__1;
x_62 = lean_string_append(x_61, x_60);
lean_dec(x_60);
x_63 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__2;
x_64 = lean_string_append(x_62, x_63);
lean_ctor_set_tag(x_13, 0);
lean_ctor_set(x_13, 0, x_64);
return x_13;
}
else
{
lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; 
lean_dec(x_13);
x_65 = lean_unsigned_to_nat(80u);
x_66 = l_Lean_Json_pretty(x_10, x_65);
x_67 = l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__1;
x_68 = lean_string_append(x_67, x_66);
lean_dec(x_66);
x_69 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__2;
x_70 = lean_string_append(x_68, x_69);
x_71 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_71, 0, x_70);
return x_71;
}
}
}
}
else
{
lean_object* x_72; lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; 
x_72 = lean_ctor_get(x_7, 0);
x_73 = lean_ctor_get(x_7, 1);
x_74 = lean_ctor_get(x_7, 2);
lean_inc(x_74);
lean_inc(x_73);
lean_inc(x_72);
lean_dec(x_7);
x_75 = l_Lean_Json_getStr_x3f(x_72);
x_76 = l_MonadExcept_ofExcept___at_Lean_Widget_Lean_Widget_InteractiveHypothesisBundle_instRpcEncodableInteractiveHypothesisBundle_dec____x40_Lean_Widget_InteractiveGoal___hyg_5____spec__1(x_75, x_2);
if (lean_obj_tag(x_76) == 0)
{
lean_object* x_77; lean_object* x_78; lean_object* x_79; 
lean_dec(x_74);
lean_dec(x_73);
x_77 = lean_ctor_get(x_76, 0);
lean_inc(x_77);
if (lean_is_exclusive(x_76)) {
 lean_ctor_release(x_76, 0);
 x_78 = x_76;
} else {
 lean_dec_ref(x_76);
 x_78 = lean_box(0);
}
if (lean_is_scalar(x_78)) {
 x_79 = lean_alloc_ctor(0, 1, 0);
} else {
 x_79 = x_78;
}
lean_ctor_set(x_79, 0, x_77);
return x_79;
}
else
{
if (lean_obj_tag(x_73) == 4)
{
lean_object* x_80; lean_object* x_81; size_t x_82; size_t x_83; lean_object* x_84; lean_object* x_85; size_t x_86; lean_object* x_87; 
x_80 = lean_ctor_get(x_76, 0);
lean_inc(x_80);
lean_dec(x_76);
x_81 = lean_ctor_get(x_73, 0);
lean_inc(x_81);
lean_dec(x_73);
x_82 = lean_array_size(x_81);
x_83 = 0;
x_84 = l_Array_mapMUnsafe_map___at___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_fromJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1645____spec__2(x_82, x_83, x_81);
x_85 = lean_ctor_get(x_84, 0);
lean_inc(x_85);
lean_dec(x_84);
x_86 = lean_array_size(x_85);
x_87 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1(x_86, x_83, x_85, x_2);
if (lean_obj_tag(x_87) == 0)
{
lean_object* x_88; lean_object* x_89; lean_object* x_90; 
lean_dec(x_80);
lean_dec(x_74);
x_88 = lean_ctor_get(x_87, 0);
lean_inc(x_88);
if (lean_is_exclusive(x_87)) {
 lean_ctor_release(x_87, 0);
 x_89 = x_87;
} else {
 lean_dec_ref(x_87);
 x_89 = lean_box(0);
}
if (lean_is_scalar(x_89)) {
 x_90 = lean_alloc_ctor(0, 1, 0);
} else {
 x_90 = x_89;
}
lean_ctor_set(x_90, 0, x_88);
return x_90;
}
else
{
if (lean_obj_tag(x_74) == 4)
{
lean_object* x_91; lean_object* x_92; size_t x_93; lean_object* x_94; lean_object* x_95; size_t x_96; lean_object* x_97; 
x_91 = lean_ctor_get(x_87, 0);
lean_inc(x_91);
lean_dec(x_87);
x_92 = lean_ctor_get(x_74, 0);
lean_inc(x_92);
lean_dec(x_74);
x_93 = lean_array_size(x_92);
x_94 = l_Array_mapMUnsafe_map___at___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_fromJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1645____spec__2(x_93, x_83, x_92);
x_95 = lean_ctor_get(x_94, 0);
lean_inc(x_95);
lean_dec(x_94);
x_96 = lean_array_size(x_95);
x_97 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__2(x_96, x_83, x_95, x_2);
if (lean_obj_tag(x_97) == 0)
{
lean_object* x_98; lean_object* x_99; lean_object* x_100; 
lean_dec(x_91);
lean_dec(x_80);
x_98 = lean_ctor_get(x_97, 0);
lean_inc(x_98);
if (lean_is_exclusive(x_97)) {
 lean_ctor_release(x_97, 0);
 x_99 = x_97;
} else {
 lean_dec_ref(x_97);
 x_99 = lean_box(0);
}
if (lean_is_scalar(x_99)) {
 x_100 = lean_alloc_ctor(0, 1, 0);
} else {
 x_100 = x_99;
}
lean_ctor_set(x_100, 0, x_98);
return x_100;
}
else
{
lean_object* x_101; lean_object* x_102; lean_object* x_103; lean_object* x_104; 
x_101 = lean_ctor_get(x_97, 0);
lean_inc(x_101);
if (lean_is_exclusive(x_97)) {
 lean_ctor_release(x_97, 0);
 x_102 = x_97;
} else {
 lean_dec_ref(x_97);
 x_102 = lean_box(0);
}
x_103 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_103, 0, x_80);
lean_ctor_set(x_103, 1, x_91);
lean_ctor_set(x_103, 2, x_101);
if (lean_is_scalar(x_102)) {
 x_104 = lean_alloc_ctor(1, 1, 0);
} else {
 x_104 = x_102;
}
lean_ctor_set(x_104, 0, x_103);
return x_104;
}
}
else
{
lean_object* x_105; lean_object* x_106; lean_object* x_107; lean_object* x_108; lean_object* x_109; lean_object* x_110; lean_object* x_111; lean_object* x_112; 
lean_dec(x_80);
if (lean_is_exclusive(x_87)) {
 lean_ctor_release(x_87, 0);
 x_105 = x_87;
} else {
 lean_dec_ref(x_87);
 x_105 = lean_box(0);
}
x_106 = lean_unsigned_to_nat(80u);
x_107 = l_Lean_Json_pretty(x_74, x_106);
x_108 = l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__1;
x_109 = lean_string_append(x_108, x_107);
lean_dec(x_107);
x_110 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__2;
x_111 = lean_string_append(x_109, x_110);
if (lean_is_scalar(x_105)) {
 x_112 = lean_alloc_ctor(0, 1, 0);
} else {
 x_112 = x_105;
 lean_ctor_set_tag(x_112, 0);
}
lean_ctor_set(x_112, 0, x_111);
return x_112;
}
}
}
else
{
lean_object* x_113; lean_object* x_114; lean_object* x_115; lean_object* x_116; lean_object* x_117; lean_object* x_118; lean_object* x_119; lean_object* x_120; 
lean_dec(x_74);
if (lean_is_exclusive(x_76)) {
 lean_ctor_release(x_76, 0);
 x_113 = x_76;
} else {
 lean_dec_ref(x_76);
 x_113 = lean_box(0);
}
x_114 = lean_unsigned_to_nat(80u);
x_115 = l_Lean_Json_pretty(x_73, x_114);
x_116 = l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__1;
x_117 = lean_string_append(x_116, x_115);
lean_dec(x_115);
x_118 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__2;
x_119 = lean_string_append(x_117, x_118);
if (lean_is_scalar(x_113)) {
 x_120 = lean_alloc_ctor(0, 1, 0);
} else {
 x_120 = x_113;
 lean_ctor_set_tag(x_120, 0);
}
lean_ctor_set(x_120, 0, x_119);
return x_120;
}
}
}
}
case 1:
{
uint8_t x_121; 
x_121 = !lean_is_exclusive(x_7);
if (x_121 == 0)
{
lean_object* x_122; lean_object* x_123; lean_object* x_124; 
x_122 = lean_ctor_get(x_7, 0);
x_123 = l_Lean_Json_getStr_x3f(x_122);
x_124 = l_MonadExcept_ofExcept___at_Lean_Widget_Lean_Widget_InteractiveHypothesisBundle_instRpcEncodableInteractiveHypothesisBundle_dec____x40_Lean_Widget_InteractiveGoal___hyg_5____spec__1(x_123, x_2);
if (lean_obj_tag(x_124) == 0)
{
uint8_t x_125; 
lean_free_object(x_7);
x_125 = !lean_is_exclusive(x_124);
if (x_125 == 0)
{
return x_124;
}
else
{
lean_object* x_126; lean_object* x_127; 
x_126 = lean_ctor_get(x_124, 0);
lean_inc(x_126);
lean_dec(x_124);
x_127 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_127, 0, x_126);
return x_127;
}
}
else
{
uint8_t x_128; 
x_128 = !lean_is_exclusive(x_124);
if (x_128 == 0)
{
lean_object* x_129; 
x_129 = lean_ctor_get(x_124, 0);
lean_ctor_set(x_7, 0, x_129);
lean_ctor_set(x_124, 0, x_7);
return x_124;
}
else
{
lean_object* x_130; lean_object* x_131; 
x_130 = lean_ctor_get(x_124, 0);
lean_inc(x_130);
lean_dec(x_124);
lean_ctor_set(x_7, 0, x_130);
x_131 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_131, 0, x_7);
return x_131;
}
}
}
else
{
lean_object* x_132; lean_object* x_133; lean_object* x_134; 
x_132 = lean_ctor_get(x_7, 0);
lean_inc(x_132);
lean_dec(x_7);
x_133 = l_Lean_Json_getStr_x3f(x_132);
x_134 = l_MonadExcept_ofExcept___at_Lean_Widget_Lean_Widget_InteractiveHypothesisBundle_instRpcEncodableInteractiveHypothesisBundle_dec____x40_Lean_Widget_InteractiveGoal___hyg_5____spec__1(x_133, x_2);
if (lean_obj_tag(x_134) == 0)
{
lean_object* x_135; lean_object* x_136; lean_object* x_137; 
x_135 = lean_ctor_get(x_134, 0);
lean_inc(x_135);
if (lean_is_exclusive(x_134)) {
 lean_ctor_release(x_134, 0);
 x_136 = x_134;
} else {
 lean_dec_ref(x_134);
 x_136 = lean_box(0);
}
if (lean_is_scalar(x_136)) {
 x_137 = lean_alloc_ctor(0, 1, 0);
} else {
 x_137 = x_136;
}
lean_ctor_set(x_137, 0, x_135);
return x_137;
}
else
{
lean_object* x_138; lean_object* x_139; lean_object* x_140; lean_object* x_141; 
x_138 = lean_ctor_get(x_134, 0);
lean_inc(x_138);
if (lean_is_exclusive(x_134)) {
 lean_ctor_release(x_134, 0);
 x_139 = x_134;
} else {
 lean_dec_ref(x_134);
 x_139 = lean_box(0);
}
x_140 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_140, 0, x_138);
if (lean_is_scalar(x_139)) {
 x_141 = lean_alloc_ctor(1, 1, 0);
} else {
 x_141 = x_139;
}
lean_ctor_set(x_141, 0, x_140);
return x_141;
}
}
}
default: 
{
lean_object* x_142; lean_object* x_143; lean_object* x_144; lean_object* x_145; uint64_t x_146; lean_object* x_222; 
x_142 = lean_ctor_get(x_7, 0);
lean_inc(x_142);
x_143 = lean_ctor_get(x_7, 1);
lean_inc(x_143);
x_144 = lean_ctor_get(x_7, 2);
lean_inc(x_144);
x_145 = lean_ctor_get(x_7, 3);
lean_inc(x_145);
lean_dec(x_7);
x_222 = l_Lean_bignumFromJson_x3f(x_142);
if (lean_obj_tag(x_222) == 0)
{
uint8_t x_223; 
x_223 = !lean_is_exclusive(x_222);
if (x_223 == 0)
{
lean_object* x_224; 
x_224 = l_MonadExcept_ofExcept___at_Lean_Widget_Lean_Widget_WidgetInstance_instRpcEncodableWidgetInstance_dec____x40_Lean_Widget_Types___hyg_3____spec__1(x_222, x_2);
if (lean_obj_tag(x_224) == 0)
{
uint8_t x_225; 
lean_dec(x_145);
lean_dec(x_144);
lean_dec(x_143);
x_225 = !lean_is_exclusive(x_224);
if (x_225 == 0)
{
return x_224;
}
else
{
lean_object* x_226; lean_object* x_227; 
x_226 = lean_ctor_get(x_224, 0);
lean_inc(x_226);
lean_dec(x_224);
x_227 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_227, 0, x_226);
return x_227;
}
}
else
{
lean_object* x_228; uint64_t x_229; 
x_228 = lean_ctor_get(x_224, 0);
lean_inc(x_228);
lean_dec(x_224);
x_229 = lean_unbox_uint64(x_228);
lean_dec(x_228);
x_146 = x_229;
goto block_221;
}
}
else
{
lean_object* x_230; lean_object* x_231; lean_object* x_232; 
x_230 = lean_ctor_get(x_222, 0);
lean_inc(x_230);
lean_dec(x_222);
x_231 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_231, 0, x_230);
x_232 = l_MonadExcept_ofExcept___at_Lean_Widget_Lean_Widget_WidgetInstance_instRpcEncodableWidgetInstance_dec____x40_Lean_Widget_Types___hyg_3____spec__1(x_231, x_2);
if (lean_obj_tag(x_232) == 0)
{
lean_object* x_233; lean_object* x_234; lean_object* x_235; 
lean_dec(x_145);
lean_dec(x_144);
lean_dec(x_143);
x_233 = lean_ctor_get(x_232, 0);
lean_inc(x_233);
if (lean_is_exclusive(x_232)) {
 lean_ctor_release(x_232, 0);
 x_234 = x_232;
} else {
 lean_dec_ref(x_232);
 x_234 = lean_box(0);
}
if (lean_is_scalar(x_234)) {
 x_235 = lean_alloc_ctor(0, 1, 0);
} else {
 x_235 = x_234;
}
lean_ctor_set(x_235, 0, x_233);
return x_235;
}
else
{
lean_object* x_236; uint64_t x_237; 
x_236 = lean_ctor_get(x_232, 0);
lean_inc(x_236);
lean_dec(x_232);
x_237 = lean_unbox_uint64(x_236);
lean_dec(x_236);
x_146 = x_237;
goto block_221;
}
}
}
else
{
lean_object* x_238; lean_object* x_239; uint8_t x_240; 
x_238 = lean_ctor_get(x_222, 0);
lean_inc(x_238);
lean_dec(x_222);
x_239 = l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__2;
x_240 = lean_nat_dec_le(x_239, x_238);
if (x_240 == 0)
{
lean_object* x_241; lean_object* x_242; lean_object* x_243; 
x_241 = lean_box(0);
x_242 = l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____lambda__1(x_238, x_241);
lean_dec(x_238);
x_243 = l_MonadExcept_ofExcept___at_Lean_Widget_Lean_Widget_WidgetInstance_instRpcEncodableWidgetInstance_dec____x40_Lean_Widget_Types___hyg_3____spec__1(x_242, x_2);
if (lean_obj_tag(x_243) == 0)
{
uint8_t x_244; 
lean_dec(x_145);
lean_dec(x_144);
lean_dec(x_143);
x_244 = !lean_is_exclusive(x_243);
if (x_244 == 0)
{
return x_243;
}
else
{
lean_object* x_245; lean_object* x_246; 
x_245 = lean_ctor_get(x_243, 0);
lean_inc(x_245);
lean_dec(x_243);
x_246 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_246, 0, x_245);
return x_246;
}
}
else
{
lean_object* x_247; uint64_t x_248; 
x_247 = lean_ctor_get(x_243, 0);
lean_inc(x_247);
lean_dec(x_243);
x_248 = lean_unbox_uint64(x_247);
lean_dec(x_247);
x_146 = x_248;
goto block_221;
}
}
else
{
lean_object* x_249; lean_object* x_250; 
lean_dec(x_238);
x_249 = l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__4;
x_250 = l_MonadExcept_ofExcept___at_Lean_Widget_Lean_Widget_WidgetInstance_instRpcEncodableWidgetInstance_dec____x40_Lean_Widget_Types___hyg_3____spec__1(x_249, x_2);
if (lean_obj_tag(x_250) == 0)
{
uint8_t x_251; 
lean_dec(x_145);
lean_dec(x_144);
lean_dec(x_143);
x_251 = !lean_is_exclusive(x_250);
if (x_251 == 0)
{
return x_250;
}
else
{
lean_object* x_252; lean_object* x_253; 
x_252 = lean_ctor_get(x_250, 0);
lean_inc(x_252);
lean_dec(x_250);
x_253 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_253, 0, x_252);
return x_253;
}
}
else
{
lean_object* x_254; uint64_t x_255; 
x_254 = lean_ctor_get(x_250, 0);
lean_inc(x_254);
lean_dec(x_250);
x_255 = lean_unbox_uint64(x_254);
lean_dec(x_254);
x_146 = x_255;
goto block_221;
}
}
}
block_221:
{
lean_object* x_147; lean_object* x_148; 
x_147 = l_Lean_Json_getStr_x3f(x_143);
x_148 = l_MonadExcept_ofExcept___at_Lean_Widget_Lean_Widget_InteractiveHypothesisBundle_instRpcEncodableInteractiveHypothesisBundle_dec____x40_Lean_Widget_InteractiveGoal___hyg_5____spec__1(x_147, x_2);
if (lean_obj_tag(x_148) == 0)
{
uint8_t x_149; 
lean_dec(x_145);
lean_dec(x_144);
x_149 = !lean_is_exclusive(x_148);
if (x_149 == 0)
{
return x_148;
}
else
{
lean_object* x_150; lean_object* x_151; 
x_150 = lean_ctor_get(x_148, 0);
lean_inc(x_150);
lean_dec(x_148);
x_151 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_151, 0, x_150);
return x_151;
}
}
else
{
uint8_t x_152; 
x_152 = !lean_is_exclusive(x_148);
if (x_152 == 0)
{
lean_object* x_153; lean_object* x_154; 
x_153 = lean_ctor_get(x_148, 0);
lean_ctor_set(x_148, 0, x_144);
x_154 = l_MonadExcept_ofExcept___at_Lean_Widget_Lean_Widget_WidgetInstance_instRpcEncodableWidgetInstance_dec____x40_Lean_Widget_Types___hyg_3____spec__2(x_148, x_2);
if (lean_obj_tag(x_154) == 0)
{
uint8_t x_155; 
lean_dec(x_153);
lean_dec(x_145);
x_155 = !lean_is_exclusive(x_154);
if (x_155 == 0)
{
return x_154;
}
else
{
lean_object* x_156; lean_object* x_157; 
x_156 = lean_ctor_get(x_154, 0);
lean_inc(x_156);
lean_dec(x_154);
x_157 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_157, 0, x_156);
return x_157;
}
}
else
{
if (lean_obj_tag(x_145) == 4)
{
lean_object* x_158; lean_object* x_159; lean_object* x_160; size_t x_161; size_t x_162; lean_object* x_163; lean_object* x_164; size_t x_165; lean_object* x_166; 
x_158 = lean_ctor_get(x_154, 0);
lean_inc(x_158);
lean_dec(x_154);
x_159 = lean_ctor_get(x_145, 0);
lean_inc(x_159);
lean_dec(x_145);
x_160 = lean_alloc_closure((void*)(l_StateT_pure___at_Lean_Server_instRpcEncodableStateMRpcObjectStore___spec__1___rarg), 2, 1);
lean_closure_set(x_160, 0, x_158);
x_161 = lean_array_size(x_159);
x_162 = 0;
x_163 = l_Array_mapMUnsafe_map___at___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_fromJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1645____spec__2(x_161, x_162, x_159);
x_164 = lean_ctor_get(x_163, 0);
lean_inc(x_164);
lean_dec(x_163);
x_165 = lean_array_size(x_164);
x_166 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__2(x_165, x_162, x_164, x_2);
if (lean_obj_tag(x_166) == 0)
{
uint8_t x_167; 
lean_dec(x_160);
lean_dec(x_153);
x_167 = !lean_is_exclusive(x_166);
if (x_167 == 0)
{
return x_166;
}
else
{
lean_object* x_168; lean_object* x_169; 
x_168 = lean_ctor_get(x_166, 0);
lean_inc(x_168);
lean_dec(x_166);
x_169 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_169, 0, x_168);
return x_169;
}
}
else
{
uint8_t x_170; 
x_170 = !lean_is_exclusive(x_166);
if (x_170 == 0)
{
lean_object* x_171; lean_object* x_172; 
x_171 = lean_ctor_get(x_166, 0);
x_172 = lean_alloc_ctor(2, 3, 8);
lean_ctor_set(x_172, 0, x_153);
lean_ctor_set(x_172, 1, x_160);
lean_ctor_set(x_172, 2, x_171);
lean_ctor_set_uint64(x_172, sizeof(void*)*3, x_146);
lean_ctor_set(x_166, 0, x_172);
return x_166;
}
else
{
lean_object* x_173; lean_object* x_174; lean_object* x_175; 
x_173 = lean_ctor_get(x_166, 0);
lean_inc(x_173);
lean_dec(x_166);
x_174 = lean_alloc_ctor(2, 3, 8);
lean_ctor_set(x_174, 0, x_153);
lean_ctor_set(x_174, 1, x_160);
lean_ctor_set(x_174, 2, x_173);
lean_ctor_set_uint64(x_174, sizeof(void*)*3, x_146);
x_175 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_175, 0, x_174);
return x_175;
}
}
}
else
{
uint8_t x_176; 
lean_dec(x_153);
x_176 = !lean_is_exclusive(x_154);
if (x_176 == 0)
{
lean_object* x_177; lean_object* x_178; lean_object* x_179; lean_object* x_180; lean_object* x_181; lean_object* x_182; lean_object* x_183; 
x_177 = lean_ctor_get(x_154, 0);
lean_dec(x_177);
x_178 = lean_unsigned_to_nat(80u);
x_179 = l_Lean_Json_pretty(x_145, x_178);
x_180 = l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__1;
x_181 = lean_string_append(x_180, x_179);
lean_dec(x_179);
x_182 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__2;
x_183 = lean_string_append(x_181, x_182);
lean_ctor_set_tag(x_154, 0);
lean_ctor_set(x_154, 0, x_183);
return x_154;
}
else
{
lean_object* x_184; lean_object* x_185; lean_object* x_186; lean_object* x_187; lean_object* x_188; lean_object* x_189; lean_object* x_190; 
lean_dec(x_154);
x_184 = lean_unsigned_to_nat(80u);
x_185 = l_Lean_Json_pretty(x_145, x_184);
x_186 = l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__1;
x_187 = lean_string_append(x_186, x_185);
lean_dec(x_185);
x_188 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__2;
x_189 = lean_string_append(x_187, x_188);
x_190 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_190, 0, x_189);
return x_190;
}
}
}
}
else
{
lean_object* x_191; lean_object* x_192; lean_object* x_193; 
x_191 = lean_ctor_get(x_148, 0);
lean_inc(x_191);
lean_dec(x_148);
x_192 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_192, 0, x_144);
x_193 = l_MonadExcept_ofExcept___at_Lean_Widget_Lean_Widget_WidgetInstance_instRpcEncodableWidgetInstance_dec____x40_Lean_Widget_Types___hyg_3____spec__2(x_192, x_2);
if (lean_obj_tag(x_193) == 0)
{
lean_object* x_194; lean_object* x_195; lean_object* x_196; 
lean_dec(x_191);
lean_dec(x_145);
x_194 = lean_ctor_get(x_193, 0);
lean_inc(x_194);
if (lean_is_exclusive(x_193)) {
 lean_ctor_release(x_193, 0);
 x_195 = x_193;
} else {
 lean_dec_ref(x_193);
 x_195 = lean_box(0);
}
if (lean_is_scalar(x_195)) {
 x_196 = lean_alloc_ctor(0, 1, 0);
} else {
 x_196 = x_195;
}
lean_ctor_set(x_196, 0, x_194);
return x_196;
}
else
{
if (lean_obj_tag(x_145) == 4)
{
lean_object* x_197; lean_object* x_198; lean_object* x_199; size_t x_200; size_t x_201; lean_object* x_202; lean_object* x_203; size_t x_204; lean_object* x_205; 
x_197 = lean_ctor_get(x_193, 0);
lean_inc(x_197);
lean_dec(x_193);
x_198 = lean_ctor_get(x_145, 0);
lean_inc(x_198);
lean_dec(x_145);
x_199 = lean_alloc_closure((void*)(l_StateT_pure___at_Lean_Server_instRpcEncodableStateMRpcObjectStore___spec__1___rarg), 2, 1);
lean_closure_set(x_199, 0, x_197);
x_200 = lean_array_size(x_198);
x_201 = 0;
x_202 = l_Array_mapMUnsafe_map___at___private_Lean_Data_Lsp_Basic_0__Lean_Lsp_fromJsonCommand____x40_Lean_Data_Lsp_Basic___hyg_1645____spec__2(x_200, x_201, x_198);
x_203 = lean_ctor_get(x_202, 0);
lean_inc(x_203);
lean_dec(x_202);
x_204 = lean_array_size(x_203);
x_205 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__2(x_204, x_201, x_203, x_2);
if (lean_obj_tag(x_205) == 0)
{
lean_object* x_206; lean_object* x_207; lean_object* x_208; 
lean_dec(x_199);
lean_dec(x_191);
x_206 = lean_ctor_get(x_205, 0);
lean_inc(x_206);
if (lean_is_exclusive(x_205)) {
 lean_ctor_release(x_205, 0);
 x_207 = x_205;
} else {
 lean_dec_ref(x_205);
 x_207 = lean_box(0);
}
if (lean_is_scalar(x_207)) {
 x_208 = lean_alloc_ctor(0, 1, 0);
} else {
 x_208 = x_207;
}
lean_ctor_set(x_208, 0, x_206);
return x_208;
}
else
{
lean_object* x_209; lean_object* x_210; lean_object* x_211; lean_object* x_212; 
x_209 = lean_ctor_get(x_205, 0);
lean_inc(x_209);
if (lean_is_exclusive(x_205)) {
 lean_ctor_release(x_205, 0);
 x_210 = x_205;
} else {
 lean_dec_ref(x_205);
 x_210 = lean_box(0);
}
x_211 = lean_alloc_ctor(2, 3, 8);
lean_ctor_set(x_211, 0, x_191);
lean_ctor_set(x_211, 1, x_199);
lean_ctor_set(x_211, 2, x_209);
lean_ctor_set_uint64(x_211, sizeof(void*)*3, x_146);
if (lean_is_scalar(x_210)) {
 x_212 = lean_alloc_ctor(1, 1, 0);
} else {
 x_212 = x_210;
}
lean_ctor_set(x_212, 0, x_211);
return x_212;
}
}
else
{
lean_object* x_213; lean_object* x_214; lean_object* x_215; lean_object* x_216; lean_object* x_217; lean_object* x_218; lean_object* x_219; lean_object* x_220; 
lean_dec(x_191);
if (lean_is_exclusive(x_193)) {
 lean_ctor_release(x_193, 0);
 x_213 = x_193;
} else {
 lean_dec_ref(x_193);
 x_213 = lean_box(0);
}
x_214 = lean_unsigned_to_nat(80u);
x_215 = l_Lean_Json_pretty(x_145, x_214);
x_216 = l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__1;
x_217 = lean_string_append(x_216, x_215);
lean_dec(x_215);
x_218 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__2;
x_219 = lean_string_append(x_217, x_218);
if (lean_is_scalar(x_213)) {
 x_220 = lean_alloc_ctor(0, 1, 0);
} else {
 x_220 = x_213;
 lean_ctor_set_tag(x_220, 0);
}
lean_ctor_set(x_220, 0, x_219);
return x_220;
}
}
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5____spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
size_t x_5; size_t x_6; lean_object* x_7; 
x_5 = lean_unbox_usize(x_1);
lean_dec(x_1);
x_6 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_7 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5____spec__1(x_5, x_6, x_3, x_4);
return x_7;
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5____spec__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
size_t x_5; size_t x_6; lean_object* x_7; 
x_5 = lean_unbox_usize(x_1);
lean_dec(x_1);
x_6 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_7 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5____spec__2(x_5, x_6, x_3, x_4);
return x_7;
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
size_t x_5; size_t x_6; lean_object* x_7; 
x_5 = lean_unbox_usize(x_1);
lean_dec(x_1);
x_6 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_7 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1(x_5, x_6, x_3, x_4);
lean_dec(x_4);
return x_7;
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
size_t x_5; size_t x_6; lean_object* x_7; 
x_5 = lean_unbox_usize(x_1);
lean_dec(x_1);
x_6 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_7 = l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__2(x_5, x_6, x_3, x_4);
lean_dec(x_4);
return x_7;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____lambda__1___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____lambda__1(x_1, x_2);
lean_dec(x_2);
lean_dec(x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5_(x_1, x_2);
lean_dec(x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5_), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____boxed), 2, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml___closed__1;
x_2 = l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml___closed__2;
x_3 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml___closed__3;
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___elambda__1___rarg(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = lean_apply_2(x_2, x_1, x_3);
return x_4;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___elambda__1(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_alloc_closure((void*)(l_ProofWidgets_Html_ofComponent___elambda__1___rarg), 3, 0);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___rarg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; uint64_t x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_5 = lean_ctor_get(x_2, 0);
x_6 = lean_ctor_get(x_2, 1);
x_7 = lean_ctor_get(x_5, 0);
x_8 = lean_string_hash(x_7);
x_9 = lean_ctor_get(x_1, 0);
lean_inc(x_9);
lean_dec(x_1);
x_10 = lean_alloc_closure((void*)(l_ProofWidgets_Html_ofComponent___elambda__1___rarg), 3, 2);
lean_closure_set(x_10, 0, x_3);
lean_closure_set(x_10, 1, x_9);
lean_inc(x_6);
x_11 = lean_alloc_ctor(2, 3, 8);
lean_ctor_set(x_11, 0, x_6);
lean_ctor_set(x_11, 1, x_10);
lean_ctor_set(x_11, 2, x_4);
lean_ctor_set_uint64(x_11, sizeof(void*)*3, x_8);
return x_11;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_alloc_closure((void*)(l_ProofWidgets_Html_ofComponent___rarg___boxed), 4, 0);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Html_ofComponent___rarg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_ProofWidgets_Html_ofComponent___rarg(x_1, x_2, x_3, x_4);
lean_dec(x_2);
return x_5;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_LayoutKind_toCtorIdx(uint8_t x_1) {
_start:
{
if (x_1 == 0)
{
lean_object* x_2; 
x_2 = lean_unsigned_to_nat(0u);
return x_2;
}
else
{
lean_object* x_3; 
x_3 = lean_unsigned_to_nat(1u);
return x_3;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_LayoutKind_toCtorIdx___boxed(lean_object* x_1) {
_start:
{
uint8_t x_2; lean_object* x_3; 
x_2 = lean_unbox(x_1);
lean_dec(x_1);
x_3 = l_ProofWidgets_LayoutKind_toCtorIdx(x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_LayoutKind_noConfusion___rarg___lambda__1(lean_object* x_1) {
_start:
{
lean_inc(x_1);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_LayoutKind_noConfusion___rarg___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_LayoutKind_noConfusion___rarg___lambda__1___boxed), 1, 0);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_LayoutKind_noConfusion___rarg(uint8_t x_1, uint8_t x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_ProofWidgets_LayoutKind_noConfusion___rarg___closed__1;
return x_4;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_LayoutKind_noConfusion(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_alloc_closure((void*)(l_ProofWidgets_LayoutKind_noConfusion___rarg___boxed), 3, 0);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_LayoutKind_noConfusion___rarg___lambda__1___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_ProofWidgets_LayoutKind_noConfusion___rarg___lambda__1(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_LayoutKind_noConfusion___rarg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
uint8_t x_4; uint8_t x_5; lean_object* x_6; 
x_4 = lean_unbox(x_1);
lean_dec(x_1);
x_5 = lean_unbox(x_2);
lean_dec(x_2);
x_6 = l_ProofWidgets_LayoutKind_noConfusion___rarg(x_4, x_5, x_3);
return x_6;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Lean", 4, 4);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Parser", 6, 6);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Term", 4, 4);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("quot", 4, 4);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__1;
x_2 = l_ProofWidgets_Jsx_jsxElement_quot___closed__2;
x_3 = l_ProofWidgets_Jsx_jsxElement_quot___closed__3;
x_4 = l_ProofWidgets_Jsx_jsxElement_quot___closed__4;
x_5 = l_Lean_Name_mkStr4(x_1, x_2, x_3, x_4);
return x_5;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__6() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("jsxElement", 10, 10);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__6;
x_2 = l_ProofWidgets_Jsx_jsxElement_quot___closed__4;
x_3 = l_Lean_Name_mkStr2(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__8() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("andthen", 7, 7);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_ProofWidgets_Jsx_jsxElement_quot___closed__8;
x_3 = l_Lean_Name_str___override(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__10() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("`(jsxElement| ", 14, 14);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__11() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__10;
x_2 = lean_alloc_ctor(5, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__12() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_ProofWidgets_Jsx_jsxElement_quot___closed__6;
x_3 = l_Lean_Name_str___override(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__13() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__12;
x_2 = lean_unsigned_to_nat(0u);
x_3 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__14() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(")", 1, 1);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__15() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__14;
x_2 = lean_alloc_ctor(5, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__16() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__9;
x_2 = l_ProofWidgets_Jsx_jsxElement_quot___closed__13;
x_3 = l_ProofWidgets_Jsx_jsxElement_quot___closed__15;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__17() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__9;
x_2 = l_ProofWidgets_Jsx_jsxElement_quot___closed__11;
x_3 = l_ProofWidgets_Jsx_jsxElement_quot___closed__16;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__18() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__7;
x_2 = lean_unsigned_to_nat(1024u);
x_3 = l_ProofWidgets_Jsx_jsxElement_quot___closed__17;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__19() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__5;
x_2 = lean_unsigned_to_nat(1024u);
x_3 = l_ProofWidgets_Jsx_jsxElement_quot___closed__18;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_quot() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__19;
return x_1;
}
}
static lean_object* _init_l_Lean_Parser_Category_jsxElement() {
_start:
{
lean_object* x_1; 
x_1 = lean_box(0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild_quot___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("jsxChild", 8, 8);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild_quot___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_Jsx_jsxChild_quot___closed__1;
x_2 = l_ProofWidgets_Jsx_jsxElement_quot___closed__4;
x_3 = l_Lean_Name_mkStr2(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild_quot___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("`(jsxChild| ", 12, 12);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild_quot___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Jsx_jsxChild_quot___closed__3;
x_2 = lean_alloc_ctor(5, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild_quot___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_ProofWidgets_Jsx_jsxChild_quot___closed__1;
x_3 = l_Lean_Name_str___override(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild_quot___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_Jsx_jsxChild_quot___closed__5;
x_2 = lean_unsigned_to_nat(0u);
x_3 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild_quot___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__9;
x_2 = l_ProofWidgets_Jsx_jsxChild_quot___closed__6;
x_3 = l_ProofWidgets_Jsx_jsxElement_quot___closed__15;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild_quot___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__9;
x_2 = l_ProofWidgets_Jsx_jsxChild_quot___closed__4;
x_3 = l_ProofWidgets_Jsx_jsxChild_quot___closed__7;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild_quot___closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxChild_quot___closed__2;
x_2 = lean_unsigned_to_nat(1024u);
x_3 = l_ProofWidgets_Jsx_jsxChild_quot___closed__8;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild_quot___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__5;
x_2 = lean_unsigned_to_nat(1024u);
x_3 = l_ProofWidgets_Jsx_jsxChild_quot___closed__9;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild_quot() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_Jsx_jsxChild_quot___closed__10;
return x_1;
}
}
static lean_object* _init_l_Lean_Parser_Category_jsxChild() {
_start:
{
lean_object* x_1; 
x_1 = lean_box(0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr_quot___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("jsxAttr", 7, 7);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr_quot___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_Jsx_jsxAttr_quot___closed__1;
x_2 = l_ProofWidgets_Jsx_jsxElement_quot___closed__4;
x_3 = l_Lean_Name_mkStr2(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr_quot___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("`(jsxAttr| ", 11, 11);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr_quot___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Jsx_jsxAttr_quot___closed__3;
x_2 = lean_alloc_ctor(5, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr_quot___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_ProofWidgets_Jsx_jsxAttr_quot___closed__1;
x_3 = l_Lean_Name_str___override(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr_quot___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_Jsx_jsxAttr_quot___closed__5;
x_2 = lean_unsigned_to_nat(0u);
x_3 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr_quot___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__9;
x_2 = l_ProofWidgets_Jsx_jsxAttr_quot___closed__6;
x_3 = l_ProofWidgets_Jsx_jsxElement_quot___closed__15;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr_quot___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__9;
x_2 = l_ProofWidgets_Jsx_jsxAttr_quot___closed__4;
x_3 = l_ProofWidgets_Jsx_jsxAttr_quot___closed__7;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr_quot___closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxAttr_quot___closed__2;
x_2 = lean_unsigned_to_nat(1024u);
x_3 = l_ProofWidgets_Jsx_jsxAttr_quot___closed__8;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr_quot___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__5;
x_2 = lean_unsigned_to_nat(1024u);
x_3 = l_ProofWidgets_Jsx_jsxAttr_quot___closed__9;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr_quot() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_Jsx_jsxAttr_quot___closed__10;
return x_1;
}
}
static lean_object* _init_l_Lean_Parser_Category_jsxAttr() {
_start:
{
lean_object* x_1; 
x_1 = lean_box(0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("jsxAttrVal", 10, 10);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__1;
x_2 = l_ProofWidgets_Jsx_jsxElement_quot___closed__4;
x_3 = l_Lean_Name_mkStr2(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("`(jsxAttrVal| ", 14, 14);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__3;
x_2 = lean_alloc_ctor(5, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__1;
x_3 = l_Lean_Name_str___override(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__5;
x_2 = lean_unsigned_to_nat(0u);
x_3 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__9;
x_2 = l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__6;
x_3 = l_ProofWidgets_Jsx_jsxElement_quot___closed__15;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__9;
x_2 = l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__4;
x_3 = l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__7;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__2;
x_2 = lean_unsigned_to_nat(1024u);
x_3 = l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__8;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__5;
x_2 = lean_unsigned_to_nat(1024u);
x_3 = l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__9;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_quot() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__10;
return x_1;
}
}
static lean_object* _init_l_Lean_Parser_Category_jsxAttrVal() {
_start:
{
lean_object* x_1; 
x_1 = lean_box(0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_____closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ProofWidgets", 12, 12);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_____closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Jsx", 3, 3);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_____closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("jsxAttrVal_", 11, 11);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_____closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__1;
x_2 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__2;
x_3 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__3;
x_4 = l_Lean_Name_mkStr3(x_1, x_2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_____closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("str", 3, 3);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_____closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__5;
x_3 = l_Lean_Name_str___override(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_____closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__6;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_____closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__4;
x_2 = lean_unsigned_to_nat(1022u);
x_3 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__7;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal__() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__8;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("jsxAttrVal{_}", 13, 13);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__1;
x_2 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__2;
x_3 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__1;
x_4 = l_Lean_Name_mkStr3(x_1, x_2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("group", 5, 5);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__3;
x_3 = l_Lean_Name_str___override(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("{", 1, 1);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
x_2 = lean_alloc_ctor(5, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__7() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("term", 4, 4);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__7;
x_3 = l_Lean_Name_str___override(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__8;
x_2 = lean_unsigned_to_nat(0u);
x_3 = lean_alloc_ctor(7, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__9;
x_2 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__6;
x_3 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__9;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("}", 1, 1);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__12() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
x_2 = lean_alloc_ctor(5, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__13() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__9;
x_2 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__10;
x_3 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__12;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__14() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
x_2 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__13;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__15() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2;
x_2 = lean_unsigned_to_nat(1022u);
x_3 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__14;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__15;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("jsxAttr_=_", 10, 10);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__1;
x_2 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__2;
x_3 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__1;
x_4 = l_Lean_Name_mkStr3(x_1, x_2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ident", 5, 5);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__3;
x_3 = l_Lean_Name_str___override(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__4;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("=", 1, 1);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
x_2 = lean_alloc_ctor(5, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__9;
x_2 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__5;
x_3 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__7;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__9;
x_2 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__8;
x_3 = l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__6;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
x_2 = lean_unsigned_to_nat(1022u);
x_3 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__9;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr___x3d__() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__10;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("jsxAttr{..._}", 13, 13);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__1;
x_2 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__2;
x_3 = l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__1;
x_4 = l_Lean_Name_mkStr3(x_1, x_2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(" {...", 5, 5);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__3;
x_2 = lean_alloc_ctor(5, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__9;
x_2 = l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__4;
x_3 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__9;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__9;
x_2 = l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__5;
x_3 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__12;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
x_2 = l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__6;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__2;
x_2 = lean_unsigned_to_nat(1022u);
x_3 = l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__7;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__8;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxTextForbidden___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("{<>}$", 5, 5);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxTextForbidden() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_Jsx_jsxTextForbidden___closed__1;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxText___lambda__1___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Jsx_jsxTextForbidden;
x_2 = lean_alloc_closure((void*)(l_String_contains___boxed), 2, 1);
lean_closure_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxText___lambda__1___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_not___boxed), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxText___lambda__1___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_Jsx_jsxText___lambda__1___closed__2;
x_2 = l_ProofWidgets_Jsx_jsxText___lambda__1___closed__1;
x_3 = lean_alloc_closure((void*)(l_Function_comp___rarg), 3, 2);
lean_closure_set(x_3, 0, x_1);
lean_closure_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxText___lambda__1___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("expected JSX text", 17, 17);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxText___lambda__1(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; lean_object* x_6; lean_object* x_7; lean_object* x_8; 
x_4 = lean_ctor_get(x_3, 2);
lean_inc(x_4);
x_5 = l_ProofWidgets_Jsx_jsxText___lambda__1___closed__3;
x_6 = l_ProofWidgets_Jsx_jsxText___lambda__1___closed__4;
lean_inc(x_2);
x_7 = l_Lean_Parser_takeWhile1Fn(x_5, x_6, x_2, x_3);
x_8 = l_Lean_Parser_mkNodeToken(x_1, x_4, x_2, x_7);
return x_8;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxText___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("jsxText", 7, 7);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxText___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__1;
x_2 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__2;
x_3 = l_ProofWidgets_Jsx_jsxText___closed__1;
x_4 = l_Lean_Name_mkStr3(x_1, x_2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxText___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; uint8_t x_3; uint8_t x_4; lean_object* x_5; 
x_1 = l_ProofWidgets_Jsx_jsxText___closed__1;
x_2 = l_ProofWidgets_Jsx_jsxText___closed__2;
x_3 = 1;
x_4 = 0;
x_5 = l_Lean_Parser_mkAntiquot(x_1, x_2, x_3, x_4);
return x_5;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxText___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_id___rarg___boxed), 1, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxText___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_Jsx_jsxText___closed__4;
x_2 = lean_box(1);
x_3 = lean_alloc_ctor(0, 3, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_1);
lean_ctor_set(x_3, 2, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxText() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_1 = l_ProofWidgets_Jsx_jsxText___closed__2;
x_2 = lean_alloc_closure((void*)(l_ProofWidgets_Jsx_jsxText___lambda__1), 3, 1);
lean_closure_set(x_2, 0, x_1);
x_3 = l_ProofWidgets_Jsx_jsxText___closed__5;
x_4 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
x_5 = l_ProofWidgets_Jsx_jsxText___closed__3;
x_6 = l_Lean_Parser_withAntiquot(x_5, x_4);
return x_6;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_getJsxText(lean_object* x_1) {
_start:
{
lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_2 = lean_unsigned_to_nat(0u);
x_3 = l_Lean_Syntax_getArg(x_1, x_2);
x_4 = l_Lean_Syntax_getAtomVal(x_3);
lean_dec(x_3);
return x_4;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_getJsxText___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_ProofWidgets_Jsx_getJsxText(x_1);
lean_dec(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxText_formatter(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; lean_object* x_7; 
x_6 = l_ProofWidgets_Jsx_jsxText___closed__2;
x_7 = l_Lean_PrettyPrinter_Formatter_visitAtom(x_6, x_1, x_2, x_3, x_4, x_5);
return x_7;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxText_parenthesizer___rarg(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_Lean_PrettyPrinter_Parenthesizer_visitToken___rarg(x_1, x_2, x_3, x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxText_parenthesizer(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_alloc_closure((void*)(l_ProofWidgets_Jsx_jsxText_parenthesizer___rarg___boxed), 4, 0);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxText_parenthesizer___rarg___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_ProofWidgets_Jsx_jsxText_parenthesizer___rarg(x_1, x_2, x_3, x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_5;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_jsxText_parenthesizer___boxed(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = l_ProofWidgets_Jsx_jsxText_parenthesizer(x_1);
lean_dec(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("jsxElement<__/>", 15, 15);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__1;
x_2 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__2;
x_3 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__1;
x_4 = l_Lean_Name_mkStr3(x_1, x_2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("<", 1, 1);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__3;
x_2 = lean_alloc_ctor(5, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__9;
x_2 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__4;
x_3 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__5;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__6() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("many", 4, 4);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__6;
x_3 = l_Lean_Name_str___override(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__7;
x_2 = l_ProofWidgets_Jsx_jsxAttr_quot___closed__6;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__9;
x_2 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__5;
x_3 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__8;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__10() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("/>", 2, 2);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__11() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__10;
x_2 = lean_alloc_ctor(5, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__12() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__9;
x_2 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__9;
x_3 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__11;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__13() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__2;
x_2 = lean_unsigned_to_nat(1024u);
x_3 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__12;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__13;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("jsxElement<__>_</_>", 19, 19);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__1;
x_2 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__2;
x_3 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__1;
x_4 = l_Lean_Name_mkStr3(x_1, x_2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(">", 1, 1);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__3;
x_2 = lean_alloc_ctor(5, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__9;
x_2 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__9;
x_3 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__4;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__7;
x_2 = l_ProofWidgets_Jsx_jsxChild_quot___closed__6;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__9;
x_2 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__5;
x_3 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__6;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__8() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("</", 2, 2);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__9() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__8;
x_2 = lean_alloc_ctor(5, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__9;
x_2 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__7;
x_3 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__9;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__11() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__9;
x_2 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__10;
x_3 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__5;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__12() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__9;
x_2 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__11;
x_3 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__4;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__13() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__2;
x_2 = lean_unsigned_to_nat(1024u);
x_3 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__12;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__13;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild_____closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("jsxChild_", 9, 9);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild_____closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__1;
x_2 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__2;
x_3 = l_ProofWidgets_Jsx_jsxChild_____closed__1;
x_4 = l_Lean_Name_mkStr3(x_1, x_2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild_____closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Jsx_jsxText___closed__2;
x_2 = lean_alloc_ctor(8, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild_____closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxChild_____closed__2;
x_2 = lean_unsigned_to_nat(1022u);
x_3 = l_ProofWidgets_Jsx_jsxChild_____closed__3;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild__() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_Jsx_jsxChild_____closed__4;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("jsxChild{..._}", 14, 14);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__1;
x_2 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__2;
x_3 = l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__1;
x_4 = l_Lean_Name_mkStr3(x_1, x_2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("{...", 4, 4);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__3;
x_2 = lean_alloc_ctor(5, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__9;
x_2 = l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__4;
x_3 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__9;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__9;
x_2 = l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__5;
x_3 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__12;
x_4 = lean_alloc_ctor(2, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__2;
x_2 = lean_unsigned_to_nat(1024u);
x_3 = l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__6;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__7;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild_x7b___x7d___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("jsxChild{_}", 11, 11);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild_x7b___x7d___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__1;
x_2 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__2;
x_3 = l_ProofWidgets_Jsx_jsxChild_x7b___x7d___closed__1;
x_4 = l_Lean_Name_mkStr3(x_1, x_2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild_x7b___x7d___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxChild_x7b___x7d___closed__2;
x_2 = lean_unsigned_to_nat(1024u);
x_3 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__13;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild_x7b___x7d() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_Jsx_jsxChild_x7b___x7d___closed__3;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild____1___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("jsxChild__1", 11, 11);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild____1___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__1;
x_2 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__2;
x_3 = l_ProofWidgets_Jsx_jsxChild____1___closed__1;
x_4 = l_Lean_Name_mkStr3(x_1, x_2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild____1___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxChild____1___closed__2;
x_2 = lean_unsigned_to_nat(1022u);
x_3 = l_ProofWidgets_Jsx_jsxElement_quot___closed__13;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_jsxChild____1() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_Jsx_jsxChild____1___closed__3;
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_term_____closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("term_", 5, 5);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_term_____closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__1;
x_2 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__2;
x_3 = l_ProofWidgets_Jsx_term_____closed__1;
x_4 = l_Lean_Name_mkStr3(x_1, x_2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_term_____closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_term_____closed__2;
x_2 = lean_unsigned_to_nat(1024u);
x_3 = l_ProofWidgets_Jsx_jsxElement_quot___closed__13;
x_4 = lean_alloc_ctor(3, 3, 0);
lean_ctor_set(x_4, 0, x_1);
lean_ctor_set(x_4, 1, x_2);
lean_ctor_set(x_4, 2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_term__() {
_start:
{
lean_object* x_1; 
x_1 = l_ProofWidgets_Jsx_term_____closed__3;
return x_1;
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___lambda__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; lean_object* x_11; 
x_10 = lean_array_push(x_5, x_1);
x_11 = l_Lean_Syntax_getTailInfo(x_2);
if (lean_obj_tag(x_11) == 0)
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; 
x_12 = lean_ctor_get(x_11, 2);
lean_inc(x_12);
lean_dec(x_11);
x_13 = lean_ctor_get(x_12, 0);
lean_inc(x_13);
x_14 = lean_ctor_get(x_12, 1);
lean_inc(x_14);
x_15 = lean_ctor_get(x_12, 2);
lean_inc(x_15);
lean_dec(x_12);
x_16 = lean_string_utf8_extract(x_13, x_14, x_15);
lean_dec(x_15);
lean_dec(x_14);
lean_dec(x_13);
x_17 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_17, 0, x_10);
lean_ctor_set(x_17, 1, x_16);
x_18 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_18, 0, x_3);
lean_ctor_set(x_18, 1, x_17);
x_19 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_19, 0, x_18);
x_20 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_20, 0, x_19);
lean_ctor_set(x_20, 1, x_9);
return x_20;
}
else
{
lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; 
lean_dec(x_11);
x_21 = l_ProofWidgets_instInhabitedHtml___closed__2;
x_22 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_22, 0, x_10);
lean_ctor_set(x_22, 1, x_21);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_3);
lean_ctor_set(x_23, 1, x_22);
x_24 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_24, 0, x_23);
x_25 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_25, 0, x_24);
lean_ctor_set(x_25, 1, x_9);
return x_25;
}
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("unknown syntax", 14, 14);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("term#[_,]", 9, 9);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__2;
x_3 = l_Lean_Name_str___override(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("#[", 2, 2);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("null", 4, 4);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__5;
x_3 = l_Lean_Name_str___override(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__7() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(",", 1, 1);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__8() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("]", 1, 1);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__9() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("app", 3, 3);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__1;
x_2 = l_ProofWidgets_Jsx_jsxElement_quot___closed__2;
x_3 = l_ProofWidgets_Jsx_jsxElement_quot___closed__3;
x_4 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__9;
x_5 = l_Lean_Name_mkStr4(x_1, x_2, x_3, x_4);
return x_5;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__11() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Html.text", 9, 9);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__12() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__11;
x_2 = l_String_toSubstring_x27(x_1);
return x_2;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__13() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Html", 4, 4);
return x_1;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__14() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__13;
x_2 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____closed__1;
x_3 = l_Lean_Name_mkStr2(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__15() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__1;
x_2 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__13;
x_3 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____closed__1;
x_4 = l_Lean_Name_mkStr3(x_1, x_2, x_3);
return x_4;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__16() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__15;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__17() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__15;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__18() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__17;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__19() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__16;
x_2 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__18;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1(lean_object* x_1, lean_object* x_2, size_t x_3, size_t x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; lean_object* x_9; uint8_t x_15; 
x_15 = lean_usize_dec_lt(x_4, x_3);
if (x_15 == 0)
{
lean_object* x_16; 
lean_dec(x_6);
lean_dec(x_1);
x_16 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_16, 0, x_5);
lean_ctor_set(x_16, 1, x_7);
return x_16;
}
else
{
lean_object* x_17; uint8_t x_18; 
x_17 = lean_array_uget(x_2, x_4);
x_18 = !lean_is_exclusive(x_5);
if (x_18 == 0)
{
lean_object* x_19; uint8_t x_20; 
x_19 = lean_ctor_get(x_5, 1);
x_20 = !lean_is_exclusive(x_19);
if (x_20 == 0)
{
lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; uint8_t x_25; 
x_21 = lean_ctor_get(x_5, 0);
x_22 = lean_ctor_get(x_19, 0);
x_23 = lean_ctor_get(x_19, 1);
x_24 = l_ProofWidgets_Jsx_jsxChild_____closed__2;
lean_inc(x_17);
x_25 = l_Lean_Syntax_isOfKind(x_17, x_24);
if (x_25 == 0)
{
lean_object* x_26; uint8_t x_27; 
x_26 = l_ProofWidgets_Jsx_jsxChild_x7b___x7d___closed__2;
lean_inc(x_17);
x_27 = l_Lean_Syntax_isOfKind(x_17, x_26);
if (x_27 == 0)
{
lean_object* x_28; uint8_t x_29; 
x_28 = l_ProofWidgets_Jsx_jsxChild____1___closed__2;
lean_inc(x_17);
x_29 = l_Lean_Syntax_isOfKind(x_17, x_28);
if (x_29 == 0)
{
lean_object* x_30; uint8_t x_31; 
lean_free_object(x_19);
lean_free_object(x_5);
x_30 = l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__2;
lean_inc(x_17);
x_31 = l_Lean_Syntax_isOfKind(x_17, x_30);
if (x_31 == 0)
{
lean_object* x_32; lean_object* x_33; uint8_t x_34; 
lean_dec(x_23);
lean_dec(x_22);
lean_dec(x_21);
lean_dec(x_1);
x_32 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__1;
x_33 = l_Lean_Macro_throwErrorAt___rarg(x_17, x_32, x_6, x_7);
lean_dec(x_17);
x_34 = !lean_is_exclusive(x_33);
if (x_34 == 0)
{
return x_33;
}
else
{
lean_object* x_35; lean_object* x_36; lean_object* x_37; 
x_35 = lean_ctor_get(x_33, 0);
x_36 = lean_ctor_get(x_33, 1);
lean_inc(x_36);
lean_inc(x_35);
lean_dec(x_33);
x_37 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_37, 0, x_35);
lean_ctor_set(x_37, 1, x_36);
return x_37;
}
}
else
{
lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; uint8_t x_42; 
x_38 = lean_unsigned_to_nat(1u);
x_39 = l_Lean_Syntax_getArg(x_17, x_38);
x_40 = lean_unsigned_to_nat(2u);
x_41 = l_Lean_Syntax_getArg(x_17, x_40);
lean_dec(x_17);
x_42 = l_Array_isEmpty___rarg(x_21);
if (x_42 == 0)
{
lean_object* x_43; uint8_t x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; 
x_43 = lean_ctor_get(x_6, 5);
lean_inc(x_43);
x_44 = 0;
x_45 = l_Lean_SourceInfo_fromRef(x_43, x_44);
lean_dec(x_43);
x_46 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__4;
lean_inc(x_45);
x_47 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_47, 0, x_45);
lean_ctor_set(x_47, 1, x_46);
x_48 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__7;
x_49 = l_Lean_Syntax_SepArray_ofElems(x_48, x_21);
x_50 = l_ProofWidgets_instInhabitedHtml___closed__1;
x_51 = l_Array_append___rarg(x_50, x_49);
lean_dec(x_49);
x_52 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_45);
x_53 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_53, 0, x_45);
lean_ctor_set(x_53, 1, x_52);
lean_ctor_set(x_53, 2, x_51);
x_54 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__8;
lean_inc(x_45);
x_55 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_55, 0, x_45);
lean_ctor_set(x_55, 1, x_54);
x_56 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__3;
x_57 = l_Lean_Syntax_node3(x_45, x_56, x_47, x_53, x_55);
x_58 = lean_array_push(x_22, x_57);
x_59 = lean_box(0);
lean_inc(x_1);
x_60 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___lambda__1(x_39, x_41, x_1, x_21, x_58, x_23, x_59, x_6, x_7);
lean_dec(x_23);
lean_dec(x_21);
lean_dec(x_41);
x_61 = lean_ctor_get(x_60, 0);
lean_inc(x_61);
x_62 = lean_ctor_get(x_60, 1);
lean_inc(x_62);
lean_dec(x_60);
x_8 = x_61;
x_9 = x_62;
goto block_14;
}
else
{
lean_object* x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; 
x_63 = lean_box(0);
lean_inc(x_1);
x_64 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___lambda__1(x_39, x_41, x_1, x_21, x_22, x_23, x_63, x_6, x_7);
lean_dec(x_23);
lean_dec(x_21);
lean_dec(x_41);
x_65 = lean_ctor_get(x_64, 0);
lean_inc(x_65);
x_66 = lean_ctor_get(x_64, 1);
lean_inc(x_66);
lean_dec(x_64);
x_8 = x_65;
x_9 = x_66;
goto block_14;
}
}
}
else
{
lean_object* x_67; lean_object* x_68; lean_object* x_69; uint8_t x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; lean_object* x_74; lean_object* x_75; 
lean_dec(x_23);
x_67 = lean_unsigned_to_nat(0u);
x_68 = l_Lean_Syntax_getArg(x_17, x_67);
lean_dec(x_17);
x_69 = lean_ctor_get(x_6, 5);
lean_inc(x_69);
x_70 = 0;
x_71 = l_Lean_SourceInfo_fromRef(x_69, x_70);
lean_dec(x_69);
x_72 = l_ProofWidgets_Jsx_term_____closed__2;
lean_inc(x_68);
x_73 = l_Lean_Syntax_node1(x_71, x_72, x_68);
x_74 = lean_array_push(x_21, x_73);
x_75 = l_Lean_Syntax_getTailInfo(x_68);
lean_dec(x_68);
if (lean_obj_tag(x_75) == 0)
{
lean_object* x_76; lean_object* x_77; lean_object* x_78; lean_object* x_79; lean_object* x_80; lean_object* x_81; 
x_76 = lean_ctor_get(x_75, 2);
lean_inc(x_76);
lean_dec(x_75);
x_77 = lean_ctor_get(x_76, 0);
lean_inc(x_77);
x_78 = lean_ctor_get(x_76, 1);
lean_inc(x_78);
x_79 = lean_ctor_get(x_76, 2);
lean_inc(x_79);
lean_dec(x_76);
x_80 = lean_string_utf8_extract(x_77, x_78, x_79);
lean_dec(x_79);
lean_dec(x_78);
lean_dec(x_77);
lean_ctor_set(x_19, 1, x_80);
lean_ctor_set(x_5, 0, x_74);
x_81 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_81, 0, x_5);
x_8 = x_81;
x_9 = x_7;
goto block_14;
}
else
{
lean_object* x_82; lean_object* x_83; 
lean_dec(x_75);
x_82 = l_ProofWidgets_instInhabitedHtml___closed__2;
lean_ctor_set(x_19, 1, x_82);
lean_ctor_set(x_5, 0, x_74);
x_83 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_83, 0, x_5);
x_8 = x_83;
x_9 = x_7;
goto block_14;
}
}
}
else
{
lean_object* x_84; lean_object* x_85; lean_object* x_86; lean_object* x_87; lean_object* x_88; lean_object* x_89; 
lean_dec(x_23);
x_84 = lean_unsigned_to_nat(1u);
x_85 = l_Lean_Syntax_getArg(x_17, x_84);
x_86 = lean_unsigned_to_nat(2u);
x_87 = l_Lean_Syntax_getArg(x_17, x_86);
lean_dec(x_17);
x_88 = lean_array_push(x_21, x_85);
x_89 = l_Lean_Syntax_getTailInfo(x_87);
lean_dec(x_87);
if (lean_obj_tag(x_89) == 0)
{
lean_object* x_90; lean_object* x_91; lean_object* x_92; lean_object* x_93; lean_object* x_94; lean_object* x_95; 
x_90 = lean_ctor_get(x_89, 2);
lean_inc(x_90);
lean_dec(x_89);
x_91 = lean_ctor_get(x_90, 0);
lean_inc(x_91);
x_92 = lean_ctor_get(x_90, 1);
lean_inc(x_92);
x_93 = lean_ctor_get(x_90, 2);
lean_inc(x_93);
lean_dec(x_90);
x_94 = lean_string_utf8_extract(x_91, x_92, x_93);
lean_dec(x_93);
lean_dec(x_92);
lean_dec(x_91);
lean_ctor_set(x_19, 1, x_94);
lean_ctor_set(x_5, 0, x_88);
x_95 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_95, 0, x_5);
x_8 = x_95;
x_9 = x_7;
goto block_14;
}
else
{
lean_object* x_96; lean_object* x_97; 
lean_dec(x_89);
x_96 = l_ProofWidgets_instInhabitedHtml___closed__2;
lean_ctor_set(x_19, 1, x_96);
lean_ctor_set(x_5, 0, x_88);
x_97 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_97, 0, x_5);
x_8 = x_97;
x_9 = x_7;
goto block_14;
}
}
}
else
{
lean_object* x_98; lean_object* x_99; lean_object* x_100; uint8_t x_101; 
x_98 = lean_unsigned_to_nat(0u);
x_99 = l_Lean_Syntax_getArg(x_17, x_98);
x_100 = l_ProofWidgets_Jsx_jsxText___closed__2;
lean_inc(x_99);
x_101 = l_Lean_Syntax_isOfKind(x_99, x_100);
if (x_101 == 0)
{
lean_object* x_102; lean_object* x_103; uint8_t x_104; 
lean_dec(x_99);
lean_free_object(x_19);
lean_dec(x_23);
lean_dec(x_22);
lean_free_object(x_5);
lean_dec(x_21);
lean_dec(x_1);
x_102 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__1;
x_103 = l_Lean_Macro_throwErrorAt___rarg(x_17, x_102, x_6, x_7);
lean_dec(x_17);
x_104 = !lean_is_exclusive(x_103);
if (x_104 == 0)
{
return x_103;
}
else
{
lean_object* x_105; lean_object* x_106; lean_object* x_107; 
x_105 = lean_ctor_get(x_103, 0);
x_106 = lean_ctor_get(x_103, 1);
lean_inc(x_106);
lean_inc(x_105);
lean_dec(x_103);
x_107 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_107, 0, x_105);
lean_ctor_set(x_107, 1, x_106);
return x_107;
}
}
else
{
lean_object* x_108; uint8_t x_109; lean_object* x_110; lean_object* x_111; lean_object* x_112; lean_object* x_113; lean_object* x_114; lean_object* x_115; lean_object* x_116; lean_object* x_117; lean_object* x_118; lean_object* x_119; lean_object* x_120; lean_object* x_121; lean_object* x_122; lean_object* x_123; lean_object* x_124; lean_object* x_125; lean_object* x_126; lean_object* x_127; lean_object* x_128; 
lean_dec(x_17);
x_108 = lean_ctor_get(x_6, 5);
lean_inc(x_108);
x_109 = 0;
x_110 = l_Lean_SourceInfo_fromRef(x_108, x_109);
lean_dec(x_108);
x_111 = lean_ctor_get(x_6, 2);
lean_inc(x_111);
x_112 = lean_ctor_get(x_6, 1);
lean_inc(x_112);
x_113 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__14;
x_114 = l_Lean_addMacroScope(x_112, x_113, x_111);
x_115 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__12;
x_116 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__19;
lean_inc(x_110);
x_117 = lean_alloc_ctor(3, 4, 0);
lean_ctor_set(x_117, 0, x_110);
lean_ctor_set(x_117, 1, x_115);
lean_ctor_set(x_117, 2, x_114);
lean_ctor_set(x_117, 3, x_116);
x_118 = l_ProofWidgets_Jsx_getJsxText(x_99);
lean_dec(x_99);
x_119 = lean_string_append(x_23, x_118);
lean_dec(x_118);
x_120 = lean_box(2);
x_121 = l_Lean_Syntax_mkStrLit(x_119, x_120);
lean_dec(x_119);
x_122 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_110);
x_123 = l_Lean_Syntax_node1(x_110, x_122, x_121);
x_124 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__10;
x_125 = l_Lean_Syntax_node2(x_110, x_124, x_117, x_123);
x_126 = lean_array_push(x_21, x_125);
x_127 = l_ProofWidgets_instInhabitedHtml___closed__2;
lean_ctor_set(x_19, 1, x_127);
lean_ctor_set(x_5, 0, x_126);
x_128 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_128, 0, x_5);
x_8 = x_128;
x_9 = x_7;
goto block_14;
}
}
}
else
{
lean_object* x_129; lean_object* x_130; lean_object* x_131; lean_object* x_132; uint8_t x_133; 
x_129 = lean_ctor_get(x_5, 0);
x_130 = lean_ctor_get(x_19, 0);
x_131 = lean_ctor_get(x_19, 1);
lean_inc(x_131);
lean_inc(x_130);
lean_dec(x_19);
x_132 = l_ProofWidgets_Jsx_jsxChild_____closed__2;
lean_inc(x_17);
x_133 = l_Lean_Syntax_isOfKind(x_17, x_132);
if (x_133 == 0)
{
lean_object* x_134; uint8_t x_135; 
x_134 = l_ProofWidgets_Jsx_jsxChild_x7b___x7d___closed__2;
lean_inc(x_17);
x_135 = l_Lean_Syntax_isOfKind(x_17, x_134);
if (x_135 == 0)
{
lean_object* x_136; uint8_t x_137; 
x_136 = l_ProofWidgets_Jsx_jsxChild____1___closed__2;
lean_inc(x_17);
x_137 = l_Lean_Syntax_isOfKind(x_17, x_136);
if (x_137 == 0)
{
lean_object* x_138; uint8_t x_139; 
lean_free_object(x_5);
x_138 = l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__2;
lean_inc(x_17);
x_139 = l_Lean_Syntax_isOfKind(x_17, x_138);
if (x_139 == 0)
{
lean_object* x_140; lean_object* x_141; lean_object* x_142; lean_object* x_143; lean_object* x_144; lean_object* x_145; 
lean_dec(x_131);
lean_dec(x_130);
lean_dec(x_129);
lean_dec(x_1);
x_140 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__1;
x_141 = l_Lean_Macro_throwErrorAt___rarg(x_17, x_140, x_6, x_7);
lean_dec(x_17);
x_142 = lean_ctor_get(x_141, 0);
lean_inc(x_142);
x_143 = lean_ctor_get(x_141, 1);
lean_inc(x_143);
if (lean_is_exclusive(x_141)) {
 lean_ctor_release(x_141, 0);
 lean_ctor_release(x_141, 1);
 x_144 = x_141;
} else {
 lean_dec_ref(x_141);
 x_144 = lean_box(0);
}
if (lean_is_scalar(x_144)) {
 x_145 = lean_alloc_ctor(1, 2, 0);
} else {
 x_145 = x_144;
}
lean_ctor_set(x_145, 0, x_142);
lean_ctor_set(x_145, 1, x_143);
return x_145;
}
else
{
lean_object* x_146; lean_object* x_147; lean_object* x_148; lean_object* x_149; uint8_t x_150; 
x_146 = lean_unsigned_to_nat(1u);
x_147 = l_Lean_Syntax_getArg(x_17, x_146);
x_148 = lean_unsigned_to_nat(2u);
x_149 = l_Lean_Syntax_getArg(x_17, x_148);
lean_dec(x_17);
x_150 = l_Array_isEmpty___rarg(x_129);
if (x_150 == 0)
{
lean_object* x_151; uint8_t x_152; lean_object* x_153; lean_object* x_154; lean_object* x_155; lean_object* x_156; lean_object* x_157; lean_object* x_158; lean_object* x_159; lean_object* x_160; lean_object* x_161; lean_object* x_162; lean_object* x_163; lean_object* x_164; lean_object* x_165; lean_object* x_166; lean_object* x_167; lean_object* x_168; lean_object* x_169; lean_object* x_170; 
x_151 = lean_ctor_get(x_6, 5);
lean_inc(x_151);
x_152 = 0;
x_153 = l_Lean_SourceInfo_fromRef(x_151, x_152);
lean_dec(x_151);
x_154 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__4;
lean_inc(x_153);
x_155 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_155, 0, x_153);
lean_ctor_set(x_155, 1, x_154);
x_156 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__7;
x_157 = l_Lean_Syntax_SepArray_ofElems(x_156, x_129);
x_158 = l_ProofWidgets_instInhabitedHtml___closed__1;
x_159 = l_Array_append___rarg(x_158, x_157);
lean_dec(x_157);
x_160 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_153);
x_161 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_161, 0, x_153);
lean_ctor_set(x_161, 1, x_160);
lean_ctor_set(x_161, 2, x_159);
x_162 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__8;
lean_inc(x_153);
x_163 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_163, 0, x_153);
lean_ctor_set(x_163, 1, x_162);
x_164 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__3;
x_165 = l_Lean_Syntax_node3(x_153, x_164, x_155, x_161, x_163);
x_166 = lean_array_push(x_130, x_165);
x_167 = lean_box(0);
lean_inc(x_1);
x_168 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___lambda__1(x_147, x_149, x_1, x_129, x_166, x_131, x_167, x_6, x_7);
lean_dec(x_131);
lean_dec(x_129);
lean_dec(x_149);
x_169 = lean_ctor_get(x_168, 0);
lean_inc(x_169);
x_170 = lean_ctor_get(x_168, 1);
lean_inc(x_170);
lean_dec(x_168);
x_8 = x_169;
x_9 = x_170;
goto block_14;
}
else
{
lean_object* x_171; lean_object* x_172; lean_object* x_173; lean_object* x_174; 
x_171 = lean_box(0);
lean_inc(x_1);
x_172 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___lambda__1(x_147, x_149, x_1, x_129, x_130, x_131, x_171, x_6, x_7);
lean_dec(x_131);
lean_dec(x_129);
lean_dec(x_149);
x_173 = lean_ctor_get(x_172, 0);
lean_inc(x_173);
x_174 = lean_ctor_get(x_172, 1);
lean_inc(x_174);
lean_dec(x_172);
x_8 = x_173;
x_9 = x_174;
goto block_14;
}
}
}
else
{
lean_object* x_175; lean_object* x_176; lean_object* x_177; uint8_t x_178; lean_object* x_179; lean_object* x_180; lean_object* x_181; lean_object* x_182; lean_object* x_183; 
lean_dec(x_131);
x_175 = lean_unsigned_to_nat(0u);
x_176 = l_Lean_Syntax_getArg(x_17, x_175);
lean_dec(x_17);
x_177 = lean_ctor_get(x_6, 5);
lean_inc(x_177);
x_178 = 0;
x_179 = l_Lean_SourceInfo_fromRef(x_177, x_178);
lean_dec(x_177);
x_180 = l_ProofWidgets_Jsx_term_____closed__2;
lean_inc(x_176);
x_181 = l_Lean_Syntax_node1(x_179, x_180, x_176);
x_182 = lean_array_push(x_129, x_181);
x_183 = l_Lean_Syntax_getTailInfo(x_176);
lean_dec(x_176);
if (lean_obj_tag(x_183) == 0)
{
lean_object* x_184; lean_object* x_185; lean_object* x_186; lean_object* x_187; lean_object* x_188; lean_object* x_189; lean_object* x_190; 
x_184 = lean_ctor_get(x_183, 2);
lean_inc(x_184);
lean_dec(x_183);
x_185 = lean_ctor_get(x_184, 0);
lean_inc(x_185);
x_186 = lean_ctor_get(x_184, 1);
lean_inc(x_186);
x_187 = lean_ctor_get(x_184, 2);
lean_inc(x_187);
lean_dec(x_184);
x_188 = lean_string_utf8_extract(x_185, x_186, x_187);
lean_dec(x_187);
lean_dec(x_186);
lean_dec(x_185);
x_189 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_189, 0, x_130);
lean_ctor_set(x_189, 1, x_188);
lean_ctor_set(x_5, 1, x_189);
lean_ctor_set(x_5, 0, x_182);
x_190 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_190, 0, x_5);
x_8 = x_190;
x_9 = x_7;
goto block_14;
}
else
{
lean_object* x_191; lean_object* x_192; lean_object* x_193; 
lean_dec(x_183);
x_191 = l_ProofWidgets_instInhabitedHtml___closed__2;
x_192 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_192, 0, x_130);
lean_ctor_set(x_192, 1, x_191);
lean_ctor_set(x_5, 1, x_192);
lean_ctor_set(x_5, 0, x_182);
x_193 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_193, 0, x_5);
x_8 = x_193;
x_9 = x_7;
goto block_14;
}
}
}
else
{
lean_object* x_194; lean_object* x_195; lean_object* x_196; lean_object* x_197; lean_object* x_198; lean_object* x_199; 
lean_dec(x_131);
x_194 = lean_unsigned_to_nat(1u);
x_195 = l_Lean_Syntax_getArg(x_17, x_194);
x_196 = lean_unsigned_to_nat(2u);
x_197 = l_Lean_Syntax_getArg(x_17, x_196);
lean_dec(x_17);
x_198 = lean_array_push(x_129, x_195);
x_199 = l_Lean_Syntax_getTailInfo(x_197);
lean_dec(x_197);
if (lean_obj_tag(x_199) == 0)
{
lean_object* x_200; lean_object* x_201; lean_object* x_202; lean_object* x_203; lean_object* x_204; lean_object* x_205; lean_object* x_206; 
x_200 = lean_ctor_get(x_199, 2);
lean_inc(x_200);
lean_dec(x_199);
x_201 = lean_ctor_get(x_200, 0);
lean_inc(x_201);
x_202 = lean_ctor_get(x_200, 1);
lean_inc(x_202);
x_203 = lean_ctor_get(x_200, 2);
lean_inc(x_203);
lean_dec(x_200);
x_204 = lean_string_utf8_extract(x_201, x_202, x_203);
lean_dec(x_203);
lean_dec(x_202);
lean_dec(x_201);
x_205 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_205, 0, x_130);
lean_ctor_set(x_205, 1, x_204);
lean_ctor_set(x_5, 1, x_205);
lean_ctor_set(x_5, 0, x_198);
x_206 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_206, 0, x_5);
x_8 = x_206;
x_9 = x_7;
goto block_14;
}
else
{
lean_object* x_207; lean_object* x_208; lean_object* x_209; 
lean_dec(x_199);
x_207 = l_ProofWidgets_instInhabitedHtml___closed__2;
x_208 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_208, 0, x_130);
lean_ctor_set(x_208, 1, x_207);
lean_ctor_set(x_5, 1, x_208);
lean_ctor_set(x_5, 0, x_198);
x_209 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_209, 0, x_5);
x_8 = x_209;
x_9 = x_7;
goto block_14;
}
}
}
else
{
lean_object* x_210; lean_object* x_211; lean_object* x_212; uint8_t x_213; 
x_210 = lean_unsigned_to_nat(0u);
x_211 = l_Lean_Syntax_getArg(x_17, x_210);
x_212 = l_ProofWidgets_Jsx_jsxText___closed__2;
lean_inc(x_211);
x_213 = l_Lean_Syntax_isOfKind(x_211, x_212);
if (x_213 == 0)
{
lean_object* x_214; lean_object* x_215; lean_object* x_216; lean_object* x_217; lean_object* x_218; lean_object* x_219; 
lean_dec(x_211);
lean_dec(x_131);
lean_dec(x_130);
lean_free_object(x_5);
lean_dec(x_129);
lean_dec(x_1);
x_214 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__1;
x_215 = l_Lean_Macro_throwErrorAt___rarg(x_17, x_214, x_6, x_7);
lean_dec(x_17);
x_216 = lean_ctor_get(x_215, 0);
lean_inc(x_216);
x_217 = lean_ctor_get(x_215, 1);
lean_inc(x_217);
if (lean_is_exclusive(x_215)) {
 lean_ctor_release(x_215, 0);
 lean_ctor_release(x_215, 1);
 x_218 = x_215;
} else {
 lean_dec_ref(x_215);
 x_218 = lean_box(0);
}
if (lean_is_scalar(x_218)) {
 x_219 = lean_alloc_ctor(1, 2, 0);
} else {
 x_219 = x_218;
}
lean_ctor_set(x_219, 0, x_216);
lean_ctor_set(x_219, 1, x_217);
return x_219;
}
else
{
lean_object* x_220; uint8_t x_221; lean_object* x_222; lean_object* x_223; lean_object* x_224; lean_object* x_225; lean_object* x_226; lean_object* x_227; lean_object* x_228; lean_object* x_229; lean_object* x_230; lean_object* x_231; lean_object* x_232; lean_object* x_233; lean_object* x_234; lean_object* x_235; lean_object* x_236; lean_object* x_237; lean_object* x_238; lean_object* x_239; lean_object* x_240; lean_object* x_241; 
lean_dec(x_17);
x_220 = lean_ctor_get(x_6, 5);
lean_inc(x_220);
x_221 = 0;
x_222 = l_Lean_SourceInfo_fromRef(x_220, x_221);
lean_dec(x_220);
x_223 = lean_ctor_get(x_6, 2);
lean_inc(x_223);
x_224 = lean_ctor_get(x_6, 1);
lean_inc(x_224);
x_225 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__14;
x_226 = l_Lean_addMacroScope(x_224, x_225, x_223);
x_227 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__12;
x_228 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__19;
lean_inc(x_222);
x_229 = lean_alloc_ctor(3, 4, 0);
lean_ctor_set(x_229, 0, x_222);
lean_ctor_set(x_229, 1, x_227);
lean_ctor_set(x_229, 2, x_226);
lean_ctor_set(x_229, 3, x_228);
x_230 = l_ProofWidgets_Jsx_getJsxText(x_211);
lean_dec(x_211);
x_231 = lean_string_append(x_131, x_230);
lean_dec(x_230);
x_232 = lean_box(2);
x_233 = l_Lean_Syntax_mkStrLit(x_231, x_232);
lean_dec(x_231);
x_234 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_222);
x_235 = l_Lean_Syntax_node1(x_222, x_234, x_233);
x_236 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__10;
x_237 = l_Lean_Syntax_node2(x_222, x_236, x_229, x_235);
x_238 = lean_array_push(x_129, x_237);
x_239 = l_ProofWidgets_instInhabitedHtml___closed__2;
x_240 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_240, 0, x_130);
lean_ctor_set(x_240, 1, x_239);
lean_ctor_set(x_5, 1, x_240);
lean_ctor_set(x_5, 0, x_238);
x_241 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_241, 0, x_5);
x_8 = x_241;
x_9 = x_7;
goto block_14;
}
}
}
}
else
{
lean_object* x_242; lean_object* x_243; lean_object* x_244; lean_object* x_245; lean_object* x_246; lean_object* x_247; uint8_t x_248; 
x_242 = lean_ctor_get(x_5, 1);
x_243 = lean_ctor_get(x_5, 0);
lean_inc(x_242);
lean_inc(x_243);
lean_dec(x_5);
x_244 = lean_ctor_get(x_242, 0);
lean_inc(x_244);
x_245 = lean_ctor_get(x_242, 1);
lean_inc(x_245);
if (lean_is_exclusive(x_242)) {
 lean_ctor_release(x_242, 0);
 lean_ctor_release(x_242, 1);
 x_246 = x_242;
} else {
 lean_dec_ref(x_242);
 x_246 = lean_box(0);
}
x_247 = l_ProofWidgets_Jsx_jsxChild_____closed__2;
lean_inc(x_17);
x_248 = l_Lean_Syntax_isOfKind(x_17, x_247);
if (x_248 == 0)
{
lean_object* x_249; uint8_t x_250; 
x_249 = l_ProofWidgets_Jsx_jsxChild_x7b___x7d___closed__2;
lean_inc(x_17);
x_250 = l_Lean_Syntax_isOfKind(x_17, x_249);
if (x_250 == 0)
{
lean_object* x_251; uint8_t x_252; 
x_251 = l_ProofWidgets_Jsx_jsxChild____1___closed__2;
lean_inc(x_17);
x_252 = l_Lean_Syntax_isOfKind(x_17, x_251);
if (x_252 == 0)
{
lean_object* x_253; uint8_t x_254; 
lean_dec(x_246);
x_253 = l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__2;
lean_inc(x_17);
x_254 = l_Lean_Syntax_isOfKind(x_17, x_253);
if (x_254 == 0)
{
lean_object* x_255; lean_object* x_256; lean_object* x_257; lean_object* x_258; lean_object* x_259; lean_object* x_260; 
lean_dec(x_245);
lean_dec(x_244);
lean_dec(x_243);
lean_dec(x_1);
x_255 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__1;
x_256 = l_Lean_Macro_throwErrorAt___rarg(x_17, x_255, x_6, x_7);
lean_dec(x_17);
x_257 = lean_ctor_get(x_256, 0);
lean_inc(x_257);
x_258 = lean_ctor_get(x_256, 1);
lean_inc(x_258);
if (lean_is_exclusive(x_256)) {
 lean_ctor_release(x_256, 0);
 lean_ctor_release(x_256, 1);
 x_259 = x_256;
} else {
 lean_dec_ref(x_256);
 x_259 = lean_box(0);
}
if (lean_is_scalar(x_259)) {
 x_260 = lean_alloc_ctor(1, 2, 0);
} else {
 x_260 = x_259;
}
lean_ctor_set(x_260, 0, x_257);
lean_ctor_set(x_260, 1, x_258);
return x_260;
}
else
{
lean_object* x_261; lean_object* x_262; lean_object* x_263; lean_object* x_264; uint8_t x_265; 
x_261 = lean_unsigned_to_nat(1u);
x_262 = l_Lean_Syntax_getArg(x_17, x_261);
x_263 = lean_unsigned_to_nat(2u);
x_264 = l_Lean_Syntax_getArg(x_17, x_263);
lean_dec(x_17);
x_265 = l_Array_isEmpty___rarg(x_243);
if (x_265 == 0)
{
lean_object* x_266; uint8_t x_267; lean_object* x_268; lean_object* x_269; lean_object* x_270; lean_object* x_271; lean_object* x_272; lean_object* x_273; lean_object* x_274; lean_object* x_275; lean_object* x_276; lean_object* x_277; lean_object* x_278; lean_object* x_279; lean_object* x_280; lean_object* x_281; lean_object* x_282; lean_object* x_283; lean_object* x_284; lean_object* x_285; 
x_266 = lean_ctor_get(x_6, 5);
lean_inc(x_266);
x_267 = 0;
x_268 = l_Lean_SourceInfo_fromRef(x_266, x_267);
lean_dec(x_266);
x_269 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__4;
lean_inc(x_268);
x_270 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_270, 0, x_268);
lean_ctor_set(x_270, 1, x_269);
x_271 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__7;
x_272 = l_Lean_Syntax_SepArray_ofElems(x_271, x_243);
x_273 = l_ProofWidgets_instInhabitedHtml___closed__1;
x_274 = l_Array_append___rarg(x_273, x_272);
lean_dec(x_272);
x_275 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_268);
x_276 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_276, 0, x_268);
lean_ctor_set(x_276, 1, x_275);
lean_ctor_set(x_276, 2, x_274);
x_277 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__8;
lean_inc(x_268);
x_278 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_278, 0, x_268);
lean_ctor_set(x_278, 1, x_277);
x_279 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__3;
x_280 = l_Lean_Syntax_node3(x_268, x_279, x_270, x_276, x_278);
x_281 = lean_array_push(x_244, x_280);
x_282 = lean_box(0);
lean_inc(x_1);
x_283 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___lambda__1(x_262, x_264, x_1, x_243, x_281, x_245, x_282, x_6, x_7);
lean_dec(x_245);
lean_dec(x_243);
lean_dec(x_264);
x_284 = lean_ctor_get(x_283, 0);
lean_inc(x_284);
x_285 = lean_ctor_get(x_283, 1);
lean_inc(x_285);
lean_dec(x_283);
x_8 = x_284;
x_9 = x_285;
goto block_14;
}
else
{
lean_object* x_286; lean_object* x_287; lean_object* x_288; lean_object* x_289; 
x_286 = lean_box(0);
lean_inc(x_1);
x_287 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___lambda__1(x_262, x_264, x_1, x_243, x_244, x_245, x_286, x_6, x_7);
lean_dec(x_245);
lean_dec(x_243);
lean_dec(x_264);
x_288 = lean_ctor_get(x_287, 0);
lean_inc(x_288);
x_289 = lean_ctor_get(x_287, 1);
lean_inc(x_289);
lean_dec(x_287);
x_8 = x_288;
x_9 = x_289;
goto block_14;
}
}
}
else
{
lean_object* x_290; lean_object* x_291; lean_object* x_292; uint8_t x_293; lean_object* x_294; lean_object* x_295; lean_object* x_296; lean_object* x_297; lean_object* x_298; 
lean_dec(x_245);
x_290 = lean_unsigned_to_nat(0u);
x_291 = l_Lean_Syntax_getArg(x_17, x_290);
lean_dec(x_17);
x_292 = lean_ctor_get(x_6, 5);
lean_inc(x_292);
x_293 = 0;
x_294 = l_Lean_SourceInfo_fromRef(x_292, x_293);
lean_dec(x_292);
x_295 = l_ProofWidgets_Jsx_term_____closed__2;
lean_inc(x_291);
x_296 = l_Lean_Syntax_node1(x_294, x_295, x_291);
x_297 = lean_array_push(x_243, x_296);
x_298 = l_Lean_Syntax_getTailInfo(x_291);
lean_dec(x_291);
if (lean_obj_tag(x_298) == 0)
{
lean_object* x_299; lean_object* x_300; lean_object* x_301; lean_object* x_302; lean_object* x_303; lean_object* x_304; lean_object* x_305; lean_object* x_306; 
x_299 = lean_ctor_get(x_298, 2);
lean_inc(x_299);
lean_dec(x_298);
x_300 = lean_ctor_get(x_299, 0);
lean_inc(x_300);
x_301 = lean_ctor_get(x_299, 1);
lean_inc(x_301);
x_302 = lean_ctor_get(x_299, 2);
lean_inc(x_302);
lean_dec(x_299);
x_303 = lean_string_utf8_extract(x_300, x_301, x_302);
lean_dec(x_302);
lean_dec(x_301);
lean_dec(x_300);
if (lean_is_scalar(x_246)) {
 x_304 = lean_alloc_ctor(0, 2, 0);
} else {
 x_304 = x_246;
}
lean_ctor_set(x_304, 0, x_244);
lean_ctor_set(x_304, 1, x_303);
x_305 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_305, 0, x_297);
lean_ctor_set(x_305, 1, x_304);
x_306 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_306, 0, x_305);
x_8 = x_306;
x_9 = x_7;
goto block_14;
}
else
{
lean_object* x_307; lean_object* x_308; lean_object* x_309; lean_object* x_310; 
lean_dec(x_298);
x_307 = l_ProofWidgets_instInhabitedHtml___closed__2;
if (lean_is_scalar(x_246)) {
 x_308 = lean_alloc_ctor(0, 2, 0);
} else {
 x_308 = x_246;
}
lean_ctor_set(x_308, 0, x_244);
lean_ctor_set(x_308, 1, x_307);
x_309 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_309, 0, x_297);
lean_ctor_set(x_309, 1, x_308);
x_310 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_310, 0, x_309);
x_8 = x_310;
x_9 = x_7;
goto block_14;
}
}
}
else
{
lean_object* x_311; lean_object* x_312; lean_object* x_313; lean_object* x_314; lean_object* x_315; lean_object* x_316; 
lean_dec(x_245);
x_311 = lean_unsigned_to_nat(1u);
x_312 = l_Lean_Syntax_getArg(x_17, x_311);
x_313 = lean_unsigned_to_nat(2u);
x_314 = l_Lean_Syntax_getArg(x_17, x_313);
lean_dec(x_17);
x_315 = lean_array_push(x_243, x_312);
x_316 = l_Lean_Syntax_getTailInfo(x_314);
lean_dec(x_314);
if (lean_obj_tag(x_316) == 0)
{
lean_object* x_317; lean_object* x_318; lean_object* x_319; lean_object* x_320; lean_object* x_321; lean_object* x_322; lean_object* x_323; lean_object* x_324; 
x_317 = lean_ctor_get(x_316, 2);
lean_inc(x_317);
lean_dec(x_316);
x_318 = lean_ctor_get(x_317, 0);
lean_inc(x_318);
x_319 = lean_ctor_get(x_317, 1);
lean_inc(x_319);
x_320 = lean_ctor_get(x_317, 2);
lean_inc(x_320);
lean_dec(x_317);
x_321 = lean_string_utf8_extract(x_318, x_319, x_320);
lean_dec(x_320);
lean_dec(x_319);
lean_dec(x_318);
if (lean_is_scalar(x_246)) {
 x_322 = lean_alloc_ctor(0, 2, 0);
} else {
 x_322 = x_246;
}
lean_ctor_set(x_322, 0, x_244);
lean_ctor_set(x_322, 1, x_321);
x_323 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_323, 0, x_315);
lean_ctor_set(x_323, 1, x_322);
x_324 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_324, 0, x_323);
x_8 = x_324;
x_9 = x_7;
goto block_14;
}
else
{
lean_object* x_325; lean_object* x_326; lean_object* x_327; lean_object* x_328; 
lean_dec(x_316);
x_325 = l_ProofWidgets_instInhabitedHtml___closed__2;
if (lean_is_scalar(x_246)) {
 x_326 = lean_alloc_ctor(0, 2, 0);
} else {
 x_326 = x_246;
}
lean_ctor_set(x_326, 0, x_244);
lean_ctor_set(x_326, 1, x_325);
x_327 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_327, 0, x_315);
lean_ctor_set(x_327, 1, x_326);
x_328 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_328, 0, x_327);
x_8 = x_328;
x_9 = x_7;
goto block_14;
}
}
}
else
{
lean_object* x_329; lean_object* x_330; lean_object* x_331; uint8_t x_332; 
x_329 = lean_unsigned_to_nat(0u);
x_330 = l_Lean_Syntax_getArg(x_17, x_329);
x_331 = l_ProofWidgets_Jsx_jsxText___closed__2;
lean_inc(x_330);
x_332 = l_Lean_Syntax_isOfKind(x_330, x_331);
if (x_332 == 0)
{
lean_object* x_333; lean_object* x_334; lean_object* x_335; lean_object* x_336; lean_object* x_337; lean_object* x_338; 
lean_dec(x_330);
lean_dec(x_246);
lean_dec(x_245);
lean_dec(x_244);
lean_dec(x_243);
lean_dec(x_1);
x_333 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__1;
x_334 = l_Lean_Macro_throwErrorAt___rarg(x_17, x_333, x_6, x_7);
lean_dec(x_17);
x_335 = lean_ctor_get(x_334, 0);
lean_inc(x_335);
x_336 = lean_ctor_get(x_334, 1);
lean_inc(x_336);
if (lean_is_exclusive(x_334)) {
 lean_ctor_release(x_334, 0);
 lean_ctor_release(x_334, 1);
 x_337 = x_334;
} else {
 lean_dec_ref(x_334);
 x_337 = lean_box(0);
}
if (lean_is_scalar(x_337)) {
 x_338 = lean_alloc_ctor(1, 2, 0);
} else {
 x_338 = x_337;
}
lean_ctor_set(x_338, 0, x_335);
lean_ctor_set(x_338, 1, x_336);
return x_338;
}
else
{
lean_object* x_339; uint8_t x_340; lean_object* x_341; lean_object* x_342; lean_object* x_343; lean_object* x_344; lean_object* x_345; lean_object* x_346; lean_object* x_347; lean_object* x_348; lean_object* x_349; lean_object* x_350; lean_object* x_351; lean_object* x_352; lean_object* x_353; lean_object* x_354; lean_object* x_355; lean_object* x_356; lean_object* x_357; lean_object* x_358; lean_object* x_359; lean_object* x_360; lean_object* x_361; 
lean_dec(x_17);
x_339 = lean_ctor_get(x_6, 5);
lean_inc(x_339);
x_340 = 0;
x_341 = l_Lean_SourceInfo_fromRef(x_339, x_340);
lean_dec(x_339);
x_342 = lean_ctor_get(x_6, 2);
lean_inc(x_342);
x_343 = lean_ctor_get(x_6, 1);
lean_inc(x_343);
x_344 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__14;
x_345 = l_Lean_addMacroScope(x_343, x_344, x_342);
x_346 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__12;
x_347 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__19;
lean_inc(x_341);
x_348 = lean_alloc_ctor(3, 4, 0);
lean_ctor_set(x_348, 0, x_341);
lean_ctor_set(x_348, 1, x_346);
lean_ctor_set(x_348, 2, x_345);
lean_ctor_set(x_348, 3, x_347);
x_349 = l_ProofWidgets_Jsx_getJsxText(x_330);
lean_dec(x_330);
x_350 = lean_string_append(x_245, x_349);
lean_dec(x_349);
x_351 = lean_box(2);
x_352 = l_Lean_Syntax_mkStrLit(x_350, x_351);
lean_dec(x_350);
x_353 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_341);
x_354 = l_Lean_Syntax_node1(x_341, x_353, x_352);
x_355 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__10;
x_356 = l_Lean_Syntax_node2(x_341, x_355, x_348, x_354);
x_357 = lean_array_push(x_243, x_356);
x_358 = l_ProofWidgets_instInhabitedHtml___closed__2;
if (lean_is_scalar(x_246)) {
 x_359 = lean_alloc_ctor(0, 2, 0);
} else {
 x_359 = x_246;
}
lean_ctor_set(x_359, 0, x_244);
lean_ctor_set(x_359, 1, x_358);
x_360 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_360, 0, x_357);
lean_ctor_set(x_360, 1, x_359);
x_361 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_361, 0, x_360);
x_8 = x_361;
x_9 = x_7;
goto block_14;
}
}
}
}
block_14:
{
lean_object* x_10; size_t x_11; size_t x_12; 
x_10 = lean_ctor_get(x_8, 0);
lean_inc(x_10);
lean_dec(x_8);
x_11 = 1;
x_12 = lean_usize_add(x_4, x_11);
x_4 = x_12;
x_5 = x_10;
x_7 = x_9;
goto _start;
}
}
}
static lean_object* _init_l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__3___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("term_++_", 8, 8);
return x_1;
}
}
static lean_object* _init_l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__3___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__3___closed__1;
x_3 = l_Lean_Name_str___override(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__3___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("++", 2, 2);
return x_1;
}
}
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__3(lean_object* x_1, size_t x_2, size_t x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
uint8_t x_7; 
x_7 = lean_usize_dec_eq(x_2, x_3);
if (x_7 == 0)
{
lean_object* x_8; lean_object* x_9; uint8_t x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; size_t x_16; size_t x_17; 
x_8 = lean_array_uget(x_1, x_2);
x_9 = lean_ctor_get(x_5, 5);
x_10 = 0;
x_11 = l_Lean_SourceInfo_fromRef(x_9, x_10);
x_12 = l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__3___closed__3;
lean_inc(x_11);
x_13 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_13, 0, x_11);
lean_ctor_set(x_13, 1, x_12);
x_14 = l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__3___closed__2;
x_15 = l_Lean_Syntax_node3(x_11, x_14, x_4, x_13, x_8);
x_16 = 1;
x_17 = lean_usize_add(x_2, x_16);
x_2 = x_17;
x_4 = x_15;
goto _start;
}
else
{
lean_object* x_19; 
x_19 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_19, 0, x_4);
lean_ctor_set(x_19, 1, x_6);
return x_19;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___at_ProofWidgets_Jsx_transformTag___spec__2(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; lean_object* x_5; uint8_t x_6; 
x_4 = lean_array_get_size(x_1);
x_5 = lean_unsigned_to_nat(0u);
x_6 = lean_nat_dec_lt(x_5, x_4);
if (x_6 == 0)
{
lean_object* x_7; uint8_t x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; 
lean_dec(x_4);
x_7 = lean_ctor_get(x_2, 5);
x_8 = 0;
x_9 = l_Lean_SourceInfo_fromRef(x_7, x_8);
x_10 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__4;
lean_inc(x_9);
x_11 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_11, 0, x_9);
lean_ctor_set(x_11, 1, x_10);
x_12 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
x_13 = l_ProofWidgets_instInhabitedHtml___closed__1;
lean_inc(x_9);
x_14 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_14, 0, x_9);
lean_ctor_set(x_14, 1, x_12);
lean_ctor_set(x_14, 2, x_13);
x_15 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__8;
lean_inc(x_9);
x_16 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_16, 0, x_9);
lean_ctor_set(x_16, 1, x_15);
x_17 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__3;
x_18 = l_Lean_Syntax_node3(x_9, x_17, x_11, x_14, x_16);
x_19 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_19, 0, x_18);
lean_ctor_set(x_19, 1, x_3);
return x_19;
}
else
{
lean_object* x_20; lean_object* x_21; uint8_t x_22; 
x_20 = lean_array_fget(x_1, x_5);
x_21 = lean_unsigned_to_nat(1u);
x_22 = lean_nat_dec_lt(x_21, x_4);
if (x_22 == 0)
{
lean_object* x_23; 
lean_dec(x_4);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_20);
lean_ctor_set(x_23, 1, x_3);
return x_23;
}
else
{
uint8_t x_24; 
x_24 = lean_nat_dec_le(x_4, x_4);
if (x_24 == 0)
{
lean_object* x_25; 
lean_dec(x_4);
x_25 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_25, 0, x_20);
lean_ctor_set(x_25, 1, x_3);
return x_25;
}
else
{
size_t x_26; size_t x_27; lean_object* x_28; 
x_26 = 1;
x_27 = lean_usize_of_nat(x_4);
lean_dec(x_4);
x_28 = l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__3(x_1, x_26, x_27, x_20, x_2, x_3);
return x_28;
}
}
}
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__4(size_t x_1, size_t x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
uint8_t x_6; 
x_6 = lean_usize_dec_lt(x_2, x_1);
if (x_6 == 0)
{
lean_object* x_7; 
lean_dec(x_4);
x_7 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_7, 0, x_3);
lean_ctor_set(x_7, 1, x_5);
return x_7;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_18; uint8_t x_19; 
x_8 = lean_array_uget(x_3, x_2);
x_9 = lean_unsigned_to_nat(0u);
x_10 = lean_array_uset(x_3, x_2, x_9);
x_18 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
lean_inc(x_8);
x_19 = l_Lean_Syntax_isOfKind(x_8, x_18);
if (x_19 == 0)
{
lean_object* x_20; uint8_t x_21; 
x_20 = l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__2;
lean_inc(x_8);
x_21 = l_Lean_Syntax_isOfKind(x_8, x_20);
if (x_21 == 0)
{
lean_object* x_22; lean_object* x_23; uint8_t x_24; 
lean_dec(x_10);
x_22 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__1;
x_23 = l_Lean_Macro_throwErrorAt___rarg(x_8, x_22, x_4, x_5);
lean_dec(x_8);
x_24 = !lean_is_exclusive(x_23);
if (x_24 == 0)
{
return x_23;
}
else
{
lean_object* x_25; lean_object* x_26; lean_object* x_27; 
x_25 = lean_ctor_get(x_23, 0);
x_26 = lean_ctor_get(x_23, 1);
lean_inc(x_26);
lean_inc(x_25);
lean_dec(x_23);
x_27 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_27, 0, x_25);
lean_ctor_set(x_27, 1, x_26);
return x_27;
}
}
else
{
lean_object* x_28; lean_object* x_29; uint8_t x_30; 
x_28 = l_Lean_Syntax_getArg(x_8, x_9);
x_29 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_28);
x_30 = l_Lean_Syntax_isOfKind(x_28, x_29);
if (x_30 == 0)
{
lean_object* x_31; lean_object* x_32; uint8_t x_33; 
lean_dec(x_28);
lean_dec(x_10);
x_31 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__1;
x_32 = l_Lean_Macro_throwErrorAt___rarg(x_8, x_31, x_4, x_5);
lean_dec(x_8);
x_33 = !lean_is_exclusive(x_32);
if (x_33 == 0)
{
return x_32;
}
else
{
lean_object* x_34; lean_object* x_35; lean_object* x_36; 
x_34 = lean_ctor_get(x_32, 0);
x_35 = lean_ctor_get(x_32, 1);
lean_inc(x_35);
lean_inc(x_34);
lean_dec(x_32);
x_36 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_36, 0, x_34);
lean_ctor_set(x_36, 1, x_35);
return x_36;
}
}
else
{
lean_object* x_37; lean_object* x_38; lean_object* x_39; 
lean_dec(x_8);
x_37 = lean_unsigned_to_nat(1u);
x_38 = l_Lean_Syntax_getArg(x_28, x_37);
lean_dec(x_28);
x_39 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_39, 0, x_38);
x_11 = x_39;
x_12 = x_5;
goto block_17;
}
}
}
else
{
lean_object* x_40; lean_object* x_41; uint8_t x_42; 
x_40 = l_Lean_Syntax_getArg(x_8, x_9);
x_41 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__4;
lean_inc(x_40);
x_42 = l_Lean_Syntax_isOfKind(x_40, x_41);
if (x_42 == 0)
{
lean_object* x_43; lean_object* x_44; uint8_t x_45; 
lean_dec(x_40);
lean_dec(x_10);
x_43 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__1;
x_44 = l_Lean_Macro_throwErrorAt___rarg(x_8, x_43, x_4, x_5);
lean_dec(x_8);
x_45 = !lean_is_exclusive(x_44);
if (x_45 == 0)
{
return x_44;
}
else
{
lean_object* x_46; lean_object* x_47; lean_object* x_48; 
x_46 = lean_ctor_get(x_44, 0);
x_47 = lean_ctor_get(x_44, 1);
lean_inc(x_47);
lean_inc(x_46);
lean_dec(x_44);
x_48 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_48, 0, x_46);
lean_ctor_set(x_48, 1, x_47);
return x_48;
}
}
else
{
lean_object* x_49; lean_object* x_50; lean_object* x_51; uint8_t x_52; 
x_49 = lean_unsigned_to_nat(2u);
x_50 = l_Lean_Syntax_getArg(x_8, x_49);
x_51 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__4;
lean_inc(x_50);
x_52 = l_Lean_Syntax_isOfKind(x_50, x_51);
if (x_52 == 0)
{
lean_object* x_53; uint8_t x_54; 
x_53 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2;
lean_inc(x_50);
x_54 = l_Lean_Syntax_isOfKind(x_50, x_53);
if (x_54 == 0)
{
lean_object* x_55; lean_object* x_56; uint8_t x_57; 
lean_dec(x_50);
lean_dec(x_40);
lean_dec(x_10);
x_55 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__1;
x_56 = l_Lean_Macro_throwErrorAt___rarg(x_8, x_55, x_4, x_5);
lean_dec(x_8);
x_57 = !lean_is_exclusive(x_56);
if (x_57 == 0)
{
return x_56;
}
else
{
lean_object* x_58; lean_object* x_59; lean_object* x_60; 
x_58 = lean_ctor_get(x_56, 0);
x_59 = lean_ctor_get(x_56, 1);
lean_inc(x_59);
lean_inc(x_58);
lean_dec(x_56);
x_60 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_60, 0, x_58);
lean_ctor_set(x_60, 1, x_59);
return x_60;
}
}
else
{
lean_object* x_61; lean_object* x_62; uint8_t x_63; 
x_61 = l_Lean_Syntax_getArg(x_50, x_9);
lean_dec(x_50);
x_62 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_61);
x_63 = l_Lean_Syntax_isOfKind(x_61, x_62);
if (x_63 == 0)
{
lean_object* x_64; lean_object* x_65; uint8_t x_66; 
lean_dec(x_61);
lean_dec(x_40);
lean_dec(x_10);
x_64 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__1;
x_65 = l_Lean_Macro_throwErrorAt___rarg(x_8, x_64, x_4, x_5);
lean_dec(x_8);
x_66 = !lean_is_exclusive(x_65);
if (x_66 == 0)
{
return x_65;
}
else
{
lean_object* x_67; lean_object* x_68; lean_object* x_69; 
x_67 = lean_ctor_get(x_65, 0);
x_68 = lean_ctor_get(x_65, 1);
lean_inc(x_68);
lean_inc(x_67);
lean_dec(x_65);
x_69 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_69, 0, x_67);
lean_ctor_set(x_69, 1, x_68);
return x_69;
}
}
else
{
lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; 
lean_dec(x_8);
x_70 = lean_unsigned_to_nat(1u);
x_71 = l_Lean_Syntax_getArg(x_61, x_70);
lean_dec(x_61);
x_72 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_72, 0, x_40);
lean_ctor_set(x_72, 1, x_71);
x_73 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_73, 0, x_72);
x_11 = x_73;
x_12 = x_5;
goto block_17;
}
}
}
else
{
lean_object* x_74; lean_object* x_75; uint8_t x_76; 
x_74 = l_Lean_Syntax_getArg(x_50, x_9);
lean_dec(x_50);
x_75 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__6;
lean_inc(x_74);
x_76 = l_Lean_Syntax_isOfKind(x_74, x_75);
if (x_76 == 0)
{
lean_object* x_77; lean_object* x_78; uint8_t x_79; 
lean_dec(x_74);
lean_dec(x_40);
lean_dec(x_10);
x_77 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__1;
x_78 = l_Lean_Macro_throwErrorAt___rarg(x_8, x_77, x_4, x_5);
lean_dec(x_8);
x_79 = !lean_is_exclusive(x_78);
if (x_79 == 0)
{
return x_78;
}
else
{
lean_object* x_80; lean_object* x_81; lean_object* x_82; 
x_80 = lean_ctor_get(x_78, 0);
x_81 = lean_ctor_get(x_78, 1);
lean_inc(x_81);
lean_inc(x_80);
lean_dec(x_78);
x_82 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_82, 0, x_80);
lean_ctor_set(x_82, 1, x_81);
return x_82;
}
}
else
{
lean_object* x_83; lean_object* x_84; 
lean_dec(x_8);
x_83 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_83, 0, x_40);
lean_ctor_set(x_83, 1, x_74);
x_84 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_84, 0, x_83);
x_11 = x_84;
x_12 = x_5;
goto block_17;
}
}
}
}
block_17:
{
size_t x_13; size_t x_14; lean_object* x_15; 
x_13 = 1;
x_14 = lean_usize_add(x_2, x_13);
x_15 = lean_array_uset(x_10, x_2, x_11);
x_2 = x_14;
x_3 = x_15;
x_5 = x_12;
goto _start;
}
}
}
}
static lean_object* _init_l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__5___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("tuple", 5, 5);
return x_1;
}
}
static lean_object* _init_l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__5___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__1;
x_2 = l_ProofWidgets_Jsx_jsxElement_quot___closed__2;
x_3 = l_ProofWidgets_Jsx_jsxElement_quot___closed__3;
x_4 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__5___closed__1;
x_5 = l_Lean_Name_mkStr4(x_1, x_2, x_3, x_4);
return x_5;
}
}
static lean_object* _init_l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__5___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("(", 1, 1);
return x_1;
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__5(lean_object* x_1, size_t x_2, size_t x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
uint8_t x_7; 
x_7 = lean_usize_dec_lt(x_3, x_2);
if (x_7 == 0)
{
lean_object* x_8; 
x_8 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_8, 0, x_4);
lean_ctor_set(x_8, 1, x_6);
return x_8;
}
else
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; uint8_t x_12; 
x_9 = lean_array_uget(x_4, x_3);
x_10 = lean_unsigned_to_nat(0u);
x_11 = lean_array_uset(x_4, x_3, x_10);
x_12 = !lean_is_exclusive(x_9);
if (x_12 == 0)
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; uint8_t x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; uint8_t x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; size_t x_33; size_t x_34; lean_object* x_35; 
x_13 = lean_ctor_get(x_9, 0);
x_14 = lean_ctor_get(x_9, 1);
x_15 = lean_ctor_get(x_5, 5);
x_16 = 0;
x_17 = l_Lean_SourceInfo_fromRef(x_15, x_16);
x_18 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__5___closed__3;
lean_inc(x_17);
lean_ctor_set_tag(x_9, 2);
lean_ctor_set(x_9, 1, x_18);
lean_ctor_set(x_9, 0, x_17);
x_19 = l_Lean_Syntax_getId(x_13);
lean_dec(x_13);
x_20 = 1;
x_21 = l_Lean_Name_toString(x_19, x_20);
x_22 = lean_box(2);
x_23 = l_Lean_Syntax_mkStrLit(x_21, x_22);
lean_dec(x_21);
x_24 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__7;
lean_inc(x_17);
x_25 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_25, 0, x_17);
lean_ctor_set(x_25, 1, x_24);
x_26 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_17);
x_27 = l_Lean_Syntax_node1(x_17, x_26, x_14);
lean_inc(x_17);
x_28 = l_Lean_Syntax_node3(x_17, x_26, x_23, x_25, x_27);
x_29 = l_ProofWidgets_Jsx_jsxElement_quot___closed__14;
lean_inc(x_17);
x_30 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_30, 0, x_17);
lean_ctor_set(x_30, 1, x_29);
x_31 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__5___closed__2;
x_32 = l_Lean_Syntax_node3(x_17, x_31, x_9, x_28, x_30);
x_33 = 1;
x_34 = lean_usize_add(x_3, x_33);
x_35 = lean_array_uset(x_11, x_3, x_32);
x_3 = x_34;
x_4 = x_35;
goto _start;
}
else
{
lean_object* x_37; lean_object* x_38; lean_object* x_39; uint8_t x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; uint8_t x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; size_t x_58; size_t x_59; lean_object* x_60; 
x_37 = lean_ctor_get(x_9, 0);
x_38 = lean_ctor_get(x_9, 1);
lean_inc(x_38);
lean_inc(x_37);
lean_dec(x_9);
x_39 = lean_ctor_get(x_5, 5);
x_40 = 0;
x_41 = l_Lean_SourceInfo_fromRef(x_39, x_40);
x_42 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__5___closed__3;
lean_inc(x_41);
x_43 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_43, 0, x_41);
lean_ctor_set(x_43, 1, x_42);
x_44 = l_Lean_Syntax_getId(x_37);
lean_dec(x_37);
x_45 = 1;
x_46 = l_Lean_Name_toString(x_44, x_45);
x_47 = lean_box(2);
x_48 = l_Lean_Syntax_mkStrLit(x_46, x_47);
lean_dec(x_46);
x_49 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__7;
lean_inc(x_41);
x_50 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_50, 0, x_41);
lean_ctor_set(x_50, 1, x_49);
x_51 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_41);
x_52 = l_Lean_Syntax_node1(x_41, x_51, x_38);
lean_inc(x_41);
x_53 = l_Lean_Syntax_node3(x_41, x_51, x_48, x_50, x_52);
x_54 = l_ProofWidgets_Jsx_jsxElement_quot___closed__14;
lean_inc(x_41);
x_55 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_55, 0, x_41);
lean_ctor_set(x_55, 1, x_54);
x_56 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__5___closed__2;
x_57 = l_Lean_Syntax_node3(x_41, x_56, x_43, x_53, x_55);
x_58 = 1;
x_59 = lean_usize_add(x_3, x_58);
x_60 = lean_array_uset(x_11, x_3, x_57);
x_3 = x_59;
x_4 = x_60;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__7___lambda__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; 
x_8 = lean_array_push(x_4, x_1);
x_9 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_9, 0, x_2);
lean_ctor_set(x_9, 1, x_8);
x_10 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_10, 0, x_9);
x_11 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_11, 0, x_10);
lean_ctor_set(x_11, 1, x_7);
return x_11;
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__7(lean_object* x_1, lean_object* x_2, lean_object* x_3, size_t x_4, size_t x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
uint8_t x_9; 
x_9 = lean_usize_dec_lt(x_5, x_4);
if (x_9 == 0)
{
lean_object* x_10; 
lean_dec(x_7);
lean_dec(x_2);
lean_dec(x_1);
x_10 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_10, 0, x_6);
lean_ctor_set(x_10, 1, x_8);
return x_10;
}
else
{
lean_object* x_11; 
x_11 = lean_array_uget(x_3, x_5);
if (lean_obj_tag(x_11) == 0)
{
uint8_t x_12; 
x_12 = !lean_is_exclusive(x_6);
if (x_12 == 0)
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; size_t x_16; size_t x_17; 
x_13 = lean_ctor_get(x_6, 0);
x_14 = lean_ctor_get(x_11, 0);
lean_inc(x_14);
lean_dec(x_11);
x_15 = lean_array_push(x_13, x_14);
lean_ctor_set(x_6, 0, x_15);
x_16 = 1;
x_17 = lean_usize_add(x_5, x_16);
x_5 = x_17;
goto _start;
}
else
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; size_t x_24; size_t x_25; 
x_19 = lean_ctor_get(x_6, 0);
x_20 = lean_ctor_get(x_6, 1);
lean_inc(x_20);
lean_inc(x_19);
lean_dec(x_6);
x_21 = lean_ctor_get(x_11, 0);
lean_inc(x_21);
lean_dec(x_11);
x_22 = lean_array_push(x_19, x_21);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_22);
lean_ctor_set(x_23, 1, x_20);
x_24 = 1;
x_25 = lean_usize_add(x_5, x_24);
x_5 = x_25;
x_6 = x_23;
goto _start;
}
}
else
{
lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; uint8_t x_32; uint8_t x_33; 
x_27 = lean_ctor_get(x_6, 0);
lean_inc(x_27);
x_28 = lean_ctor_get(x_6, 1);
lean_inc(x_28);
lean_dec(x_6);
x_29 = lean_ctor_get(x_11, 0);
lean_inc(x_29);
lean_dec(x_11);
x_30 = lean_array_get_size(x_27);
x_31 = lean_unsigned_to_nat(0u);
x_32 = lean_nat_dec_eq(x_30, x_31);
lean_dec(x_30);
x_33 = l_instDecidableNot___rarg(x_32);
if (x_33 == 0)
{
lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; size_t x_39; size_t x_40; 
x_34 = lean_box(0);
lean_inc(x_2);
x_35 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__7___lambda__1(x_29, x_2, x_27, x_28, x_34, x_7, x_8);
lean_dec(x_27);
x_36 = lean_ctor_get(x_35, 0);
lean_inc(x_36);
x_37 = lean_ctor_get(x_35, 1);
lean_inc(x_37);
lean_dec(x_35);
x_38 = lean_ctor_get(x_36, 0);
lean_inc(x_38);
lean_dec(x_36);
x_39 = 1;
x_40 = lean_usize_add(x_5, x_39);
x_5 = x_40;
x_6 = x_38;
x_8 = x_37;
goto _start;
}
else
{
lean_object* x_42; 
lean_inc(x_1);
lean_inc(x_7);
lean_inc(x_27);
x_42 = lean_apply_3(x_1, x_27, x_7, x_8);
if (lean_obj_tag(x_42) == 0)
{
lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; size_t x_51; size_t x_52; 
x_43 = lean_ctor_get(x_42, 0);
lean_inc(x_43);
x_44 = lean_ctor_get(x_42, 1);
lean_inc(x_44);
lean_dec(x_42);
x_45 = lean_array_push(x_28, x_43);
x_46 = lean_box(0);
lean_inc(x_2);
x_47 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__7___lambda__1(x_29, x_2, x_27, x_45, x_46, x_7, x_44);
lean_dec(x_27);
x_48 = lean_ctor_get(x_47, 0);
lean_inc(x_48);
x_49 = lean_ctor_get(x_47, 1);
lean_inc(x_49);
lean_dec(x_47);
x_50 = lean_ctor_get(x_48, 0);
lean_inc(x_50);
lean_dec(x_48);
x_51 = 1;
x_52 = lean_usize_add(x_5, x_51);
x_5 = x_52;
x_6 = x_50;
x_8 = x_49;
goto _start;
}
else
{
uint8_t x_54; 
lean_dec(x_29);
lean_dec(x_28);
lean_dec(x_27);
lean_dec(x_7);
lean_dec(x_2);
lean_dec(x_1);
x_54 = !lean_is_exclusive(x_42);
if (x_54 == 0)
{
return x_42;
}
else
{
lean_object* x_55; lean_object* x_56; lean_object* x_57; 
x_55 = lean_ctor_get(x_42, 0);
x_56 = lean_ctor_get(x_42, 1);
lean_inc(x_56);
lean_inc(x_55);
lean_dec(x_42);
x_57 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_57, 0, x_55);
lean_ctor_set(x_57, 1, x_56);
return x_57;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___at_ProofWidgets_Jsx_transformTag___spec__6___lambda__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_5, 0, x_1);
lean_ctor_set(x_5, 1, x_4);
return x_5;
}
}
static lean_object* _init_l_ProofWidgets_Util_foldInlsM___at_ProofWidgets_Jsx_transformTag___spec__6___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_instInhabitedHtml___closed__1;
x_2 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_2, 0, x_1);
lean_ctor_set(x_2, 1, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Util_foldInlsM___at_ProofWidgets_Jsx_transformTag___spec__6___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_Util_foldInlsM___at_ProofWidgets_Jsx_transformTag___spec__6___lambda__1___boxed), 4, 0);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___at_ProofWidgets_Jsx_transformTag___spec__6(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
size_t x_5; size_t x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; 
x_5 = lean_array_size(x_1);
x_6 = 0;
x_7 = l_ProofWidgets_instInhabitedHtml___closed__1;
x_8 = l_ProofWidgets_Util_foldInlsM___at_ProofWidgets_Jsx_transformTag___spec__6___closed__1;
lean_inc(x_3);
lean_inc(x_2);
x_9 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__7(x_2, x_7, x_1, x_5, x_6, x_8, x_3, x_4);
if (lean_obj_tag(x_9) == 0)
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; uint8_t x_17; uint8_t x_18; 
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec(x_9);
x_12 = lean_ctor_get(x_10, 0);
lean_inc(x_12);
x_13 = lean_ctor_get(x_10, 1);
lean_inc(x_13);
lean_dec(x_10);
x_14 = l_ProofWidgets_Util_foldInlsM___at_ProofWidgets_Jsx_transformTag___spec__6___closed__2;
x_15 = lean_array_get_size(x_12);
x_16 = lean_unsigned_to_nat(0u);
x_17 = lean_nat_dec_eq(x_15, x_16);
lean_dec(x_15);
x_18 = l_instDecidableNot___rarg(x_17);
if (x_18 == 0)
{
lean_object* x_19; lean_object* x_20; 
lean_dec(x_12);
lean_dec(x_2);
x_19 = lean_box(0);
x_20 = lean_apply_4(x_14, x_13, x_19, x_3, x_11);
return x_20;
}
else
{
lean_object* x_21; 
lean_inc(x_3);
x_21 = lean_apply_3(x_2, x_12, x_3, x_11);
if (lean_obj_tag(x_21) == 0)
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; 
x_22 = lean_ctor_get(x_21, 0);
lean_inc(x_22);
x_23 = lean_ctor_get(x_21, 1);
lean_inc(x_23);
lean_dec(x_21);
x_24 = lean_array_push(x_13, x_22);
x_25 = lean_box(0);
x_26 = lean_apply_4(x_14, x_24, x_25, x_3, x_23);
return x_26;
}
else
{
uint8_t x_27; 
lean_dec(x_13);
lean_dec(x_3);
x_27 = !lean_is_exclusive(x_21);
if (x_27 == 0)
{
return x_21;
}
else
{
lean_object* x_28; lean_object* x_29; lean_object* x_30; 
x_28 = lean_ctor_get(x_21, 0);
x_29 = lean_ctor_get(x_21, 1);
lean_inc(x_29);
lean_inc(x_28);
lean_dec(x_21);
x_30 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_30, 0, x_28);
lean_ctor_set(x_30, 1, x_29);
return x_30;
}
}
}
}
else
{
uint8_t x_31; 
lean_dec(x_3);
lean_dec(x_2);
x_31 = !lean_is_exclusive(x_9);
if (x_31 == 0)
{
return x_9;
}
else
{
lean_object* x_32; lean_object* x_33; lean_object* x_34; 
x_32 = lean_ctor_get(x_9, 0);
x_33 = lean_ctor_get(x_9, 1);
lean_inc(x_33);
lean_inc(x_32);
lean_dec(x_9);
x_34 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_34, 0, x_32);
lean_ctor_set(x_34, 1, x_33);
return x_34;
}
}
}
}
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__9(lean_object* x_1, size_t x_2, size_t x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
uint8_t x_7; 
x_7 = lean_usize_dec_eq(x_2, x_3);
if (x_7 == 0)
{
lean_object* x_8; 
x_8 = lean_array_uget(x_1, x_2);
if (lean_obj_tag(x_8) == 0)
{
size_t x_9; size_t x_10; 
lean_dec(x_8);
x_9 = 1;
x_10 = lean_usize_add(x_2, x_9);
x_2 = x_10;
goto _start;
}
else
{
lean_object* x_12; lean_object* x_13; size_t x_14; size_t x_15; 
x_12 = lean_ctor_get(x_8, 0);
lean_inc(x_12);
lean_dec(x_8);
x_13 = lean_array_push(x_4, x_12);
x_14 = 1;
x_15 = lean_usize_add(x_2, x_14);
x_2 = x_15;
x_4 = x_13;
goto _start;
}
}
else
{
lean_object* x_17; 
x_17 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_17, 0, x_4);
lean_ctor_set(x_17, 1, x_6);
return x_17;
}
}
}
LEAN_EXPORT lean_object* l_Array_filterMapM___at_ProofWidgets_Jsx_transformTag___spec__8(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
uint8_t x_6; 
x_6 = lean_nat_dec_lt(x_2, x_3);
if (x_6 == 0)
{
lean_object* x_7; lean_object* x_8; 
x_7 = l_ProofWidgets_instInhabitedHtml___closed__1;
x_8 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_8, 0, x_7);
lean_ctor_set(x_8, 1, x_5);
return x_8;
}
else
{
lean_object* x_9; uint8_t x_10; 
x_9 = lean_array_get_size(x_1);
x_10 = lean_nat_dec_le(x_3, x_9);
lean_dec(x_9);
if (x_10 == 0)
{
lean_object* x_11; lean_object* x_12; 
x_11 = l_ProofWidgets_instInhabitedHtml___closed__1;
x_12 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_12, 0, x_11);
lean_ctor_set(x_12, 1, x_5);
return x_12;
}
else
{
size_t x_13; size_t x_14; lean_object* x_15; lean_object* x_16; 
x_13 = lean_usize_of_nat(x_2);
x_14 = lean_usize_of_nat(x_3);
x_15 = l_ProofWidgets_instInhabitedHtml___closed__1;
x_16 = l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__9(x_1, x_13, x_14, x_15, x_4, x_5);
return x_16;
}
}
}
}
static lean_object* _init_l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("structInstField", 15, 15);
return x_1;
}
}
static lean_object* _init_l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__1;
x_2 = l_ProofWidgets_Jsx_jsxElement_quot___closed__2;
x_3 = l_ProofWidgets_Jsx_jsxElement_quot___closed__3;
x_4 = l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__1;
x_5 = l_Lean_Name_mkStr4(x_1, x_2, x_3, x_4);
return x_5;
}
}
static lean_object* _init_l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("structInstLVal", 14, 14);
return x_1;
}
}
static lean_object* _init_l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__1;
x_2 = l_ProofWidgets_Jsx_jsxElement_quot___closed__2;
x_3 = l_ProofWidgets_Jsx_jsxElement_quot___closed__3;
x_4 = l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__3;
x_5 = l_Lean_Name_mkStr4(x_1, x_2, x_3, x_4);
return x_5;
}
}
static lean_object* _init_l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked(":=", 2, 2);
return x_1;
}
}
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11(lean_object* x_1, lean_object* x_2, size_t x_3, size_t x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
uint8_t x_8; 
x_8 = lean_usize_dec_eq(x_3, x_4);
if (x_8 == 0)
{
lean_object* x_9; 
x_9 = lean_array_uget(x_2, x_3);
if (lean_obj_tag(x_9) == 0)
{
lean_object* x_10; uint8_t x_11; 
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
lean_dec(x_9);
x_11 = !lean_is_exclusive(x_10);
if (x_11 == 0)
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; uint8_t x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; size_t x_26; size_t x_27; 
x_12 = lean_ctor_get(x_10, 0);
x_13 = lean_ctor_get(x_10, 1);
x_14 = lean_ctor_get(x_6, 5);
x_15 = 0;
x_16 = l_Lean_SourceInfo_fromRef(x_14, x_15);
x_17 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
x_18 = l_ProofWidgets_instInhabitedHtml___closed__1;
lean_inc(x_16);
x_19 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_19, 0, x_16);
lean_ctor_set(x_19, 1, x_17);
lean_ctor_set(x_19, 2, x_18);
x_20 = l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__4;
lean_inc(x_16);
x_21 = l_Lean_Syntax_node2(x_16, x_20, x_12, x_19);
x_22 = l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__5;
lean_inc(x_16);
lean_ctor_set_tag(x_10, 2);
lean_ctor_set(x_10, 1, x_22);
lean_ctor_set(x_10, 0, x_16);
x_23 = l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__2;
x_24 = l_Lean_Syntax_node3(x_16, x_23, x_21, x_10, x_13);
x_25 = lean_array_push(x_5, x_24);
x_26 = 1;
x_27 = lean_usize_add(x_3, x_26);
x_3 = x_27;
x_5 = x_25;
goto _start;
}
else
{
lean_object* x_29; lean_object* x_30; lean_object* x_31; uint8_t x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; size_t x_44; size_t x_45; 
x_29 = lean_ctor_get(x_10, 0);
x_30 = lean_ctor_get(x_10, 1);
lean_inc(x_30);
lean_inc(x_29);
lean_dec(x_10);
x_31 = lean_ctor_get(x_6, 5);
x_32 = 0;
x_33 = l_Lean_SourceInfo_fromRef(x_31, x_32);
x_34 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
x_35 = l_ProofWidgets_instInhabitedHtml___closed__1;
lean_inc(x_33);
x_36 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_36, 0, x_33);
lean_ctor_set(x_36, 1, x_34);
lean_ctor_set(x_36, 2, x_35);
x_37 = l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__4;
lean_inc(x_33);
x_38 = l_Lean_Syntax_node2(x_33, x_37, x_29, x_36);
x_39 = l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__5;
lean_inc(x_33);
x_40 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_40, 0, x_33);
lean_ctor_set(x_40, 1, x_39);
x_41 = l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__2;
x_42 = l_Lean_Syntax_node3(x_33, x_41, x_38, x_40, x_30);
x_43 = lean_array_push(x_5, x_42);
x_44 = 1;
x_45 = lean_usize_add(x_3, x_44);
x_3 = x_45;
x_5 = x_43;
goto _start;
}
}
else
{
size_t x_47; size_t x_48; 
lean_dec(x_9);
x_47 = 1;
x_48 = lean_usize_add(x_3, x_47);
x_3 = x_48;
goto _start;
}
}
else
{
lean_object* x_50; 
x_50 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_50, 0, x_5);
lean_ctor_set(x_50, 1, x_7);
return x_50;
}
}
}
LEAN_EXPORT lean_object* l_Array_filterMapM___at_ProofWidgets_Jsx_transformTag___spec__10(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
uint8_t x_7; 
x_7 = lean_nat_dec_lt(x_3, x_4);
if (x_7 == 0)
{
lean_object* x_8; lean_object* x_9; 
x_8 = l_ProofWidgets_instInhabitedHtml___closed__1;
x_9 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_9, 0, x_8);
lean_ctor_set(x_9, 1, x_6);
return x_9;
}
else
{
lean_object* x_10; uint8_t x_11; 
x_10 = lean_array_get_size(x_2);
x_11 = lean_nat_dec_le(x_4, x_10);
lean_dec(x_10);
if (x_11 == 0)
{
lean_object* x_12; lean_object* x_13; 
x_12 = l_ProofWidgets_instInhabitedHtml___closed__1;
x_13 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_13, 0, x_12);
lean_ctor_set(x_13, 1, x_6);
return x_13;
}
else
{
size_t x_14; size_t x_15; lean_object* x_16; lean_object* x_17; 
x_14 = lean_usize_of_nat(x_3);
x_15 = lean_usize_of_nat(x_4);
x_16 = l_ProofWidgets_instInhabitedHtml___closed__1;
x_17 = l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11(x_1, x_2, x_14, x_15, x_16, x_5, x_6);
return x_17;
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_transformTag___lambda__1(lean_object* x_1, size_t x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
size_t x_7; lean_object* x_8; uint8_t x_9; 
x_7 = lean_array_size(x_4);
x_8 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__5(x_1, x_7, x_2, x_4, x_5, x_6);
x_9 = !lean_is_exclusive(x_8);
if (x_9 == 0)
{
lean_object* x_10; lean_object* x_11; uint8_t x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; 
x_10 = lean_ctor_get(x_8, 0);
x_11 = lean_ctor_get(x_5, 5);
x_12 = 0;
x_13 = l_Lean_SourceInfo_fromRef(x_11, x_12);
x_14 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__4;
lean_inc(x_13);
x_15 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_15, 0, x_13);
lean_ctor_set(x_15, 1, x_14);
x_16 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__7;
x_17 = l_Lean_Syntax_SepArray_ofElems(x_16, x_10);
lean_dec(x_10);
x_18 = l_Array_append___rarg(x_3, x_17);
lean_dec(x_17);
x_19 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_13);
x_20 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_20, 0, x_13);
lean_ctor_set(x_20, 1, x_19);
lean_ctor_set(x_20, 2, x_18);
x_21 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__8;
lean_inc(x_13);
x_22 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_22, 0, x_13);
lean_ctor_set(x_22, 1, x_21);
x_23 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__3;
x_24 = l_Lean_Syntax_node3(x_13, x_23, x_15, x_20, x_22);
lean_ctor_set(x_8, 0, x_24);
return x_8;
}
else
{
lean_object* x_25; lean_object* x_26; lean_object* x_27; uint8_t x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; 
x_25 = lean_ctor_get(x_8, 0);
x_26 = lean_ctor_get(x_8, 1);
lean_inc(x_26);
lean_inc(x_25);
lean_dec(x_8);
x_27 = lean_ctor_get(x_5, 5);
x_28 = 0;
x_29 = l_Lean_SourceInfo_fromRef(x_27, x_28);
x_30 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__4;
lean_inc(x_29);
x_31 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_31, 0, x_29);
lean_ctor_set(x_31, 1, x_30);
x_32 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__7;
x_33 = l_Lean_Syntax_SepArray_ofElems(x_32, x_25);
lean_dec(x_25);
x_34 = l_Array_append___rarg(x_3, x_33);
lean_dec(x_33);
x_35 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_29);
x_36 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_36, 0, x_29);
lean_ctor_set(x_36, 1, x_35);
lean_ctor_set(x_36, 2, x_34);
x_37 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__8;
lean_inc(x_29);
x_38 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_38, 0, x_29);
lean_ctor_set(x_38, 1, x_37);
x_39 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__3;
x_40 = l_Lean_Syntax_node3(x_29, x_39, x_31, x_36, x_38);
x_41 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_41, 0, x_40);
lean_ctor_set(x_41, 1, x_26);
return x_41;
}
}
}
static lean_object* _init_l_ProofWidgets_Jsx_transformTag___lambda__2___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Html.ofComponent", 16, 16);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_transformTag___lambda__2___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Jsx_transformTag___lambda__2___closed__1;
x_2 = l_String_toSubstring_x27(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_transformTag___lambda__2___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("ofComponent", 11, 11);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_transformTag___lambda__2___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__13;
x_2 = l_ProofWidgets_Jsx_transformTag___lambda__2___closed__3;
x_3 = l_Lean_Name_mkStr2(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_transformTag___lambda__2___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__1;
x_2 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__13;
x_3 = l_ProofWidgets_Jsx_transformTag___lambda__2___closed__3;
x_4 = l_Lean_Name_mkStr3(x_1, x_2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_transformTag___lambda__2___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Jsx_transformTag___lambda__2___closed__5;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_transformTag___lambda__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; uint8_t x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; 
x_7 = lean_ctor_get(x_5, 5);
lean_inc(x_7);
x_8 = 0;
x_9 = l_Lean_SourceInfo_fromRef(x_7, x_8);
lean_dec(x_7);
x_10 = lean_ctor_get(x_5, 2);
lean_inc(x_10);
x_11 = lean_ctor_get(x_5, 1);
lean_inc(x_11);
lean_dec(x_5);
x_12 = l_ProofWidgets_Jsx_transformTag___lambda__2___closed__4;
x_13 = l_Lean_addMacroScope(x_11, x_12, x_10);
x_14 = l_ProofWidgets_Jsx_transformTag___lambda__2___closed__5;
lean_inc(x_1);
x_15 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_15, 0, x_14);
lean_ctor_set(x_15, 1, x_1);
x_16 = l_ProofWidgets_Jsx_transformTag___lambda__2___closed__6;
x_17 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_17, 0, x_16);
lean_ctor_set(x_17, 1, x_1);
x_18 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_18, 0, x_15);
lean_ctor_set(x_18, 1, x_17);
x_19 = l_ProofWidgets_Jsx_transformTag___lambda__2___closed__2;
lean_inc(x_9);
x_20 = lean_alloc_ctor(3, 4, 0);
lean_ctor_set(x_20, 0, x_9);
lean_ctor_set(x_20, 1, x_19);
lean_ctor_set(x_20, 2, x_13);
lean_ctor_set(x_20, 3, x_18);
x_21 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_9);
x_22 = l_Lean_Syntax_node3(x_9, x_21, x_2, x_4, x_3);
x_23 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__10;
x_24 = l_Lean_Syntax_node2(x_9, x_23, x_20, x_22);
x_25 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_25, 0, x_24);
lean_ctor_set(x_25, 1, x_6);
return x_25;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_transformTag___lambda__3___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Html.element", 12, 12);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_transformTag___lambda__3___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__1;
x_2 = l_String_toSubstring_x27(x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_transformTag___lambda__3___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__13;
x_2 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__3___closed__1;
x_3 = l_Lean_Name_mkStr2(x_1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_transformTag___lambda__3___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__1;
x_2 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__13;
x_3 = l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__3___closed__1;
x_4 = l_Lean_Name_mkStr3(x_1, x_2, x_3);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_transformTag___lambda__3___closed__5() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__4;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_transformTag___lambda__3___closed__6() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__4;
x_2 = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_transformTag___lambda__3___closed__7() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = lean_box(0);
x_2 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__6;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_2);
lean_ctor_set(x_3, 1, x_1);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_transformTag___lambda__3___closed__8() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__5;
x_2 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__7;
x_3 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_3, 0, x_1);
lean_ctor_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_transformTag___lambda__3___closed__9() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("structInst", 10, 10);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_transformTag___lambda__3___closed__10() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__1;
x_2 = l_ProofWidgets_Jsx_jsxElement_quot___closed__2;
x_3 = l_ProofWidgets_Jsx_jsxElement_quot___closed__3;
x_4 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__9;
x_5 = l_Lean_Name_mkStr4(x_1, x_2, x_3, x_4);
return x_5;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_transformTag___lambda__3___closed__11() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("with", 4, 4);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_transformTag___lambda__3___closed__12() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("optEllipsis", 11, 11);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_transformTag___lambda__3___closed__13() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; lean_object* x_5; 
x_1 = l_ProofWidgets_Jsx_jsxElement_quot___closed__1;
x_2 = l_ProofWidgets_Jsx_jsxElement_quot___closed__2;
x_3 = l_ProofWidgets_Jsx_jsxElement_quot___closed__3;
x_4 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__12;
x_5 = l_Lean_Name_mkStr4(x_1, x_2, x_3, x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_transformTag___lambda__3(lean_object* x_1, size_t x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; uint8_t x_11; 
x_10 = l_ProofWidgets_Util_joinArrays___at_ProofWidgets_Jsx_transformTag___spec__2(x_6, x_8, x_9);
x_11 = !lean_is_exclusive(x_10);
if (x_11 == 0)
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; size_t x_15; lean_object* x_16; 
x_12 = lean_ctor_get(x_10, 0);
x_13 = lean_ctor_get(x_10, 1);
x_14 = lean_box(0);
x_15 = lean_array_size(x_1);
lean_inc(x_8);
x_16 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__4(x_15, x_2, x_1, x_8, x_13);
if (lean_obj_tag(x_16) == 0)
{
lean_object* x_17; lean_object* x_18; uint8_t x_19; lean_object* x_20; lean_object* x_21; lean_object* x_70; lean_object* x_71; 
x_17 = lean_ctor_get(x_16, 0);
lean_inc(x_17);
x_18 = lean_ctor_get(x_16, 1);
lean_inc(x_18);
lean_dec(x_16);
x_19 = 1;
x_20 = l_Lean_Name_toString(x_3, x_19);
x_70 = lean_unsigned_to_nat(0u);
x_71 = lean_string_utf8_get_opt(x_20, x_70);
if (lean_obj_tag(x_71) == 0)
{
lean_object* x_72; 
lean_free_object(x_10);
lean_dec(x_5);
x_72 = lean_box(0);
x_21 = x_72;
goto block_69;
}
else
{
lean_object* x_73; uint32_t x_74; uint32_t x_75; uint8_t x_76; 
x_73 = lean_ctor_get(x_71, 0);
lean_inc(x_73);
lean_dec(x_71);
x_74 = 65;
x_75 = lean_unbox_uint32(x_73);
x_76 = lean_uint32_dec_le(x_74, x_75);
if (x_76 == 0)
{
lean_object* x_77; 
lean_dec(x_73);
lean_free_object(x_10);
lean_dec(x_5);
x_77 = lean_box(0);
x_21 = x_77;
goto block_69;
}
else
{
uint32_t x_78; uint32_t x_79; uint8_t x_80; 
x_78 = 90;
x_79 = lean_unbox_uint32(x_73);
lean_dec(x_73);
x_80 = lean_uint32_dec_le(x_79, x_78);
if (x_80 == 0)
{
lean_object* x_81; 
lean_free_object(x_10);
lean_dec(x_5);
x_81 = lean_box(0);
x_21 = x_81;
goto block_69;
}
else
{
lean_object* x_82; lean_object* x_83; uint8_t x_84; 
lean_dec(x_20);
x_82 = lean_array_get_size(x_17);
x_83 = l_Array_filterMapM___at_ProofWidgets_Jsx_transformTag___spec__8(x_17, x_70, x_82, x_8, x_18);
x_84 = !lean_is_exclusive(x_83);
if (x_84 == 0)
{
lean_object* x_85; lean_object* x_86; lean_object* x_87; uint8_t x_88; 
x_85 = lean_ctor_get(x_83, 0);
x_86 = lean_ctor_get(x_83, 1);
x_87 = l_Array_filterMapM___at_ProofWidgets_Jsx_transformTag___spec__10(x_14, x_17, x_70, x_82, x_8, x_86);
lean_dec(x_82);
lean_dec(x_17);
x_88 = !lean_is_exclusive(x_87);
if (x_88 == 0)
{
lean_object* x_89; lean_object* x_90; lean_object* x_91; lean_object* x_92; uint8_t x_93; 
x_89 = lean_ctor_get(x_87, 0);
x_90 = lean_ctor_get(x_87, 1);
x_91 = lean_array_get_size(x_85);
x_92 = lean_unsigned_to_nat(1u);
x_93 = lean_nat_dec_eq(x_91, x_92);
lean_dec(x_91);
if (x_93 == 0)
{
lean_object* x_94; uint8_t x_95; lean_object* x_96; lean_object* x_97; lean_object* x_98; lean_object* x_99; lean_object* x_100; lean_object* x_101; lean_object* x_102; lean_object* x_103; lean_object* x_104; lean_object* x_105; lean_object* x_106; lean_object* x_107; lean_object* x_108; lean_object* x_109; lean_object* x_110; lean_object* x_111; lean_object* x_112; lean_object* x_113; lean_object* x_114; 
x_94 = lean_ctor_get(x_8, 5);
lean_inc(x_94);
x_95 = 0;
x_96 = l_Lean_SourceInfo_fromRef(x_94, x_95);
lean_dec(x_94);
x_97 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_96);
lean_ctor_set_tag(x_87, 2);
lean_ctor_set(x_87, 1, x_97);
lean_ctor_set(x_87, 0, x_96);
x_98 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__7;
x_99 = l_Lean_Syntax_SepArray_ofElems(x_98, x_85);
lean_dec(x_85);
lean_inc(x_4);
x_100 = l_Array_append___rarg(x_4, x_99);
lean_dec(x_99);
x_101 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_96);
x_102 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_102, 0, x_96);
lean_ctor_set(x_102, 1, x_101);
lean_ctor_set(x_102, 2, x_100);
x_103 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__11;
lean_inc(x_96);
lean_ctor_set_tag(x_83, 2);
lean_ctor_set(x_83, 1, x_103);
lean_ctor_set(x_83, 0, x_96);
lean_inc(x_96);
x_104 = l_Lean_Syntax_node2(x_96, x_101, x_102, x_83);
x_105 = l_Lean_Syntax_SepArray_ofElems(x_98, x_89);
lean_dec(x_89);
lean_inc(x_4);
x_106 = l_Array_append___rarg(x_4, x_105);
lean_dec(x_105);
lean_inc(x_96);
x_107 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_107, 0, x_96);
lean_ctor_set(x_107, 1, x_101);
lean_ctor_set(x_107, 2, x_106);
lean_inc(x_96);
x_108 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_108, 0, x_96);
lean_ctor_set(x_108, 1, x_101);
lean_ctor_set(x_108, 2, x_4);
x_109 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__13;
lean_inc(x_108);
lean_inc(x_96);
x_110 = l_Lean_Syntax_node1(x_96, x_109, x_108);
x_111 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_96);
lean_ctor_set_tag(x_10, 2);
lean_ctor_set(x_10, 1, x_111);
lean_ctor_set(x_10, 0, x_96);
x_112 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__10;
x_113 = l_Lean_Syntax_node6(x_96, x_112, x_87, x_104, x_107, x_110, x_108, x_10);
x_114 = l_ProofWidgets_Jsx_transformTag___lambda__2(x_14, x_5, x_12, x_113, x_8, x_90);
return x_114;
}
else
{
lean_object* x_115; uint8_t x_116; 
x_115 = lean_array_get_size(x_89);
x_116 = lean_nat_dec_eq(x_115, x_70);
lean_dec(x_115);
if (x_116 == 0)
{
lean_object* x_117; uint8_t x_118; lean_object* x_119; lean_object* x_120; lean_object* x_121; lean_object* x_122; lean_object* x_123; lean_object* x_124; lean_object* x_125; lean_object* x_126; lean_object* x_127; lean_object* x_128; lean_object* x_129; lean_object* x_130; lean_object* x_131; lean_object* x_132; lean_object* x_133; lean_object* x_134; lean_object* x_135; lean_object* x_136; lean_object* x_137; 
x_117 = lean_ctor_get(x_8, 5);
lean_inc(x_117);
x_118 = 0;
x_119 = l_Lean_SourceInfo_fromRef(x_117, x_118);
lean_dec(x_117);
x_120 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_119);
lean_ctor_set_tag(x_87, 2);
lean_ctor_set(x_87, 1, x_120);
lean_ctor_set(x_87, 0, x_119);
x_121 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__7;
x_122 = l_Lean_Syntax_SepArray_ofElems(x_121, x_85);
lean_dec(x_85);
lean_inc(x_4);
x_123 = l_Array_append___rarg(x_4, x_122);
lean_dec(x_122);
x_124 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_119);
x_125 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_125, 0, x_119);
lean_ctor_set(x_125, 1, x_124);
lean_ctor_set(x_125, 2, x_123);
x_126 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__11;
lean_inc(x_119);
lean_ctor_set_tag(x_83, 2);
lean_ctor_set(x_83, 1, x_126);
lean_ctor_set(x_83, 0, x_119);
lean_inc(x_119);
x_127 = l_Lean_Syntax_node2(x_119, x_124, x_125, x_83);
x_128 = l_Lean_Syntax_SepArray_ofElems(x_121, x_89);
lean_dec(x_89);
lean_inc(x_4);
x_129 = l_Array_append___rarg(x_4, x_128);
lean_dec(x_128);
lean_inc(x_119);
x_130 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_130, 0, x_119);
lean_ctor_set(x_130, 1, x_124);
lean_ctor_set(x_130, 2, x_129);
lean_inc(x_119);
x_131 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_131, 0, x_119);
lean_ctor_set(x_131, 1, x_124);
lean_ctor_set(x_131, 2, x_4);
x_132 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__13;
lean_inc(x_131);
lean_inc(x_119);
x_133 = l_Lean_Syntax_node1(x_119, x_132, x_131);
x_134 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_119);
lean_ctor_set_tag(x_10, 2);
lean_ctor_set(x_10, 1, x_134);
lean_ctor_set(x_10, 0, x_119);
x_135 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__10;
x_136 = l_Lean_Syntax_node6(x_119, x_135, x_87, x_127, x_130, x_133, x_131, x_10);
x_137 = l_ProofWidgets_Jsx_transformTag___lambda__2(x_14, x_5, x_12, x_136, x_8, x_90);
return x_137;
}
else
{
lean_object* x_138; lean_object* x_139; 
lean_free_object(x_87);
lean_dec(x_89);
lean_free_object(x_83);
lean_free_object(x_10);
lean_dec(x_4);
x_138 = lean_array_fget(x_85, x_70);
lean_dec(x_85);
x_139 = l_ProofWidgets_Jsx_transformTag___lambda__2(x_14, x_5, x_12, x_138, x_8, x_90);
return x_139;
}
}
}
else
{
lean_object* x_140; lean_object* x_141; lean_object* x_142; lean_object* x_143; uint8_t x_144; 
x_140 = lean_ctor_get(x_87, 0);
x_141 = lean_ctor_get(x_87, 1);
lean_inc(x_141);
lean_inc(x_140);
lean_dec(x_87);
x_142 = lean_array_get_size(x_85);
x_143 = lean_unsigned_to_nat(1u);
x_144 = lean_nat_dec_eq(x_142, x_143);
lean_dec(x_142);
if (x_144 == 0)
{
lean_object* x_145; uint8_t x_146; lean_object* x_147; lean_object* x_148; lean_object* x_149; lean_object* x_150; lean_object* x_151; lean_object* x_152; lean_object* x_153; lean_object* x_154; lean_object* x_155; lean_object* x_156; lean_object* x_157; lean_object* x_158; lean_object* x_159; lean_object* x_160; lean_object* x_161; lean_object* x_162; lean_object* x_163; lean_object* x_164; lean_object* x_165; lean_object* x_166; 
x_145 = lean_ctor_get(x_8, 5);
lean_inc(x_145);
x_146 = 0;
x_147 = l_Lean_SourceInfo_fromRef(x_145, x_146);
lean_dec(x_145);
x_148 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_147);
x_149 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_149, 0, x_147);
lean_ctor_set(x_149, 1, x_148);
x_150 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__7;
x_151 = l_Lean_Syntax_SepArray_ofElems(x_150, x_85);
lean_dec(x_85);
lean_inc(x_4);
x_152 = l_Array_append___rarg(x_4, x_151);
lean_dec(x_151);
x_153 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_147);
x_154 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_154, 0, x_147);
lean_ctor_set(x_154, 1, x_153);
lean_ctor_set(x_154, 2, x_152);
x_155 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__11;
lean_inc(x_147);
lean_ctor_set_tag(x_83, 2);
lean_ctor_set(x_83, 1, x_155);
lean_ctor_set(x_83, 0, x_147);
lean_inc(x_147);
x_156 = l_Lean_Syntax_node2(x_147, x_153, x_154, x_83);
x_157 = l_Lean_Syntax_SepArray_ofElems(x_150, x_140);
lean_dec(x_140);
lean_inc(x_4);
x_158 = l_Array_append___rarg(x_4, x_157);
lean_dec(x_157);
lean_inc(x_147);
x_159 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_159, 0, x_147);
lean_ctor_set(x_159, 1, x_153);
lean_ctor_set(x_159, 2, x_158);
lean_inc(x_147);
x_160 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_160, 0, x_147);
lean_ctor_set(x_160, 1, x_153);
lean_ctor_set(x_160, 2, x_4);
x_161 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__13;
lean_inc(x_160);
lean_inc(x_147);
x_162 = l_Lean_Syntax_node1(x_147, x_161, x_160);
x_163 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_147);
lean_ctor_set_tag(x_10, 2);
lean_ctor_set(x_10, 1, x_163);
lean_ctor_set(x_10, 0, x_147);
x_164 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__10;
x_165 = l_Lean_Syntax_node6(x_147, x_164, x_149, x_156, x_159, x_162, x_160, x_10);
x_166 = l_ProofWidgets_Jsx_transformTag___lambda__2(x_14, x_5, x_12, x_165, x_8, x_141);
return x_166;
}
else
{
lean_object* x_167; uint8_t x_168; 
x_167 = lean_array_get_size(x_140);
x_168 = lean_nat_dec_eq(x_167, x_70);
lean_dec(x_167);
if (x_168 == 0)
{
lean_object* x_169; uint8_t x_170; lean_object* x_171; lean_object* x_172; lean_object* x_173; lean_object* x_174; lean_object* x_175; lean_object* x_176; lean_object* x_177; lean_object* x_178; lean_object* x_179; lean_object* x_180; lean_object* x_181; lean_object* x_182; lean_object* x_183; lean_object* x_184; lean_object* x_185; lean_object* x_186; lean_object* x_187; lean_object* x_188; lean_object* x_189; lean_object* x_190; 
x_169 = lean_ctor_get(x_8, 5);
lean_inc(x_169);
x_170 = 0;
x_171 = l_Lean_SourceInfo_fromRef(x_169, x_170);
lean_dec(x_169);
x_172 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_171);
x_173 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_173, 0, x_171);
lean_ctor_set(x_173, 1, x_172);
x_174 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__7;
x_175 = l_Lean_Syntax_SepArray_ofElems(x_174, x_85);
lean_dec(x_85);
lean_inc(x_4);
x_176 = l_Array_append___rarg(x_4, x_175);
lean_dec(x_175);
x_177 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_171);
x_178 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_178, 0, x_171);
lean_ctor_set(x_178, 1, x_177);
lean_ctor_set(x_178, 2, x_176);
x_179 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__11;
lean_inc(x_171);
lean_ctor_set_tag(x_83, 2);
lean_ctor_set(x_83, 1, x_179);
lean_ctor_set(x_83, 0, x_171);
lean_inc(x_171);
x_180 = l_Lean_Syntax_node2(x_171, x_177, x_178, x_83);
x_181 = l_Lean_Syntax_SepArray_ofElems(x_174, x_140);
lean_dec(x_140);
lean_inc(x_4);
x_182 = l_Array_append___rarg(x_4, x_181);
lean_dec(x_181);
lean_inc(x_171);
x_183 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_183, 0, x_171);
lean_ctor_set(x_183, 1, x_177);
lean_ctor_set(x_183, 2, x_182);
lean_inc(x_171);
x_184 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_184, 0, x_171);
lean_ctor_set(x_184, 1, x_177);
lean_ctor_set(x_184, 2, x_4);
x_185 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__13;
lean_inc(x_184);
lean_inc(x_171);
x_186 = l_Lean_Syntax_node1(x_171, x_185, x_184);
x_187 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_171);
lean_ctor_set_tag(x_10, 2);
lean_ctor_set(x_10, 1, x_187);
lean_ctor_set(x_10, 0, x_171);
x_188 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__10;
x_189 = l_Lean_Syntax_node6(x_171, x_188, x_173, x_180, x_183, x_186, x_184, x_10);
x_190 = l_ProofWidgets_Jsx_transformTag___lambda__2(x_14, x_5, x_12, x_189, x_8, x_141);
return x_190;
}
else
{
lean_object* x_191; lean_object* x_192; 
lean_dec(x_140);
lean_free_object(x_83);
lean_free_object(x_10);
lean_dec(x_4);
x_191 = lean_array_fget(x_85, x_70);
lean_dec(x_85);
x_192 = l_ProofWidgets_Jsx_transformTag___lambda__2(x_14, x_5, x_12, x_191, x_8, x_141);
return x_192;
}
}
}
}
else
{
lean_object* x_193; lean_object* x_194; lean_object* x_195; lean_object* x_196; lean_object* x_197; lean_object* x_198; lean_object* x_199; lean_object* x_200; uint8_t x_201; 
x_193 = lean_ctor_get(x_83, 0);
x_194 = lean_ctor_get(x_83, 1);
lean_inc(x_194);
lean_inc(x_193);
lean_dec(x_83);
x_195 = l_Array_filterMapM___at_ProofWidgets_Jsx_transformTag___spec__10(x_14, x_17, x_70, x_82, x_8, x_194);
lean_dec(x_82);
lean_dec(x_17);
x_196 = lean_ctor_get(x_195, 0);
lean_inc(x_196);
x_197 = lean_ctor_get(x_195, 1);
lean_inc(x_197);
if (lean_is_exclusive(x_195)) {
 lean_ctor_release(x_195, 0);
 lean_ctor_release(x_195, 1);
 x_198 = x_195;
} else {
 lean_dec_ref(x_195);
 x_198 = lean_box(0);
}
x_199 = lean_array_get_size(x_193);
x_200 = lean_unsigned_to_nat(1u);
x_201 = lean_nat_dec_eq(x_199, x_200);
lean_dec(x_199);
if (x_201 == 0)
{
lean_object* x_202; uint8_t x_203; lean_object* x_204; lean_object* x_205; lean_object* x_206; lean_object* x_207; lean_object* x_208; lean_object* x_209; lean_object* x_210; lean_object* x_211; lean_object* x_212; lean_object* x_213; lean_object* x_214; lean_object* x_215; lean_object* x_216; lean_object* x_217; lean_object* x_218; lean_object* x_219; lean_object* x_220; lean_object* x_221; lean_object* x_222; lean_object* x_223; lean_object* x_224; 
x_202 = lean_ctor_get(x_8, 5);
lean_inc(x_202);
x_203 = 0;
x_204 = l_Lean_SourceInfo_fromRef(x_202, x_203);
lean_dec(x_202);
x_205 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_204);
if (lean_is_scalar(x_198)) {
 x_206 = lean_alloc_ctor(2, 2, 0);
} else {
 x_206 = x_198;
 lean_ctor_set_tag(x_206, 2);
}
lean_ctor_set(x_206, 0, x_204);
lean_ctor_set(x_206, 1, x_205);
x_207 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__7;
x_208 = l_Lean_Syntax_SepArray_ofElems(x_207, x_193);
lean_dec(x_193);
lean_inc(x_4);
x_209 = l_Array_append___rarg(x_4, x_208);
lean_dec(x_208);
x_210 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_204);
x_211 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_211, 0, x_204);
lean_ctor_set(x_211, 1, x_210);
lean_ctor_set(x_211, 2, x_209);
x_212 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__11;
lean_inc(x_204);
x_213 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_213, 0, x_204);
lean_ctor_set(x_213, 1, x_212);
lean_inc(x_204);
x_214 = l_Lean_Syntax_node2(x_204, x_210, x_211, x_213);
x_215 = l_Lean_Syntax_SepArray_ofElems(x_207, x_196);
lean_dec(x_196);
lean_inc(x_4);
x_216 = l_Array_append___rarg(x_4, x_215);
lean_dec(x_215);
lean_inc(x_204);
x_217 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_217, 0, x_204);
lean_ctor_set(x_217, 1, x_210);
lean_ctor_set(x_217, 2, x_216);
lean_inc(x_204);
x_218 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_218, 0, x_204);
lean_ctor_set(x_218, 1, x_210);
lean_ctor_set(x_218, 2, x_4);
x_219 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__13;
lean_inc(x_218);
lean_inc(x_204);
x_220 = l_Lean_Syntax_node1(x_204, x_219, x_218);
x_221 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_204);
lean_ctor_set_tag(x_10, 2);
lean_ctor_set(x_10, 1, x_221);
lean_ctor_set(x_10, 0, x_204);
x_222 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__10;
x_223 = l_Lean_Syntax_node6(x_204, x_222, x_206, x_214, x_217, x_220, x_218, x_10);
x_224 = l_ProofWidgets_Jsx_transformTag___lambda__2(x_14, x_5, x_12, x_223, x_8, x_197);
return x_224;
}
else
{
lean_object* x_225; uint8_t x_226; 
x_225 = lean_array_get_size(x_196);
x_226 = lean_nat_dec_eq(x_225, x_70);
lean_dec(x_225);
if (x_226 == 0)
{
lean_object* x_227; uint8_t x_228; lean_object* x_229; lean_object* x_230; lean_object* x_231; lean_object* x_232; lean_object* x_233; lean_object* x_234; lean_object* x_235; lean_object* x_236; lean_object* x_237; lean_object* x_238; lean_object* x_239; lean_object* x_240; lean_object* x_241; lean_object* x_242; lean_object* x_243; lean_object* x_244; lean_object* x_245; lean_object* x_246; lean_object* x_247; lean_object* x_248; lean_object* x_249; 
x_227 = lean_ctor_get(x_8, 5);
lean_inc(x_227);
x_228 = 0;
x_229 = l_Lean_SourceInfo_fromRef(x_227, x_228);
lean_dec(x_227);
x_230 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_229);
if (lean_is_scalar(x_198)) {
 x_231 = lean_alloc_ctor(2, 2, 0);
} else {
 x_231 = x_198;
 lean_ctor_set_tag(x_231, 2);
}
lean_ctor_set(x_231, 0, x_229);
lean_ctor_set(x_231, 1, x_230);
x_232 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__7;
x_233 = l_Lean_Syntax_SepArray_ofElems(x_232, x_193);
lean_dec(x_193);
lean_inc(x_4);
x_234 = l_Array_append___rarg(x_4, x_233);
lean_dec(x_233);
x_235 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_229);
x_236 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_236, 0, x_229);
lean_ctor_set(x_236, 1, x_235);
lean_ctor_set(x_236, 2, x_234);
x_237 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__11;
lean_inc(x_229);
x_238 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_238, 0, x_229);
lean_ctor_set(x_238, 1, x_237);
lean_inc(x_229);
x_239 = l_Lean_Syntax_node2(x_229, x_235, x_236, x_238);
x_240 = l_Lean_Syntax_SepArray_ofElems(x_232, x_196);
lean_dec(x_196);
lean_inc(x_4);
x_241 = l_Array_append___rarg(x_4, x_240);
lean_dec(x_240);
lean_inc(x_229);
x_242 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_242, 0, x_229);
lean_ctor_set(x_242, 1, x_235);
lean_ctor_set(x_242, 2, x_241);
lean_inc(x_229);
x_243 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_243, 0, x_229);
lean_ctor_set(x_243, 1, x_235);
lean_ctor_set(x_243, 2, x_4);
x_244 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__13;
lean_inc(x_243);
lean_inc(x_229);
x_245 = l_Lean_Syntax_node1(x_229, x_244, x_243);
x_246 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_229);
lean_ctor_set_tag(x_10, 2);
lean_ctor_set(x_10, 1, x_246);
lean_ctor_set(x_10, 0, x_229);
x_247 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__10;
x_248 = l_Lean_Syntax_node6(x_229, x_247, x_231, x_239, x_242, x_245, x_243, x_10);
x_249 = l_ProofWidgets_Jsx_transformTag___lambda__2(x_14, x_5, x_12, x_248, x_8, x_197);
return x_249;
}
else
{
lean_object* x_250; lean_object* x_251; 
lean_dec(x_198);
lean_dec(x_196);
lean_free_object(x_10);
lean_dec(x_4);
x_250 = lean_array_fget(x_193, x_70);
lean_dec(x_193);
x_251 = l_ProofWidgets_Jsx_transformTag___lambda__2(x_14, x_5, x_12, x_250, x_8, x_197);
return x_251;
}
}
}
}
}
}
block_69:
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; 
lean_dec(x_21);
x_22 = lean_box_usize(x_2);
x_23 = lean_alloc_closure((void*)(l_ProofWidgets_Jsx_transformTag___lambda__1___boxed), 6, 3);
lean_closure_set(x_23, 0, x_14);
lean_closure_set(x_23, 1, x_22);
lean_closure_set(x_23, 2, x_4);
lean_inc(x_8);
x_24 = l_ProofWidgets_Util_foldInlsM___at_ProofWidgets_Jsx_transformTag___spec__6(x_17, x_23, x_8, x_18);
lean_dec(x_17);
if (lean_obj_tag(x_24) == 0)
{
lean_object* x_25; lean_object* x_26; lean_object* x_27; uint8_t x_28; 
x_25 = lean_ctor_get(x_24, 0);
lean_inc(x_25);
x_26 = lean_ctor_get(x_24, 1);
lean_inc(x_26);
lean_dec(x_24);
x_27 = l_ProofWidgets_Util_joinArrays___at_ProofWidgets_Jsx_transformTag___spec__2(x_25, x_8, x_26);
lean_dec(x_25);
x_28 = !lean_is_exclusive(x_27);
if (x_28 == 0)
{
lean_object* x_29; lean_object* x_30; uint8_t x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; 
x_29 = lean_ctor_get(x_27, 0);
x_30 = lean_ctor_get(x_8, 5);
lean_inc(x_30);
x_31 = 0;
x_32 = l_Lean_SourceInfo_fromRef(x_30, x_31);
lean_dec(x_30);
x_33 = lean_ctor_get(x_8, 2);
lean_inc(x_33);
x_34 = lean_ctor_get(x_8, 1);
lean_inc(x_34);
lean_dec(x_8);
x_35 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__3;
x_36 = l_Lean_addMacroScope(x_34, x_35, x_33);
x_37 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__2;
x_38 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__8;
lean_inc(x_32);
x_39 = lean_alloc_ctor(3, 4, 0);
lean_ctor_set(x_39, 0, x_32);
lean_ctor_set(x_39, 1, x_37);
lean_ctor_set(x_39, 2, x_36);
lean_ctor_set(x_39, 3, x_38);
x_40 = lean_box(2);
x_41 = l_Lean_Syntax_mkStrLit(x_20, x_40);
lean_dec(x_20);
x_42 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_32);
x_43 = l_Lean_Syntax_node3(x_32, x_42, x_41, x_29, x_12);
x_44 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__10;
x_45 = l_Lean_Syntax_node2(x_32, x_44, x_39, x_43);
lean_ctor_set(x_27, 0, x_45);
return x_27;
}
else
{
lean_object* x_46; lean_object* x_47; lean_object* x_48; uint8_t x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; 
x_46 = lean_ctor_get(x_27, 0);
x_47 = lean_ctor_get(x_27, 1);
lean_inc(x_47);
lean_inc(x_46);
lean_dec(x_27);
x_48 = lean_ctor_get(x_8, 5);
lean_inc(x_48);
x_49 = 0;
x_50 = l_Lean_SourceInfo_fromRef(x_48, x_49);
lean_dec(x_48);
x_51 = lean_ctor_get(x_8, 2);
lean_inc(x_51);
x_52 = lean_ctor_get(x_8, 1);
lean_inc(x_52);
lean_dec(x_8);
x_53 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__3;
x_54 = l_Lean_addMacroScope(x_52, x_53, x_51);
x_55 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__2;
x_56 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__8;
lean_inc(x_50);
x_57 = lean_alloc_ctor(3, 4, 0);
lean_ctor_set(x_57, 0, x_50);
lean_ctor_set(x_57, 1, x_55);
lean_ctor_set(x_57, 2, x_54);
lean_ctor_set(x_57, 3, x_56);
x_58 = lean_box(2);
x_59 = l_Lean_Syntax_mkStrLit(x_20, x_58);
lean_dec(x_20);
x_60 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_50);
x_61 = l_Lean_Syntax_node3(x_50, x_60, x_59, x_46, x_12);
x_62 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__10;
x_63 = l_Lean_Syntax_node2(x_50, x_62, x_57, x_61);
x_64 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_64, 0, x_63);
lean_ctor_set(x_64, 1, x_47);
return x_64;
}
}
else
{
uint8_t x_65; 
lean_dec(x_20);
lean_dec(x_12);
lean_dec(x_8);
x_65 = !lean_is_exclusive(x_24);
if (x_65 == 0)
{
return x_24;
}
else
{
lean_object* x_66; lean_object* x_67; lean_object* x_68; 
x_66 = lean_ctor_get(x_24, 0);
x_67 = lean_ctor_get(x_24, 1);
lean_inc(x_67);
lean_inc(x_66);
lean_dec(x_24);
x_68 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_68, 0, x_66);
lean_ctor_set(x_68, 1, x_67);
return x_68;
}
}
}
}
else
{
uint8_t x_252; 
lean_free_object(x_10);
lean_dec(x_12);
lean_dec(x_8);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
x_252 = !lean_is_exclusive(x_16);
if (x_252 == 0)
{
return x_16;
}
else
{
lean_object* x_253; lean_object* x_254; lean_object* x_255; 
x_253 = lean_ctor_get(x_16, 0);
x_254 = lean_ctor_get(x_16, 1);
lean_inc(x_254);
lean_inc(x_253);
lean_dec(x_16);
x_255 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_255, 0, x_253);
lean_ctor_set(x_255, 1, x_254);
return x_255;
}
}
}
else
{
lean_object* x_256; lean_object* x_257; lean_object* x_258; size_t x_259; lean_object* x_260; 
x_256 = lean_ctor_get(x_10, 0);
x_257 = lean_ctor_get(x_10, 1);
lean_inc(x_257);
lean_inc(x_256);
lean_dec(x_10);
x_258 = lean_box(0);
x_259 = lean_array_size(x_1);
lean_inc(x_8);
x_260 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__4(x_259, x_2, x_1, x_8, x_257);
if (lean_obj_tag(x_260) == 0)
{
lean_object* x_261; lean_object* x_262; uint8_t x_263; lean_object* x_264; lean_object* x_265; lean_object* x_297; lean_object* x_298; 
x_261 = lean_ctor_get(x_260, 0);
lean_inc(x_261);
x_262 = lean_ctor_get(x_260, 1);
lean_inc(x_262);
lean_dec(x_260);
x_263 = 1;
x_264 = l_Lean_Name_toString(x_3, x_263);
x_297 = lean_unsigned_to_nat(0u);
x_298 = lean_string_utf8_get_opt(x_264, x_297);
if (lean_obj_tag(x_298) == 0)
{
lean_object* x_299; 
lean_dec(x_5);
x_299 = lean_box(0);
x_265 = x_299;
goto block_296;
}
else
{
lean_object* x_300; uint32_t x_301; uint32_t x_302; uint8_t x_303; 
x_300 = lean_ctor_get(x_298, 0);
lean_inc(x_300);
lean_dec(x_298);
x_301 = 65;
x_302 = lean_unbox_uint32(x_300);
x_303 = lean_uint32_dec_le(x_301, x_302);
if (x_303 == 0)
{
lean_object* x_304; 
lean_dec(x_300);
lean_dec(x_5);
x_304 = lean_box(0);
x_265 = x_304;
goto block_296;
}
else
{
uint32_t x_305; uint32_t x_306; uint8_t x_307; 
x_305 = 90;
x_306 = lean_unbox_uint32(x_300);
lean_dec(x_300);
x_307 = lean_uint32_dec_le(x_306, x_305);
if (x_307 == 0)
{
lean_object* x_308; 
lean_dec(x_5);
x_308 = lean_box(0);
x_265 = x_308;
goto block_296;
}
else
{
lean_object* x_309; lean_object* x_310; lean_object* x_311; lean_object* x_312; lean_object* x_313; lean_object* x_314; lean_object* x_315; lean_object* x_316; lean_object* x_317; lean_object* x_318; lean_object* x_319; uint8_t x_320; 
lean_dec(x_264);
x_309 = lean_array_get_size(x_261);
x_310 = l_Array_filterMapM___at_ProofWidgets_Jsx_transformTag___spec__8(x_261, x_297, x_309, x_8, x_262);
x_311 = lean_ctor_get(x_310, 0);
lean_inc(x_311);
x_312 = lean_ctor_get(x_310, 1);
lean_inc(x_312);
if (lean_is_exclusive(x_310)) {
 lean_ctor_release(x_310, 0);
 lean_ctor_release(x_310, 1);
 x_313 = x_310;
} else {
 lean_dec_ref(x_310);
 x_313 = lean_box(0);
}
x_314 = l_Array_filterMapM___at_ProofWidgets_Jsx_transformTag___spec__10(x_258, x_261, x_297, x_309, x_8, x_312);
lean_dec(x_309);
lean_dec(x_261);
x_315 = lean_ctor_get(x_314, 0);
lean_inc(x_315);
x_316 = lean_ctor_get(x_314, 1);
lean_inc(x_316);
if (lean_is_exclusive(x_314)) {
 lean_ctor_release(x_314, 0);
 lean_ctor_release(x_314, 1);
 x_317 = x_314;
} else {
 lean_dec_ref(x_314);
 x_317 = lean_box(0);
}
x_318 = lean_array_get_size(x_311);
x_319 = lean_unsigned_to_nat(1u);
x_320 = lean_nat_dec_eq(x_318, x_319);
lean_dec(x_318);
if (x_320 == 0)
{
lean_object* x_321; uint8_t x_322; lean_object* x_323; lean_object* x_324; lean_object* x_325; lean_object* x_326; lean_object* x_327; lean_object* x_328; lean_object* x_329; lean_object* x_330; lean_object* x_331; lean_object* x_332; lean_object* x_333; lean_object* x_334; lean_object* x_335; lean_object* x_336; lean_object* x_337; lean_object* x_338; lean_object* x_339; lean_object* x_340; lean_object* x_341; lean_object* x_342; lean_object* x_343; lean_object* x_344; 
x_321 = lean_ctor_get(x_8, 5);
lean_inc(x_321);
x_322 = 0;
x_323 = l_Lean_SourceInfo_fromRef(x_321, x_322);
lean_dec(x_321);
x_324 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_323);
if (lean_is_scalar(x_317)) {
 x_325 = lean_alloc_ctor(2, 2, 0);
} else {
 x_325 = x_317;
 lean_ctor_set_tag(x_325, 2);
}
lean_ctor_set(x_325, 0, x_323);
lean_ctor_set(x_325, 1, x_324);
x_326 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__7;
x_327 = l_Lean_Syntax_SepArray_ofElems(x_326, x_311);
lean_dec(x_311);
lean_inc(x_4);
x_328 = l_Array_append___rarg(x_4, x_327);
lean_dec(x_327);
x_329 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_323);
x_330 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_330, 0, x_323);
lean_ctor_set(x_330, 1, x_329);
lean_ctor_set(x_330, 2, x_328);
x_331 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__11;
lean_inc(x_323);
if (lean_is_scalar(x_313)) {
 x_332 = lean_alloc_ctor(2, 2, 0);
} else {
 x_332 = x_313;
 lean_ctor_set_tag(x_332, 2);
}
lean_ctor_set(x_332, 0, x_323);
lean_ctor_set(x_332, 1, x_331);
lean_inc(x_323);
x_333 = l_Lean_Syntax_node2(x_323, x_329, x_330, x_332);
x_334 = l_Lean_Syntax_SepArray_ofElems(x_326, x_315);
lean_dec(x_315);
lean_inc(x_4);
x_335 = l_Array_append___rarg(x_4, x_334);
lean_dec(x_334);
lean_inc(x_323);
x_336 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_336, 0, x_323);
lean_ctor_set(x_336, 1, x_329);
lean_ctor_set(x_336, 2, x_335);
lean_inc(x_323);
x_337 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_337, 0, x_323);
lean_ctor_set(x_337, 1, x_329);
lean_ctor_set(x_337, 2, x_4);
x_338 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__13;
lean_inc(x_337);
lean_inc(x_323);
x_339 = l_Lean_Syntax_node1(x_323, x_338, x_337);
x_340 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_323);
x_341 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_341, 0, x_323);
lean_ctor_set(x_341, 1, x_340);
x_342 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__10;
x_343 = l_Lean_Syntax_node6(x_323, x_342, x_325, x_333, x_336, x_339, x_337, x_341);
x_344 = l_ProofWidgets_Jsx_transformTag___lambda__2(x_258, x_5, x_256, x_343, x_8, x_316);
return x_344;
}
else
{
lean_object* x_345; uint8_t x_346; 
x_345 = lean_array_get_size(x_315);
x_346 = lean_nat_dec_eq(x_345, x_297);
lean_dec(x_345);
if (x_346 == 0)
{
lean_object* x_347; uint8_t x_348; lean_object* x_349; lean_object* x_350; lean_object* x_351; lean_object* x_352; lean_object* x_353; lean_object* x_354; lean_object* x_355; lean_object* x_356; lean_object* x_357; lean_object* x_358; lean_object* x_359; lean_object* x_360; lean_object* x_361; lean_object* x_362; lean_object* x_363; lean_object* x_364; lean_object* x_365; lean_object* x_366; lean_object* x_367; lean_object* x_368; lean_object* x_369; lean_object* x_370; 
x_347 = lean_ctor_get(x_8, 5);
lean_inc(x_347);
x_348 = 0;
x_349 = l_Lean_SourceInfo_fromRef(x_347, x_348);
lean_dec(x_347);
x_350 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_349);
if (lean_is_scalar(x_317)) {
 x_351 = lean_alloc_ctor(2, 2, 0);
} else {
 x_351 = x_317;
 lean_ctor_set_tag(x_351, 2);
}
lean_ctor_set(x_351, 0, x_349);
lean_ctor_set(x_351, 1, x_350);
x_352 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__7;
x_353 = l_Lean_Syntax_SepArray_ofElems(x_352, x_311);
lean_dec(x_311);
lean_inc(x_4);
x_354 = l_Array_append___rarg(x_4, x_353);
lean_dec(x_353);
x_355 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_349);
x_356 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_356, 0, x_349);
lean_ctor_set(x_356, 1, x_355);
lean_ctor_set(x_356, 2, x_354);
x_357 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__11;
lean_inc(x_349);
if (lean_is_scalar(x_313)) {
 x_358 = lean_alloc_ctor(2, 2, 0);
} else {
 x_358 = x_313;
 lean_ctor_set_tag(x_358, 2);
}
lean_ctor_set(x_358, 0, x_349);
lean_ctor_set(x_358, 1, x_357);
lean_inc(x_349);
x_359 = l_Lean_Syntax_node2(x_349, x_355, x_356, x_358);
x_360 = l_Lean_Syntax_SepArray_ofElems(x_352, x_315);
lean_dec(x_315);
lean_inc(x_4);
x_361 = l_Array_append___rarg(x_4, x_360);
lean_dec(x_360);
lean_inc(x_349);
x_362 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_362, 0, x_349);
lean_ctor_set(x_362, 1, x_355);
lean_ctor_set(x_362, 2, x_361);
lean_inc(x_349);
x_363 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_363, 0, x_349);
lean_ctor_set(x_363, 1, x_355);
lean_ctor_set(x_363, 2, x_4);
x_364 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__13;
lean_inc(x_363);
lean_inc(x_349);
x_365 = l_Lean_Syntax_node1(x_349, x_364, x_363);
x_366 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_349);
x_367 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_367, 0, x_349);
lean_ctor_set(x_367, 1, x_366);
x_368 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__10;
x_369 = l_Lean_Syntax_node6(x_349, x_368, x_351, x_359, x_362, x_365, x_363, x_367);
x_370 = l_ProofWidgets_Jsx_transformTag___lambda__2(x_258, x_5, x_256, x_369, x_8, x_316);
return x_370;
}
else
{
lean_object* x_371; lean_object* x_372; 
lean_dec(x_317);
lean_dec(x_315);
lean_dec(x_313);
lean_dec(x_4);
x_371 = lean_array_fget(x_311, x_297);
lean_dec(x_311);
x_372 = l_ProofWidgets_Jsx_transformTag___lambda__2(x_258, x_5, x_256, x_371, x_8, x_316);
return x_372;
}
}
}
}
}
block_296:
{
lean_object* x_266; lean_object* x_267; lean_object* x_268; 
lean_dec(x_265);
x_266 = lean_box_usize(x_2);
x_267 = lean_alloc_closure((void*)(l_ProofWidgets_Jsx_transformTag___lambda__1___boxed), 6, 3);
lean_closure_set(x_267, 0, x_258);
lean_closure_set(x_267, 1, x_266);
lean_closure_set(x_267, 2, x_4);
lean_inc(x_8);
x_268 = l_ProofWidgets_Util_foldInlsM___at_ProofWidgets_Jsx_transformTag___spec__6(x_261, x_267, x_8, x_262);
lean_dec(x_261);
if (lean_obj_tag(x_268) == 0)
{
lean_object* x_269; lean_object* x_270; lean_object* x_271; lean_object* x_272; lean_object* x_273; lean_object* x_274; lean_object* x_275; uint8_t x_276; lean_object* x_277; lean_object* x_278; lean_object* x_279; lean_object* x_280; lean_object* x_281; lean_object* x_282; lean_object* x_283; lean_object* x_284; lean_object* x_285; lean_object* x_286; lean_object* x_287; lean_object* x_288; lean_object* x_289; lean_object* x_290; lean_object* x_291; 
x_269 = lean_ctor_get(x_268, 0);
lean_inc(x_269);
x_270 = lean_ctor_get(x_268, 1);
lean_inc(x_270);
lean_dec(x_268);
x_271 = l_ProofWidgets_Util_joinArrays___at_ProofWidgets_Jsx_transformTag___spec__2(x_269, x_8, x_270);
lean_dec(x_269);
x_272 = lean_ctor_get(x_271, 0);
lean_inc(x_272);
x_273 = lean_ctor_get(x_271, 1);
lean_inc(x_273);
if (lean_is_exclusive(x_271)) {
 lean_ctor_release(x_271, 0);
 lean_ctor_release(x_271, 1);
 x_274 = x_271;
} else {
 lean_dec_ref(x_271);
 x_274 = lean_box(0);
}
x_275 = lean_ctor_get(x_8, 5);
lean_inc(x_275);
x_276 = 0;
x_277 = l_Lean_SourceInfo_fromRef(x_275, x_276);
lean_dec(x_275);
x_278 = lean_ctor_get(x_8, 2);
lean_inc(x_278);
x_279 = lean_ctor_get(x_8, 1);
lean_inc(x_279);
lean_dec(x_8);
x_280 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__3;
x_281 = l_Lean_addMacroScope(x_279, x_280, x_278);
x_282 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__2;
x_283 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__8;
lean_inc(x_277);
x_284 = lean_alloc_ctor(3, 4, 0);
lean_ctor_set(x_284, 0, x_277);
lean_ctor_set(x_284, 1, x_282);
lean_ctor_set(x_284, 2, x_281);
lean_ctor_set(x_284, 3, x_283);
x_285 = lean_box(2);
x_286 = l_Lean_Syntax_mkStrLit(x_264, x_285);
lean_dec(x_264);
x_287 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_277);
x_288 = l_Lean_Syntax_node3(x_277, x_287, x_286, x_272, x_256);
x_289 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__10;
x_290 = l_Lean_Syntax_node2(x_277, x_289, x_284, x_288);
if (lean_is_scalar(x_274)) {
 x_291 = lean_alloc_ctor(0, 2, 0);
} else {
 x_291 = x_274;
}
lean_ctor_set(x_291, 0, x_290);
lean_ctor_set(x_291, 1, x_273);
return x_291;
}
else
{
lean_object* x_292; lean_object* x_293; lean_object* x_294; lean_object* x_295; 
lean_dec(x_264);
lean_dec(x_256);
lean_dec(x_8);
x_292 = lean_ctor_get(x_268, 0);
lean_inc(x_292);
x_293 = lean_ctor_get(x_268, 1);
lean_inc(x_293);
if (lean_is_exclusive(x_268)) {
 lean_ctor_release(x_268, 0);
 lean_ctor_release(x_268, 1);
 x_294 = x_268;
} else {
 lean_dec_ref(x_268);
 x_294 = lean_box(0);
}
if (lean_is_scalar(x_294)) {
 x_295 = lean_alloc_ctor(1, 2, 0);
} else {
 x_295 = x_294;
}
lean_ctor_set(x_295, 0, x_292);
lean_ctor_set(x_295, 1, x_293);
return x_295;
}
}
}
else
{
lean_object* x_373; lean_object* x_374; lean_object* x_375; lean_object* x_376; 
lean_dec(x_256);
lean_dec(x_8);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
x_373 = lean_ctor_get(x_260, 0);
lean_inc(x_373);
x_374 = lean_ctor_get(x_260, 1);
lean_inc(x_374);
if (lean_is_exclusive(x_260)) {
 lean_ctor_release(x_260, 0);
 lean_ctor_release(x_260, 1);
 x_375 = x_260;
} else {
 lean_dec_ref(x_260);
 x_375 = lean_box(0);
}
if (lean_is_scalar(x_375)) {
 x_376 = lean_alloc_ctor(1, 2, 0);
} else {
 x_376 = x_375;
}
lean_ctor_set(x_376, 0, x_373);
lean_ctor_set(x_376, 1, x_374);
return x_376;
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_transformTag___lambda__4(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; size_t x_10; size_t x_11; lean_object* x_12; 
x_9 = l_Lean_Syntax_getTailInfo(x_1);
x_10 = lean_array_size(x_2);
x_11 = 0;
if (lean_obj_tag(x_9) == 0)
{
lean_object* x_92; lean_object* x_93; lean_object* x_94; lean_object* x_95; lean_object* x_96; 
x_92 = lean_ctor_get(x_9, 2);
lean_inc(x_92);
lean_dec(x_9);
x_93 = lean_ctor_get(x_92, 0);
lean_inc(x_93);
x_94 = lean_ctor_get(x_92, 1);
lean_inc(x_94);
x_95 = lean_ctor_get(x_92, 2);
lean_inc(x_95);
lean_dec(x_92);
x_96 = lean_string_utf8_extract(x_93, x_94, x_95);
lean_dec(x_95);
lean_dec(x_94);
lean_dec(x_93);
x_12 = x_96;
goto block_91;
}
else
{
lean_object* x_97; 
lean_dec(x_9);
x_97 = l_ProofWidgets_instInhabitedHtml___closed__2;
x_12 = x_97;
goto block_91;
}
block_91:
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; 
x_13 = l_ProofWidgets_instInhabitedHtml___closed__1;
x_14 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_14, 0, x_13);
lean_ctor_set(x_14, 1, x_12);
x_15 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_15, 0, x_13);
lean_ctor_set(x_15, 1, x_14);
lean_inc(x_7);
x_16 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1(x_13, x_2, x_10, x_11, x_15, x_7, x_8);
if (lean_obj_tag(x_16) == 0)
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; uint8_t x_20; 
x_17 = lean_ctor_get(x_16, 0);
lean_inc(x_17);
x_18 = lean_ctor_get(x_17, 1);
lean_inc(x_18);
x_19 = lean_ctor_get(x_16, 1);
lean_inc(x_19);
lean_dec(x_16);
x_20 = !lean_is_exclusive(x_17);
if (x_20 == 0)
{
lean_object* x_21; lean_object* x_22; uint8_t x_23; 
x_21 = lean_ctor_get(x_17, 0);
x_22 = lean_ctor_get(x_17, 1);
lean_dec(x_22);
x_23 = !lean_is_exclusive(x_18);
if (x_23 == 0)
{
lean_object* x_24; lean_object* x_25; uint8_t x_26; 
x_24 = lean_ctor_get(x_18, 0);
x_25 = lean_ctor_get(x_18, 1);
lean_dec(x_25);
x_26 = l_Array_isEmpty___rarg(x_21);
if (x_26 == 0)
{
lean_object* x_27; uint8_t x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; 
x_27 = lean_ctor_get(x_7, 5);
lean_inc(x_27);
x_28 = 0;
x_29 = l_Lean_SourceInfo_fromRef(x_27, x_28);
lean_dec(x_27);
x_30 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__4;
lean_inc(x_29);
lean_ctor_set_tag(x_18, 2);
lean_ctor_set(x_18, 1, x_30);
lean_ctor_set(x_18, 0, x_29);
x_31 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__7;
x_32 = l_Lean_Syntax_SepArray_ofElems(x_31, x_21);
lean_dec(x_21);
x_33 = l_Array_append___rarg(x_13, x_32);
lean_dec(x_32);
x_34 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_29);
x_35 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_35, 0, x_29);
lean_ctor_set(x_35, 1, x_34);
lean_ctor_set(x_35, 2, x_33);
x_36 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__8;
lean_inc(x_29);
lean_ctor_set_tag(x_17, 2);
lean_ctor_set(x_17, 1, x_36);
lean_ctor_set(x_17, 0, x_29);
x_37 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__3;
x_38 = l_Lean_Syntax_node3(x_29, x_37, x_18, x_35, x_17);
x_39 = lean_array_push(x_24, x_38);
x_40 = lean_box(0);
x_41 = l_ProofWidgets_Jsx_transformTag___lambda__3(x_3, x_11, x_4, x_13, x_5, x_39, x_40, x_7, x_19);
lean_dec(x_39);
return x_41;
}
else
{
lean_object* x_42; lean_object* x_43; 
lean_free_object(x_18);
lean_free_object(x_17);
lean_dec(x_21);
x_42 = lean_box(0);
x_43 = l_ProofWidgets_Jsx_transformTag___lambda__3(x_3, x_11, x_4, x_13, x_5, x_24, x_42, x_7, x_19);
lean_dec(x_24);
return x_43;
}
}
else
{
lean_object* x_44; uint8_t x_45; 
x_44 = lean_ctor_get(x_18, 0);
lean_inc(x_44);
lean_dec(x_18);
x_45 = l_Array_isEmpty___rarg(x_21);
if (x_45 == 0)
{
lean_object* x_46; uint8_t x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; 
x_46 = lean_ctor_get(x_7, 5);
lean_inc(x_46);
x_47 = 0;
x_48 = l_Lean_SourceInfo_fromRef(x_46, x_47);
lean_dec(x_46);
x_49 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__4;
lean_inc(x_48);
x_50 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_50, 0, x_48);
lean_ctor_set(x_50, 1, x_49);
x_51 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__7;
x_52 = l_Lean_Syntax_SepArray_ofElems(x_51, x_21);
lean_dec(x_21);
x_53 = l_Array_append___rarg(x_13, x_52);
lean_dec(x_52);
x_54 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_48);
x_55 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_55, 0, x_48);
lean_ctor_set(x_55, 1, x_54);
lean_ctor_set(x_55, 2, x_53);
x_56 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__8;
lean_inc(x_48);
lean_ctor_set_tag(x_17, 2);
lean_ctor_set(x_17, 1, x_56);
lean_ctor_set(x_17, 0, x_48);
x_57 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__3;
x_58 = l_Lean_Syntax_node3(x_48, x_57, x_50, x_55, x_17);
x_59 = lean_array_push(x_44, x_58);
x_60 = lean_box(0);
x_61 = l_ProofWidgets_Jsx_transformTag___lambda__3(x_3, x_11, x_4, x_13, x_5, x_59, x_60, x_7, x_19);
lean_dec(x_59);
return x_61;
}
else
{
lean_object* x_62; lean_object* x_63; 
lean_free_object(x_17);
lean_dec(x_21);
x_62 = lean_box(0);
x_63 = l_ProofWidgets_Jsx_transformTag___lambda__3(x_3, x_11, x_4, x_13, x_5, x_44, x_62, x_7, x_19);
lean_dec(x_44);
return x_63;
}
}
}
else
{
lean_object* x_64; lean_object* x_65; lean_object* x_66; uint8_t x_67; 
x_64 = lean_ctor_get(x_17, 0);
lean_inc(x_64);
lean_dec(x_17);
x_65 = lean_ctor_get(x_18, 0);
lean_inc(x_65);
if (lean_is_exclusive(x_18)) {
 lean_ctor_release(x_18, 0);
 lean_ctor_release(x_18, 1);
 x_66 = x_18;
} else {
 lean_dec_ref(x_18);
 x_66 = lean_box(0);
}
x_67 = l_Array_isEmpty___rarg(x_64);
if (x_67 == 0)
{
lean_object* x_68; uint8_t x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; lean_object* x_79; lean_object* x_80; lean_object* x_81; lean_object* x_82; lean_object* x_83; lean_object* x_84; 
x_68 = lean_ctor_get(x_7, 5);
lean_inc(x_68);
x_69 = 0;
x_70 = l_Lean_SourceInfo_fromRef(x_68, x_69);
lean_dec(x_68);
x_71 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__4;
lean_inc(x_70);
if (lean_is_scalar(x_66)) {
 x_72 = lean_alloc_ctor(2, 2, 0);
} else {
 x_72 = x_66;
 lean_ctor_set_tag(x_72, 2);
}
lean_ctor_set(x_72, 0, x_70);
lean_ctor_set(x_72, 1, x_71);
x_73 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__7;
x_74 = l_Lean_Syntax_SepArray_ofElems(x_73, x_64);
lean_dec(x_64);
x_75 = l_Array_append___rarg(x_13, x_74);
lean_dec(x_74);
x_76 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_70);
x_77 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_77, 0, x_70);
lean_ctor_set(x_77, 1, x_76);
lean_ctor_set(x_77, 2, x_75);
x_78 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__8;
lean_inc(x_70);
x_79 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_79, 0, x_70);
lean_ctor_set(x_79, 1, x_78);
x_80 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__3;
x_81 = l_Lean_Syntax_node3(x_70, x_80, x_72, x_77, x_79);
x_82 = lean_array_push(x_65, x_81);
x_83 = lean_box(0);
x_84 = l_ProofWidgets_Jsx_transformTag___lambda__3(x_3, x_11, x_4, x_13, x_5, x_82, x_83, x_7, x_19);
lean_dec(x_82);
return x_84;
}
else
{
lean_object* x_85; lean_object* x_86; 
lean_dec(x_66);
lean_dec(x_64);
x_85 = lean_box(0);
x_86 = l_ProofWidgets_Jsx_transformTag___lambda__3(x_3, x_11, x_4, x_13, x_5, x_65, x_85, x_7, x_19);
lean_dec(x_65);
return x_86;
}
}
}
else
{
uint8_t x_87; 
lean_dec(x_7);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
x_87 = !lean_is_exclusive(x_16);
if (x_87 == 0)
{
return x_16;
}
else
{
lean_object* x_88; lean_object* x_89; lean_object* x_90; 
x_88 = lean_ctor_get(x_16, 0);
x_89 = lean_ctor_get(x_16, 1);
lean_inc(x_89);
lean_inc(x_88);
lean_dec(x_16);
x_90 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_90, 0, x_88);
lean_ctor_set(x_90, 1, x_89);
return x_90;
}
}
}
}
}
static lean_object* _init_l_ProofWidgets_Jsx_transformTag___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("expected </", 11, 11);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_transformTag(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; uint8_t x_12; 
x_8 = l_Lean_Syntax_getId(x_2);
x_9 = lean_erase_macro_scopes(x_8);
x_10 = l_Lean_Syntax_getId(x_3);
x_11 = lean_erase_macro_scopes(x_10);
x_12 = lean_name_eq(x_9, x_11);
lean_dec(x_11);
if (x_12 == 0)
{
uint8_t x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; uint8_t x_20; 
lean_dec(x_4);
lean_dec(x_2);
x_13 = 1;
x_14 = l_Lean_Name_toString(x_9, x_13);
x_15 = l_ProofWidgets_Jsx_transformTag___closed__1;
x_16 = lean_string_append(x_15, x_14);
lean_dec(x_14);
x_17 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__3;
x_18 = lean_string_append(x_16, x_17);
x_19 = l_Lean_Macro_throwErrorAt___rarg(x_3, x_18, x_6, x_7);
x_20 = !lean_is_exclusive(x_19);
if (x_20 == 0)
{
return x_19;
}
else
{
lean_object* x_21; lean_object* x_22; lean_object* x_23; 
x_21 = lean_ctor_get(x_19, 0);
x_22 = lean_ctor_get(x_19, 1);
lean_inc(x_22);
lean_inc(x_21);
lean_dec(x_19);
x_23 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_23, 0, x_21);
lean_ctor_set(x_23, 1, x_22);
return x_23;
}
}
else
{
lean_object* x_24; lean_object* x_25; 
x_24 = lean_box(0);
x_25 = l_ProofWidgets_Jsx_transformTag___lambda__4(x_1, x_5, x_4, x_9, x_2, x_24, x_6, x_7);
return x_25;
}
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___lambda__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___lambda__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_4);
lean_dec(x_2);
return x_10;
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
size_t x_8; size_t x_9; lean_object* x_10; 
x_8 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_9 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_10 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1(x_1, x_2, x_8, x_9, x_5, x_6, x_7);
lean_dec(x_2);
return x_10;
}
}
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__3___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
size_t x_7; size_t x_8; lean_object* x_9; 
x_7 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_8 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_9 = l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__3(x_1, x_7, x_8, x_4, x_5, x_6);
lean_dec(x_5);
lean_dec(x_1);
return x_9;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_joinArrays___at_ProofWidgets_Jsx_transformTag___spec__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; 
x_4 = l_ProofWidgets_Util_joinArrays___at_ProofWidgets_Jsx_transformTag___spec__2(x_1, x_2, x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_4;
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__4___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
size_t x_6; size_t x_7; lean_object* x_8; 
x_6 = lean_unbox_usize(x_1);
lean_dec(x_1);
x_7 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_8 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__4(x_6, x_7, x_3, x_4, x_5);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__5___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
size_t x_7; size_t x_8; lean_object* x_9; 
x_7 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_8 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_9 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__5(x_1, x_7, x_8, x_4, x_5, x_6);
lean_dec(x_5);
lean_dec(x_1);
return x_9;
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__7___lambda__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__7___lambda__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_3);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__7___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
size_t x_9; size_t x_10; lean_object* x_11; 
x_9 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_10 = lean_unbox_usize(x_5);
lean_dec(x_5);
x_11 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__7(x_1, x_2, x_3, x_9, x_10, x_6, x_7, x_8);
lean_dec(x_3);
return x_11;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___at_ProofWidgets_Jsx_transformTag___spec__6___lambda__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_ProofWidgets_Util_foldInlsM___at_ProofWidgets_Jsx_transformTag___spec__6___lambda__1(x_1, x_2, x_3, x_4);
lean_dec(x_3);
lean_dec(x_2);
return x_5;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Util_foldInlsM___at_ProofWidgets_Jsx_transformTag___spec__6___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
lean_object* x_5; 
x_5 = l_ProofWidgets_Util_foldInlsM___at_ProofWidgets_Jsx_transformTag___spec__6(x_1, x_2, x_3, x_4);
lean_dec(x_1);
return x_5;
}
}
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__9___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
size_t x_7; size_t x_8; lean_object* x_9; 
x_7 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_8 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_9 = l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__9(x_1, x_7, x_8, x_4, x_5, x_6);
lean_dec(x_5);
lean_dec(x_1);
return x_9;
}
}
LEAN_EXPORT lean_object* l_Array_filterMapM___at_ProofWidgets_Jsx_transformTag___spec__8___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_Array_filterMapM___at_ProofWidgets_Jsx_transformTag___spec__8(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
size_t x_8; size_t x_9; lean_object* x_10; 
x_8 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_9 = lean_unbox_usize(x_4);
lean_dec(x_4);
x_10 = l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11(x_1, x_2, x_8, x_9, x_5, x_6, x_7);
lean_dec(x_6);
lean_dec(x_2);
lean_dec(x_1);
return x_10;
}
}
LEAN_EXPORT lean_object* l_Array_filterMapM___at_ProofWidgets_Jsx_transformTag___spec__10___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
lean_object* x_7; 
x_7 = l_Array_filterMapM___at_ProofWidgets_Jsx_transformTag___spec__10(x_1, x_2, x_3, x_4, x_5, x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_7;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_transformTag___lambda__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6) {
_start:
{
size_t x_7; lean_object* x_8; 
x_7 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_8 = l_ProofWidgets_Jsx_transformTag___lambda__1(x_1, x_7, x_3, x_4, x_5, x_6);
lean_dec(x_5);
lean_dec(x_1);
return x_8;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_transformTag___lambda__3___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
size_t x_10; lean_object* x_11; 
x_10 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_11 = l_ProofWidgets_Jsx_transformTag___lambda__3(x_1, x_10, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_7);
lean_dec(x_6);
return x_11;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_transformTag___lambda__4___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l_ProofWidgets_Jsx_transformTag___lambda__4(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
lean_dec(x_6);
lean_dec(x_2);
lean_dec(x_1);
return x_9;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_transformTag___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
x_8 = l_ProofWidgets_Jsx_transformTag(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
lean_dec(x_5);
lean_dec(x_3);
lean_dec(x_1);
return x_8;
}
}
LEAN_EXPORT lean_object* l_Array_sequenceMap_loop___at_ProofWidgets_Jsx___aux__ProofWidgets__Data__Html______macroRules__ProofWidgets__Jsx__term____1___spec__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; uint8_t x_7; 
x_6 = lean_array_get_size(x_1);
x_7 = lean_nat_dec_lt(x_4, x_6);
lean_dec(x_6);
if (x_7 == 0)
{
lean_object* x_8; 
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_8 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_8, 0, x_5);
return x_8;
}
else
{
lean_object* x_9; uint8_t x_10; 
x_9 = lean_unsigned_to_nat(0u);
x_10 = lean_nat_dec_eq(x_3, x_9);
if (x_10 == 0)
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; 
x_11 = lean_unsigned_to_nat(1u);
x_12 = lean_nat_sub(x_3, x_11);
lean_dec(x_3);
x_13 = lean_array_fget(x_1, x_4);
lean_inc(x_2);
x_14 = lean_apply_1(x_2, x_13);
if (lean_obj_tag(x_14) == 0)
{
lean_object* x_15; 
lean_dec(x_12);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_2);
x_15 = lean_box(0);
return x_15;
}
else
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_16 = lean_ctor_get(x_14, 0);
lean_inc(x_16);
lean_dec(x_14);
x_17 = lean_nat_add(x_4, x_11);
lean_dec(x_4);
x_18 = lean_array_push(x_5, x_16);
x_3 = x_12;
x_4 = x_17;
x_5 = x_18;
goto _start;
}
}
else
{
lean_object* x_20; 
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_20 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_20, 0, x_5);
return x_20;
}
}
}
}
LEAN_EXPORT lean_object* l_Array_sequenceMap___at_ProofWidgets_Jsx___aux__ProofWidgets__Data__Html______macroRules__ProofWidgets__Jsx__term____1___spec__1(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_3 = lean_array_get_size(x_1);
x_4 = lean_mk_empty_array_with_capacity(x_3);
x_5 = lean_unsigned_to_nat(0u);
x_6 = l_Array_sequenceMap_loop___at_ProofWidgets_Jsx___aux__ProofWidgets__Data__Html______macroRules__ProofWidgets__Jsx__term____1___spec__2(x_1, x_2, x_3, x_5, x_4);
return x_6;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx___aux__ProofWidgets__Data__Html______macroRules__ProofWidgets__Jsx__term____1___lambda__1(lean_object* x_1) {
_start:
{
lean_object* x_2; 
x_2 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Jsx___aux__ProofWidgets__Data__Html______macroRules__ProofWidgets__Jsx__term____1___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_Jsx___aux__ProofWidgets__Data__Html______macroRules__ProofWidgets__Jsx__term____1___lambda__1), 1, 0);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx___aux__ProofWidgets__Data__Html______macroRules__ProofWidgets__Jsx__term____1(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
lean_object* x_4; uint8_t x_5; 
x_4 = l_ProofWidgets_Jsx_term_____closed__2;
lean_inc(x_1);
x_5 = l_Lean_Syntax_isOfKind(x_1, x_4);
if (x_5 == 0)
{
lean_object* x_6; lean_object* x_7; 
lean_dec(x_2);
lean_dec(x_1);
x_6 = lean_box(1);
x_7 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_7, 0, x_6);
lean_ctor_set(x_7, 1, x_3);
return x_7;
}
else
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; uint8_t x_11; 
x_8 = lean_unsigned_to_nat(0u);
x_9 = l_Lean_Syntax_getArg(x_1, x_8);
lean_dec(x_1);
x_10 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__2;
lean_inc(x_9);
x_11 = l_Lean_Syntax_isOfKind(x_9, x_10);
if (x_11 == 0)
{
lean_object* x_12; uint8_t x_13; 
x_12 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__2;
lean_inc(x_9);
x_13 = l_Lean_Syntax_isOfKind(x_9, x_12);
if (x_13 == 0)
{
lean_object* x_14; lean_object* x_15; 
lean_dec(x_9);
lean_dec(x_2);
x_14 = lean_box(1);
x_15 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_15, 0, x_14);
lean_ctor_set(x_15, 1, x_3);
return x_15;
}
else
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; uint8_t x_19; 
x_16 = lean_unsigned_to_nat(1u);
x_17 = l_Lean_Syntax_getArg(x_9, x_16);
x_18 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__4;
lean_inc(x_17);
x_19 = l_Lean_Syntax_isOfKind(x_17, x_18);
if (x_19 == 0)
{
lean_object* x_20; lean_object* x_21; 
lean_dec(x_17);
lean_dec(x_9);
lean_dec(x_2);
x_20 = lean_box(1);
x_21 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_21, 0, x_20);
lean_ctor_set(x_21, 1, x_3);
return x_21;
}
else
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; 
x_22 = lean_unsigned_to_nat(2u);
x_23 = l_Lean_Syntax_getArg(x_9, x_22);
x_24 = l_Lean_Syntax_getArgs(x_23);
lean_dec(x_23);
x_25 = l_ProofWidgets_Jsx___aux__ProofWidgets__Data__Html______macroRules__ProofWidgets__Jsx__term____1___closed__1;
x_26 = l_Array_sequenceMap___at_ProofWidgets_Jsx___aux__ProofWidgets__Data__Html______macroRules__ProofWidgets__Jsx__term____1___spec__1(x_24, x_25);
lean_dec(x_24);
if (lean_obj_tag(x_26) == 0)
{
lean_object* x_27; lean_object* x_28; 
lean_dec(x_17);
lean_dec(x_9);
lean_dec(x_2);
x_27 = lean_box(1);
x_28 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_28, 0, x_27);
lean_ctor_set(x_28, 1, x_3);
return x_28;
}
else
{
lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; 
x_29 = lean_ctor_get(x_26, 0);
lean_inc(x_29);
lean_dec(x_26);
x_30 = lean_unsigned_to_nat(3u);
x_31 = l_Lean_Syntax_getArg(x_9, x_30);
x_32 = lean_unsigned_to_nat(4u);
x_33 = l_Lean_Syntax_getArg(x_9, x_32);
x_34 = lean_unsigned_to_nat(6u);
x_35 = l_Lean_Syntax_getArg(x_9, x_34);
lean_dec(x_9);
x_36 = l_Lean_Syntax_getArgs(x_33);
lean_dec(x_33);
x_37 = l_ProofWidgets_Jsx_transformTag(x_31, x_17, x_35, x_29, x_36, x_2, x_3);
lean_dec(x_36);
lean_dec(x_35);
lean_dec(x_31);
if (lean_obj_tag(x_37) == 0)
{
uint8_t x_38; 
x_38 = !lean_is_exclusive(x_37);
if (x_38 == 0)
{
return x_37;
}
else
{
lean_object* x_39; lean_object* x_40; lean_object* x_41; 
x_39 = lean_ctor_get(x_37, 0);
x_40 = lean_ctor_get(x_37, 1);
lean_inc(x_40);
lean_inc(x_39);
lean_dec(x_37);
x_41 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_41, 0, x_39);
lean_ctor_set(x_41, 1, x_40);
return x_41;
}
}
else
{
uint8_t x_42; 
x_42 = !lean_is_exclusive(x_37);
if (x_42 == 0)
{
return x_37;
}
else
{
lean_object* x_43; lean_object* x_44; lean_object* x_45; 
x_43 = lean_ctor_get(x_37, 0);
x_44 = lean_ctor_get(x_37, 1);
lean_inc(x_44);
lean_inc(x_43);
lean_dec(x_37);
x_45 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_45, 0, x_43);
lean_ctor_set(x_45, 1, x_44);
return x_45;
}
}
}
}
}
}
else
{
lean_object* x_46; lean_object* x_47; lean_object* x_48; uint8_t x_49; 
x_46 = lean_unsigned_to_nat(1u);
x_47 = l_Lean_Syntax_getArg(x_9, x_46);
x_48 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__4;
lean_inc(x_47);
x_49 = l_Lean_Syntax_isOfKind(x_47, x_48);
if (x_49 == 0)
{
lean_object* x_50; lean_object* x_51; 
lean_dec(x_47);
lean_dec(x_9);
lean_dec(x_2);
x_50 = lean_box(1);
x_51 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_51, 0, x_50);
lean_ctor_set(x_51, 1, x_3);
return x_51;
}
else
{
lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; 
x_52 = lean_unsigned_to_nat(2u);
x_53 = l_Lean_Syntax_getArg(x_9, x_52);
x_54 = l_Lean_Syntax_getArgs(x_53);
lean_dec(x_53);
x_55 = l_ProofWidgets_Jsx___aux__ProofWidgets__Data__Html______macroRules__ProofWidgets__Jsx__term____1___closed__1;
x_56 = l_Array_sequenceMap___at_ProofWidgets_Jsx___aux__ProofWidgets__Data__Html______macroRules__ProofWidgets__Jsx__term____1___spec__1(x_54, x_55);
lean_dec(x_54);
if (lean_obj_tag(x_56) == 0)
{
lean_object* x_57; lean_object* x_58; 
lean_dec(x_47);
lean_dec(x_9);
lean_dec(x_2);
x_57 = lean_box(1);
x_58 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_58, 0, x_57);
lean_ctor_set(x_58, 1, x_3);
return x_58;
}
else
{
lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; 
x_59 = lean_ctor_get(x_56, 0);
lean_inc(x_59);
lean_dec(x_56);
x_60 = lean_unsigned_to_nat(3u);
x_61 = l_Lean_Syntax_getArg(x_9, x_60);
lean_dec(x_9);
x_62 = l_ProofWidgets_instInhabitedHtml___closed__1;
lean_inc(x_47);
x_63 = l_ProofWidgets_Jsx_transformTag(x_61, x_47, x_47, x_59, x_62, x_2, x_3);
lean_dec(x_47);
lean_dec(x_61);
if (lean_obj_tag(x_63) == 0)
{
uint8_t x_64; 
x_64 = !lean_is_exclusive(x_63);
if (x_64 == 0)
{
return x_63;
}
else
{
lean_object* x_65; lean_object* x_66; lean_object* x_67; 
x_65 = lean_ctor_get(x_63, 0);
x_66 = lean_ctor_get(x_63, 1);
lean_inc(x_66);
lean_inc(x_65);
lean_dec(x_63);
x_67 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_67, 0, x_65);
lean_ctor_set(x_67, 1, x_66);
return x_67;
}
}
else
{
uint8_t x_68; 
x_68 = !lean_is_exclusive(x_63);
if (x_68 == 0)
{
return x_63;
}
else
{
lean_object* x_69; lean_object* x_70; lean_object* x_71; 
x_69 = lean_ctor_get(x_63, 0);
x_70 = lean_ctor_get(x_63, 1);
lean_inc(x_70);
lean_inc(x_69);
lean_dec(x_63);
x_71 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_71, 0, x_69);
lean_ctor_set(x_71, 1, x_70);
return x_71;
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_Array_sequenceMap_loop___at_ProofWidgets_Jsx___aux__ProofWidgets__Data__Html______macroRules__ProofWidgets__Jsx__term____1___spec__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_Array_sequenceMap_loop___at_ProofWidgets_Jsx___aux__ProofWidgets__Data__Html______macroRules__ProofWidgets__Jsx__term____1___spec__2(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_1);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Array_sequenceMap___at_ProofWidgets_Jsx___aux__ProofWidgets__Data__Html______macroRules__ProofWidgets__Jsx__term____1___spec__1___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Array_sequenceMap___at_ProofWidgets_Jsx___aux__ProofWidgets__Data__Html______macroRules__ProofWidgets__Jsx__term____1___spec__1(x_1, x_2);
lean_dec(x_1);
return x_3;
}
}
LEAN_EXPORT uint8_t l_String_anyAux___at_ProofWidgets_Jsx_delabHtmlText___spec__2(uint32_t x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
uint8_t x_5; 
x_5 = lean_nat_dec_lt(x_4, x_3);
if (x_5 == 0)
{
uint8_t x_6; 
lean_dec(x_4);
x_6 = 0;
return x_6;
}
else
{
uint32_t x_7; uint8_t x_8; 
x_7 = lean_string_utf8_get(x_2, x_4);
x_8 = lean_uint32_dec_eq(x_7, x_1);
if (x_8 == 0)
{
lean_object* x_9; 
x_9 = lean_string_utf8_next(x_2, x_4);
lean_dec(x_4);
x_4 = x_9;
goto _start;
}
else
{
uint8_t x_11; 
lean_dec(x_4);
x_11 = 1;
return x_11;
}
}
}
}
static lean_object* _init_l_String_anyAux___at_ProofWidgets_Jsx_delabHtmlText___spec__1___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Jsx_jsxTextForbidden;
x_2 = lean_string_utf8_byte_size(x_1);
return x_2;
}
}
LEAN_EXPORT uint8_t l_String_anyAux___at_ProofWidgets_Jsx_delabHtmlText___spec__1(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
uint8_t x_4; 
x_4 = lean_nat_dec_lt(x_3, x_2);
if (x_4 == 0)
{
uint8_t x_5; 
lean_dec(x_3);
x_5 = 0;
return x_5;
}
else
{
uint32_t x_6; lean_object* x_7; lean_object* x_8; lean_object* x_9; uint8_t x_10; 
x_6 = lean_string_utf8_get(x_1, x_3);
x_7 = l_ProofWidgets_Jsx_jsxTextForbidden;
x_8 = l_String_anyAux___at_ProofWidgets_Jsx_delabHtmlText___spec__1___closed__1;
x_9 = lean_unsigned_to_nat(0u);
x_10 = l_String_anyAux___at_ProofWidgets_Jsx_delabHtmlText___spec__2(x_6, x_7, x_8, x_9);
if (x_10 == 0)
{
lean_object* x_11; 
x_11 = lean_string_utf8_next(x_1, x_3);
lean_dec(x_3);
x_3 = x_11;
goto _start;
}
else
{
uint8_t x_13; 
lean_dec(x_3);
x_13 = 1;
return x_13;
}
}
}
}
static lean_object* _init_l_ProofWidgets_Jsx_delabHtmlText___lambda__1___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = lean_unsigned_to_nat(1u);
x_2 = lean_mk_empty_array_with_capacity(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlText___lambda__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; 
x_10 = lean_box(2);
x_11 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_11, 0, x_10);
lean_ctor_set(x_11, 1, x_1);
x_12 = l_ProofWidgets_Jsx_delabHtmlText___lambda__1___closed__1;
x_13 = lean_array_push(x_12, x_11);
x_14 = l_ProofWidgets_Jsx_jsxText___closed__2;
x_15 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_15, 0, x_10);
lean_ctor_set(x_15, 1, x_14);
lean_ctor_set(x_15, 2, x_13);
x_16 = l_Lean_PrettyPrinter_Delaborator_annotateTermLikeInfo___rarg(x_15, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
return x_16;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlText___lambda__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
if (lean_obj_tag(x_1) == 9)
{
lean_object* x_9; 
x_9 = lean_ctor_get(x_1, 0);
lean_inc(x_9);
lean_dec(x_1);
if (lean_obj_tag(x_9) == 0)
{
lean_object* x_10; 
lean_dec(x_9);
lean_dec(x_2);
x_10 = l_Lean_PrettyPrinter_Delaborator_failure___rarg(x_8);
return x_10;
}
else
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; uint8_t x_14; 
x_11 = lean_ctor_get(x_9, 0);
lean_inc(x_11);
lean_dec(x_9);
x_12 = lean_string_utf8_byte_size(x_11);
x_13 = lean_unsigned_to_nat(0u);
x_14 = l_String_anyAux___at_ProofWidgets_Jsx_delabHtmlText___spec__1(x_11, x_12, x_13);
lean_dec(x_12);
if (x_14 == 0)
{
lean_object* x_15; lean_object* x_16; 
x_15 = lean_box(0);
x_16 = l_ProofWidgets_Jsx_delabHtmlText___lambda__1(x_11, x_15, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
return x_16;
}
else
{
lean_object* x_17; uint8_t x_18; 
lean_dec(x_11);
lean_dec(x_2);
x_17 = l_Lean_PrettyPrinter_Delaborator_failure___rarg(x_8);
x_18 = !lean_is_exclusive(x_17);
if (x_18 == 0)
{
return x_17;
}
else
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_19 = lean_ctor_get(x_17, 0);
x_20 = lean_ctor_get(x_17, 1);
lean_inc(x_20);
lean_inc(x_19);
lean_dec(x_17);
x_21 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_21, 0, x_19);
lean_ctor_set(x_21, 1, x_20);
return x_21;
}
}
}
}
else
{
lean_object* x_22; 
lean_dec(x_2);
lean_dec(x_1);
x_22 = l_Lean_PrettyPrinter_Delaborator_failure___rarg(x_8);
return x_22;
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlText___lambda__3(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l_Lean_PrettyPrinter_Delaborator_failure___rarg(x_8);
return x_9;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_delabHtmlText___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_Jsx_delabHtmlText___lambda__2___boxed), 8, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_delabHtmlText___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_Jsx_delabHtmlText___lambda__3___boxed), 8, 0);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlText(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; uint8_t x_14; 
lean_inc(x_1);
x_8 = l_Lean_PrettyPrinter_Delaborator_SubExpr_getExpr___at_Lean_PrettyPrinter_Delaborator_getExprKind___spec__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
x_9 = lean_ctor_get(x_8, 0);
lean_inc(x_9);
x_10 = lean_ctor_get(x_8, 1);
lean_inc(x_10);
lean_dec(x_8);
x_11 = l_ProofWidgets_Jsx_delabHtmlText___closed__1;
x_12 = l_ProofWidgets_Jsx_delabHtmlText___closed__2;
x_13 = l_Lean_Expr_cleanupAnnotations(x_9);
x_14 = l_Lean_Expr_isApp(x_13);
if (x_14 == 0)
{
lean_object* x_15; lean_object* x_16; 
lean_dec(x_13);
x_15 = lean_box(0);
x_16 = lean_apply_8(x_12, x_15, x_1, x_2, x_3, x_4, x_5, x_6, x_10);
return x_16;
}
else
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; uint8_t x_20; 
x_17 = l_Lean_Expr_appArg(x_13, lean_box(0));
x_18 = l_Lean_Expr_appFnCleanup(x_13, lean_box(0));
x_19 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__15;
x_20 = l_Lean_Expr_isConstOf(x_18, x_19);
lean_dec(x_18);
if (x_20 == 0)
{
lean_object* x_21; lean_object* x_22; 
lean_dec(x_17);
x_21 = lean_box(0);
x_22 = lean_apply_8(x_12, x_21, x_1, x_2, x_3, x_4, x_5, x_6, x_10);
return x_22;
}
else
{
lean_object* x_23; 
x_23 = lean_apply_8(x_11, x_17, x_1, x_2, x_3, x_4, x_5, x_6, x_10);
return x_23;
}
}
}
}
LEAN_EXPORT lean_object* l_String_anyAux___at_ProofWidgets_Jsx_delabHtmlText___spec__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4) {
_start:
{
uint32_t x_5; uint8_t x_6; lean_object* x_7; 
x_5 = lean_unbox_uint32(x_1);
lean_dec(x_1);
x_6 = l_String_anyAux___at_ProofWidgets_Jsx_delabHtmlText___spec__2(x_5, x_2, x_3, x_4);
lean_dec(x_3);
lean_dec(x_2);
x_7 = lean_box(x_6);
return x_7;
}
}
LEAN_EXPORT lean_object* l_String_anyAux___at_ProofWidgets_Jsx_delabHtmlText___spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
uint8_t x_4; lean_object* x_5; 
x_4 = l_String_anyAux___at_ProofWidgets_Jsx_delabHtmlText___spec__1(x_1, x_2, x_3);
lean_dec(x_2);
lean_dec(x_1);
x_5 = lean_box(x_4);
return x_5;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlText___lambda__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_ProofWidgets_Jsx_delabHtmlText___lambda__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_2);
return x_10;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlText___lambda__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l_ProofWidgets_Jsx_delabHtmlText___lambda__2(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
return x_9;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlText___lambda__3___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l_ProofWidgets_Jsx_delabHtmlText___lambda__3(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_9;
}
}
static lean_object* _init_l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__1___closed__1() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_Lean_levelZero;
x_2 = l_Lean_Expr_sort___override(x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; uint8_t x_21; 
lean_inc(x_3);
x_10 = l_Lean_PrettyPrinter_Delaborator_SubExpr_getExpr___at_Lean_PrettyPrinter_Delaborator_getExprKind___spec__1(x_3, x_4, x_5, x_6, x_7, x_8, x_9);
x_11 = lean_ctor_get(x_10, 0);
lean_inc(x_11);
x_12 = lean_ctor_get(x_10, 1);
lean_inc(x_12);
lean_dec(x_10);
x_13 = lean_unsigned_to_nat(0u);
x_14 = l___private_Lean_Expr_0__Lean_Expr_getAppNumArgsAux(x_11, x_13);
x_15 = l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__1___closed__1;
lean_inc(x_14);
x_16 = lean_mk_array(x_14, x_15);
x_17 = lean_unsigned_to_nat(1u);
x_18 = lean_nat_sub(x_14, x_17);
lean_dec(x_14);
x_19 = l___private_Lean_Expr_0__Lean_Expr_getAppArgsAux(x_11, x_16, x_18);
x_20 = l_Lean_PrettyPrinter_Delaborator_SubExpr_getPos___at_Lean_PrettyPrinter_Delaborator_getOptionsAtCurrPos___spec__1(x_3, x_4, x_5, x_6, x_7, x_8, x_12);
x_21 = !lean_is_exclusive(x_20);
if (x_21 == 0)
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; uint8_t x_26; 
x_22 = lean_ctor_get(x_20, 0);
x_23 = lean_ctor_get(x_20, 1);
x_24 = lean_array_get_size(x_19);
x_25 = l_Lean_SubExpr_Pos_pushNaryArg(x_24, x_1, x_22);
lean_dec(x_22);
x_26 = !lean_is_exclusive(x_3);
if (x_26 == 0)
{
lean_object* x_27; uint8_t x_28; 
x_27 = lean_ctor_get(x_3, 3);
lean_dec(x_27);
x_28 = lean_nat_dec_lt(x_1, x_24);
lean_dec(x_24);
if (x_28 == 0)
{
lean_object* x_29; lean_object* x_30; lean_object* x_31; 
lean_dec(x_19);
x_29 = l_Lean_instInhabitedExpr;
x_30 = l_outOfBounds___rarg(x_29);
lean_ctor_set(x_20, 1, x_25);
lean_ctor_set(x_20, 0, x_30);
lean_ctor_set(x_3, 3, x_20);
x_31 = lean_apply_7(x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_23);
return x_31;
}
else
{
lean_object* x_32; lean_object* x_33; 
x_32 = lean_array_fget(x_19, x_1);
lean_dec(x_19);
lean_ctor_set(x_20, 1, x_25);
lean_ctor_set(x_20, 0, x_32);
lean_ctor_set(x_3, 3, x_20);
x_33 = lean_apply_7(x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_23);
return x_33;
}
}
else
{
lean_object* x_34; lean_object* x_35; lean_object* x_36; uint8_t x_37; lean_object* x_38; uint8_t x_39; 
x_34 = lean_ctor_get(x_3, 0);
x_35 = lean_ctor_get(x_3, 1);
x_36 = lean_ctor_get(x_3, 2);
x_37 = lean_ctor_get_uint8(x_3, sizeof(void*)*5);
x_38 = lean_ctor_get(x_3, 4);
lean_inc(x_38);
lean_inc(x_36);
lean_inc(x_35);
lean_inc(x_34);
lean_dec(x_3);
x_39 = lean_nat_dec_lt(x_1, x_24);
lean_dec(x_24);
if (x_39 == 0)
{
lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; 
lean_dec(x_19);
x_40 = l_Lean_instInhabitedExpr;
x_41 = l_outOfBounds___rarg(x_40);
lean_ctor_set(x_20, 1, x_25);
lean_ctor_set(x_20, 0, x_41);
x_42 = lean_alloc_ctor(0, 5, 1);
lean_ctor_set(x_42, 0, x_34);
lean_ctor_set(x_42, 1, x_35);
lean_ctor_set(x_42, 2, x_36);
lean_ctor_set(x_42, 3, x_20);
lean_ctor_set(x_42, 4, x_38);
lean_ctor_set_uint8(x_42, sizeof(void*)*5, x_37);
x_43 = lean_apply_7(x_2, x_42, x_4, x_5, x_6, x_7, x_8, x_23);
return x_43;
}
else
{
lean_object* x_44; lean_object* x_45; lean_object* x_46; 
x_44 = lean_array_fget(x_19, x_1);
lean_dec(x_19);
lean_ctor_set(x_20, 1, x_25);
lean_ctor_set(x_20, 0, x_44);
x_45 = lean_alloc_ctor(0, 5, 1);
lean_ctor_set(x_45, 0, x_34);
lean_ctor_set(x_45, 1, x_35);
lean_ctor_set(x_45, 2, x_36);
lean_ctor_set(x_45, 3, x_20);
lean_ctor_set(x_45, 4, x_38);
lean_ctor_set_uint8(x_45, sizeof(void*)*5, x_37);
x_46 = lean_apply_7(x_2, x_45, x_4, x_5, x_6, x_7, x_8, x_23);
return x_46;
}
}
}
else
{
lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; uint8_t x_54; lean_object* x_55; lean_object* x_56; uint8_t x_57; 
x_47 = lean_ctor_get(x_20, 0);
x_48 = lean_ctor_get(x_20, 1);
lean_inc(x_48);
lean_inc(x_47);
lean_dec(x_20);
x_49 = lean_array_get_size(x_19);
x_50 = l_Lean_SubExpr_Pos_pushNaryArg(x_49, x_1, x_47);
lean_dec(x_47);
x_51 = lean_ctor_get(x_3, 0);
lean_inc(x_51);
x_52 = lean_ctor_get(x_3, 1);
lean_inc(x_52);
x_53 = lean_ctor_get(x_3, 2);
lean_inc(x_53);
x_54 = lean_ctor_get_uint8(x_3, sizeof(void*)*5);
x_55 = lean_ctor_get(x_3, 4);
lean_inc(x_55);
if (lean_is_exclusive(x_3)) {
 lean_ctor_release(x_3, 0);
 lean_ctor_release(x_3, 1);
 lean_ctor_release(x_3, 2);
 lean_ctor_release(x_3, 3);
 lean_ctor_release(x_3, 4);
 x_56 = x_3;
} else {
 lean_dec_ref(x_3);
 x_56 = lean_box(0);
}
x_57 = lean_nat_dec_lt(x_1, x_49);
lean_dec(x_49);
if (x_57 == 0)
{
lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; 
lean_dec(x_19);
x_58 = l_Lean_instInhabitedExpr;
x_59 = l_outOfBounds___rarg(x_58);
x_60 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_60, 0, x_59);
lean_ctor_set(x_60, 1, x_50);
if (lean_is_scalar(x_56)) {
 x_61 = lean_alloc_ctor(0, 5, 1);
} else {
 x_61 = x_56;
}
lean_ctor_set(x_61, 0, x_51);
lean_ctor_set(x_61, 1, x_52);
lean_ctor_set(x_61, 2, x_53);
lean_ctor_set(x_61, 3, x_60);
lean_ctor_set(x_61, 4, x_55);
lean_ctor_set_uint8(x_61, sizeof(void*)*5, x_54);
x_62 = lean_apply_7(x_2, x_61, x_4, x_5, x_6, x_7, x_8, x_48);
return x_62;
}
else
{
lean_object* x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; 
x_63 = lean_array_fget(x_19, x_1);
lean_dec(x_19);
x_64 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_64, 0, x_63);
lean_ctor_set(x_64, 1, x_50);
if (lean_is_scalar(x_56)) {
 x_65 = lean_alloc_ctor(0, 5, 1);
} else {
 x_65 = x_56;
}
lean_ctor_set(x_65, 0, x_51);
lean_ctor_set(x_65, 1, x_52);
lean_ctor_set(x_65, 2, x_53);
lean_ctor_set(x_65, 3, x_64);
lean_ctor_set(x_65, 4, x_55);
lean_ctor_set_uint8(x_65, sizeof(void*)*5, x_54);
x_66 = lean_apply_7(x_2, x_65, x_4, x_5, x_6, x_7, x_8, x_48);
return x_66;
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; uint8_t x_21; 
lean_inc(x_3);
x_10 = l_Lean_PrettyPrinter_Delaborator_SubExpr_getExpr___at_Lean_PrettyPrinter_Delaborator_getExprKind___spec__1(x_3, x_4, x_5, x_6, x_7, x_8, x_9);
x_11 = lean_ctor_get(x_10, 0);
lean_inc(x_11);
x_12 = lean_ctor_get(x_10, 1);
lean_inc(x_12);
lean_dec(x_10);
x_13 = lean_unsigned_to_nat(0u);
x_14 = l___private_Lean_Expr_0__Lean_Expr_getAppNumArgsAux(x_11, x_13);
x_15 = l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__1___closed__1;
lean_inc(x_14);
x_16 = lean_mk_array(x_14, x_15);
x_17 = lean_unsigned_to_nat(1u);
x_18 = lean_nat_sub(x_14, x_17);
lean_dec(x_14);
x_19 = l___private_Lean_Expr_0__Lean_Expr_getAppArgsAux(x_11, x_16, x_18);
x_20 = l_Lean_PrettyPrinter_Delaborator_SubExpr_getPos___at_Lean_PrettyPrinter_Delaborator_getOptionsAtCurrPos___spec__1(x_3, x_4, x_5, x_6, x_7, x_8, x_12);
x_21 = !lean_is_exclusive(x_20);
if (x_21 == 0)
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; uint8_t x_26; 
x_22 = lean_ctor_get(x_20, 0);
x_23 = lean_ctor_get(x_20, 1);
x_24 = lean_array_get_size(x_19);
x_25 = l_Lean_SubExpr_Pos_pushNaryArg(x_24, x_1, x_22);
lean_dec(x_22);
x_26 = !lean_is_exclusive(x_3);
if (x_26 == 0)
{
lean_object* x_27; uint8_t x_28; 
x_27 = lean_ctor_get(x_3, 3);
lean_dec(x_27);
x_28 = lean_nat_dec_lt(x_1, x_24);
lean_dec(x_24);
if (x_28 == 0)
{
lean_object* x_29; lean_object* x_30; lean_object* x_31; 
lean_dec(x_19);
x_29 = l_Lean_instInhabitedExpr;
x_30 = l_outOfBounds___rarg(x_29);
lean_ctor_set(x_20, 1, x_25);
lean_ctor_set(x_20, 0, x_30);
lean_ctor_set(x_3, 3, x_20);
x_31 = lean_apply_7(x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_23);
return x_31;
}
else
{
lean_object* x_32; lean_object* x_33; 
x_32 = lean_array_fget(x_19, x_1);
lean_dec(x_19);
lean_ctor_set(x_20, 1, x_25);
lean_ctor_set(x_20, 0, x_32);
lean_ctor_set(x_3, 3, x_20);
x_33 = lean_apply_7(x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_23);
return x_33;
}
}
else
{
lean_object* x_34; lean_object* x_35; lean_object* x_36; uint8_t x_37; lean_object* x_38; uint8_t x_39; 
x_34 = lean_ctor_get(x_3, 0);
x_35 = lean_ctor_get(x_3, 1);
x_36 = lean_ctor_get(x_3, 2);
x_37 = lean_ctor_get_uint8(x_3, sizeof(void*)*5);
x_38 = lean_ctor_get(x_3, 4);
lean_inc(x_38);
lean_inc(x_36);
lean_inc(x_35);
lean_inc(x_34);
lean_dec(x_3);
x_39 = lean_nat_dec_lt(x_1, x_24);
lean_dec(x_24);
if (x_39 == 0)
{
lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; 
lean_dec(x_19);
x_40 = l_Lean_instInhabitedExpr;
x_41 = l_outOfBounds___rarg(x_40);
lean_ctor_set(x_20, 1, x_25);
lean_ctor_set(x_20, 0, x_41);
x_42 = lean_alloc_ctor(0, 5, 1);
lean_ctor_set(x_42, 0, x_34);
lean_ctor_set(x_42, 1, x_35);
lean_ctor_set(x_42, 2, x_36);
lean_ctor_set(x_42, 3, x_20);
lean_ctor_set(x_42, 4, x_38);
lean_ctor_set_uint8(x_42, sizeof(void*)*5, x_37);
x_43 = lean_apply_7(x_2, x_42, x_4, x_5, x_6, x_7, x_8, x_23);
return x_43;
}
else
{
lean_object* x_44; lean_object* x_45; lean_object* x_46; 
x_44 = lean_array_fget(x_19, x_1);
lean_dec(x_19);
lean_ctor_set(x_20, 1, x_25);
lean_ctor_set(x_20, 0, x_44);
x_45 = lean_alloc_ctor(0, 5, 1);
lean_ctor_set(x_45, 0, x_34);
lean_ctor_set(x_45, 1, x_35);
lean_ctor_set(x_45, 2, x_36);
lean_ctor_set(x_45, 3, x_20);
lean_ctor_set(x_45, 4, x_38);
lean_ctor_set_uint8(x_45, sizeof(void*)*5, x_37);
x_46 = lean_apply_7(x_2, x_45, x_4, x_5, x_6, x_7, x_8, x_23);
return x_46;
}
}
}
else
{
lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; uint8_t x_54; lean_object* x_55; lean_object* x_56; uint8_t x_57; 
x_47 = lean_ctor_get(x_20, 0);
x_48 = lean_ctor_get(x_20, 1);
lean_inc(x_48);
lean_inc(x_47);
lean_dec(x_20);
x_49 = lean_array_get_size(x_19);
x_50 = l_Lean_SubExpr_Pos_pushNaryArg(x_49, x_1, x_47);
lean_dec(x_47);
x_51 = lean_ctor_get(x_3, 0);
lean_inc(x_51);
x_52 = lean_ctor_get(x_3, 1);
lean_inc(x_52);
x_53 = lean_ctor_get(x_3, 2);
lean_inc(x_53);
x_54 = lean_ctor_get_uint8(x_3, sizeof(void*)*5);
x_55 = lean_ctor_get(x_3, 4);
lean_inc(x_55);
if (lean_is_exclusive(x_3)) {
 lean_ctor_release(x_3, 0);
 lean_ctor_release(x_3, 1);
 lean_ctor_release(x_3, 2);
 lean_ctor_release(x_3, 3);
 lean_ctor_release(x_3, 4);
 x_56 = x_3;
} else {
 lean_dec_ref(x_3);
 x_56 = lean_box(0);
}
x_57 = lean_nat_dec_lt(x_1, x_49);
lean_dec(x_49);
if (x_57 == 0)
{
lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; 
lean_dec(x_19);
x_58 = l_Lean_instInhabitedExpr;
x_59 = l_outOfBounds___rarg(x_58);
x_60 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_60, 0, x_59);
lean_ctor_set(x_60, 1, x_50);
if (lean_is_scalar(x_56)) {
 x_61 = lean_alloc_ctor(0, 5, 1);
} else {
 x_61 = x_56;
}
lean_ctor_set(x_61, 0, x_51);
lean_ctor_set(x_61, 1, x_52);
lean_ctor_set(x_61, 2, x_53);
lean_ctor_set(x_61, 3, x_60);
lean_ctor_set(x_61, 4, x_55);
lean_ctor_set_uint8(x_61, sizeof(void*)*5, x_54);
x_62 = lean_apply_7(x_2, x_61, x_4, x_5, x_6, x_7, x_8, x_48);
return x_62;
}
else
{
lean_object* x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; 
x_63 = lean_array_fget(x_19, x_1);
lean_dec(x_19);
x_64 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_64, 0, x_63);
lean_ctor_set(x_64, 1, x_50);
if (lean_is_scalar(x_56)) {
 x_65 = lean_alloc_ctor(0, 5, 1);
} else {
 x_65 = x_56;
}
lean_ctor_set(x_65, 0, x_51);
lean_ctor_set(x_65, 1, x_52);
lean_ctor_set(x_65, 2, x_53);
lean_ctor_set(x_65, 3, x_64);
lean_ctor_set(x_65, 4, x_55);
lean_ctor_set_uint8(x_65, sizeof(void*)*5, x_54);
x_66 = lean_apply_7(x_2, x_65, x_4, x_5, x_6, x_7, x_8, x_48);
return x_66;
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__3(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; uint8_t x_21; 
lean_inc(x_3);
x_10 = l_Lean_PrettyPrinter_Delaborator_SubExpr_getExpr___at_Lean_PrettyPrinter_Delaborator_getExprKind___spec__1(x_3, x_4, x_5, x_6, x_7, x_8, x_9);
x_11 = lean_ctor_get(x_10, 0);
lean_inc(x_11);
x_12 = lean_ctor_get(x_10, 1);
lean_inc(x_12);
lean_dec(x_10);
x_13 = lean_unsigned_to_nat(0u);
x_14 = l___private_Lean_Expr_0__Lean_Expr_getAppNumArgsAux(x_11, x_13);
x_15 = l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__1___closed__1;
lean_inc(x_14);
x_16 = lean_mk_array(x_14, x_15);
x_17 = lean_unsigned_to_nat(1u);
x_18 = lean_nat_sub(x_14, x_17);
lean_dec(x_14);
x_19 = l___private_Lean_Expr_0__Lean_Expr_getAppArgsAux(x_11, x_16, x_18);
x_20 = l_Lean_PrettyPrinter_Delaborator_SubExpr_getPos___at_Lean_PrettyPrinter_Delaborator_getOptionsAtCurrPos___spec__1(x_3, x_4, x_5, x_6, x_7, x_8, x_12);
x_21 = !lean_is_exclusive(x_20);
if (x_21 == 0)
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; uint8_t x_26; 
x_22 = lean_ctor_get(x_20, 0);
x_23 = lean_ctor_get(x_20, 1);
x_24 = lean_array_get_size(x_19);
x_25 = l_Lean_SubExpr_Pos_pushNaryArg(x_24, x_1, x_22);
lean_dec(x_22);
x_26 = !lean_is_exclusive(x_3);
if (x_26 == 0)
{
lean_object* x_27; uint8_t x_28; 
x_27 = lean_ctor_get(x_3, 3);
lean_dec(x_27);
x_28 = lean_nat_dec_lt(x_1, x_24);
lean_dec(x_24);
if (x_28 == 0)
{
lean_object* x_29; lean_object* x_30; lean_object* x_31; 
lean_dec(x_19);
x_29 = l_Lean_instInhabitedExpr;
x_30 = l_outOfBounds___rarg(x_29);
lean_ctor_set(x_20, 1, x_25);
lean_ctor_set(x_20, 0, x_30);
lean_ctor_set(x_3, 3, x_20);
x_31 = lean_apply_7(x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_23);
return x_31;
}
else
{
lean_object* x_32; lean_object* x_33; 
x_32 = lean_array_fget(x_19, x_1);
lean_dec(x_19);
lean_ctor_set(x_20, 1, x_25);
lean_ctor_set(x_20, 0, x_32);
lean_ctor_set(x_3, 3, x_20);
x_33 = lean_apply_7(x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_23);
return x_33;
}
}
else
{
lean_object* x_34; lean_object* x_35; lean_object* x_36; uint8_t x_37; lean_object* x_38; uint8_t x_39; 
x_34 = lean_ctor_get(x_3, 0);
x_35 = lean_ctor_get(x_3, 1);
x_36 = lean_ctor_get(x_3, 2);
x_37 = lean_ctor_get_uint8(x_3, sizeof(void*)*5);
x_38 = lean_ctor_get(x_3, 4);
lean_inc(x_38);
lean_inc(x_36);
lean_inc(x_35);
lean_inc(x_34);
lean_dec(x_3);
x_39 = lean_nat_dec_lt(x_1, x_24);
lean_dec(x_24);
if (x_39 == 0)
{
lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; 
lean_dec(x_19);
x_40 = l_Lean_instInhabitedExpr;
x_41 = l_outOfBounds___rarg(x_40);
lean_ctor_set(x_20, 1, x_25);
lean_ctor_set(x_20, 0, x_41);
x_42 = lean_alloc_ctor(0, 5, 1);
lean_ctor_set(x_42, 0, x_34);
lean_ctor_set(x_42, 1, x_35);
lean_ctor_set(x_42, 2, x_36);
lean_ctor_set(x_42, 3, x_20);
lean_ctor_set(x_42, 4, x_38);
lean_ctor_set_uint8(x_42, sizeof(void*)*5, x_37);
x_43 = lean_apply_7(x_2, x_42, x_4, x_5, x_6, x_7, x_8, x_23);
return x_43;
}
else
{
lean_object* x_44; lean_object* x_45; lean_object* x_46; 
x_44 = lean_array_fget(x_19, x_1);
lean_dec(x_19);
lean_ctor_set(x_20, 1, x_25);
lean_ctor_set(x_20, 0, x_44);
x_45 = lean_alloc_ctor(0, 5, 1);
lean_ctor_set(x_45, 0, x_34);
lean_ctor_set(x_45, 1, x_35);
lean_ctor_set(x_45, 2, x_36);
lean_ctor_set(x_45, 3, x_20);
lean_ctor_set(x_45, 4, x_38);
lean_ctor_set_uint8(x_45, sizeof(void*)*5, x_37);
x_46 = lean_apply_7(x_2, x_45, x_4, x_5, x_6, x_7, x_8, x_23);
return x_46;
}
}
}
else
{
lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; uint8_t x_54; lean_object* x_55; lean_object* x_56; uint8_t x_57; 
x_47 = lean_ctor_get(x_20, 0);
x_48 = lean_ctor_get(x_20, 1);
lean_inc(x_48);
lean_inc(x_47);
lean_dec(x_20);
x_49 = lean_array_get_size(x_19);
x_50 = l_Lean_SubExpr_Pos_pushNaryArg(x_49, x_1, x_47);
lean_dec(x_47);
x_51 = lean_ctor_get(x_3, 0);
lean_inc(x_51);
x_52 = lean_ctor_get(x_3, 1);
lean_inc(x_52);
x_53 = lean_ctor_get(x_3, 2);
lean_inc(x_53);
x_54 = lean_ctor_get_uint8(x_3, sizeof(void*)*5);
x_55 = lean_ctor_get(x_3, 4);
lean_inc(x_55);
if (lean_is_exclusive(x_3)) {
 lean_ctor_release(x_3, 0);
 lean_ctor_release(x_3, 1);
 lean_ctor_release(x_3, 2);
 lean_ctor_release(x_3, 3);
 lean_ctor_release(x_3, 4);
 x_56 = x_3;
} else {
 lean_dec_ref(x_3);
 x_56 = lean_box(0);
}
x_57 = lean_nat_dec_lt(x_1, x_49);
lean_dec(x_49);
if (x_57 == 0)
{
lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; 
lean_dec(x_19);
x_58 = l_Lean_instInhabitedExpr;
x_59 = l_outOfBounds___rarg(x_58);
x_60 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_60, 0, x_59);
lean_ctor_set(x_60, 1, x_50);
if (lean_is_scalar(x_56)) {
 x_61 = lean_alloc_ctor(0, 5, 1);
} else {
 x_61 = x_56;
}
lean_ctor_set(x_61, 0, x_51);
lean_ctor_set(x_61, 1, x_52);
lean_ctor_set(x_61, 2, x_53);
lean_ctor_set(x_61, 3, x_60);
lean_ctor_set(x_61, 4, x_55);
lean_ctor_set_uint8(x_61, sizeof(void*)*5, x_54);
x_62 = lean_apply_7(x_2, x_61, x_4, x_5, x_6, x_7, x_8, x_48);
return x_62;
}
else
{
lean_object* x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; 
x_63 = lean_array_fget(x_19, x_1);
lean_dec(x_19);
x_64 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_64, 0, x_63);
lean_ctor_set(x_64, 1, x_50);
if (lean_is_scalar(x_56)) {
 x_65 = lean_alloc_ctor(0, 5, 1);
} else {
 x_65 = x_56;
}
lean_ctor_set(x_65, 0, x_51);
lean_ctor_set(x_65, 1, x_52);
lean_ctor_set(x_65, 2, x_53);
lean_ctor_set(x_65, 3, x_64);
lean_ctor_set(x_65, 4, x_55);
lean_ctor_set_uint8(x_65, sizeof(void*)*5, x_54);
x_66 = lean_apply_7(x_2, x_65, x_4, x_5, x_6, x_7, x_8, x_48);
return x_66;
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_descend___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__5(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
uint8_t x_11; 
x_11 = !lean_is_exclusive(x_4);
if (x_11 == 0)
{
lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; 
x_12 = lean_ctor_get(x_4, 3);
x_13 = lean_ctor_get(x_12, 1);
lean_inc(x_13);
lean_dec(x_12);
x_14 = l_Lean_SubExpr_Pos_push(x_13, x_2);
lean_dec(x_13);
x_15 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_15, 0, x_1);
lean_ctor_set(x_15, 1, x_14);
lean_ctor_set(x_4, 3, x_15);
x_16 = lean_apply_7(x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10);
return x_16;
}
else
{
lean_object* x_17; lean_object* x_18; lean_object* x_19; uint8_t x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; 
x_17 = lean_ctor_get(x_4, 0);
x_18 = lean_ctor_get(x_4, 1);
x_19 = lean_ctor_get(x_4, 2);
x_20 = lean_ctor_get_uint8(x_4, sizeof(void*)*5);
x_21 = lean_ctor_get(x_4, 3);
x_22 = lean_ctor_get(x_4, 4);
lean_inc(x_22);
lean_inc(x_21);
lean_inc(x_19);
lean_inc(x_18);
lean_inc(x_17);
lean_dec(x_4);
x_23 = lean_ctor_get(x_21, 1);
lean_inc(x_23);
lean_dec(x_21);
x_24 = l_Lean_SubExpr_Pos_push(x_23, x_2);
lean_dec(x_23);
x_25 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_25, 0, x_1);
lean_ctor_set(x_25, 1, x_24);
x_26 = lean_alloc_ctor(0, 5, 1);
lean_ctor_set(x_26, 0, x_17);
lean_ctor_set(x_26, 1, x_18);
lean_ctor_set(x_26, 2, x_19);
lean_ctor_set(x_26, 3, x_25);
lean_ctor_set(x_26, 4, x_22);
lean_ctor_set_uint8(x_26, sizeof(void*)*5, x_20);
x_27 = lean_apply_7(x_3, x_26, x_5, x_6, x_7, x_8, x_9, x_10);
return x_27;
}
}
}
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withAppArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__4(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; 
lean_inc(x_2);
x_9 = l_Lean_PrettyPrinter_Delaborator_SubExpr_getExpr___at_Lean_PrettyPrinter_Delaborator_getExprKind___spec__1(x_2, x_3, x_4, x_5, x_6, x_7, x_8);
x_10 = lean_ctor_get(x_9, 0);
lean_inc(x_10);
x_11 = lean_ctor_get(x_9, 1);
lean_inc(x_11);
lean_dec(x_9);
x_12 = l_Lean_Expr_appArg_x21(x_10);
lean_dec(x_10);
x_13 = lean_unsigned_to_nat(1u);
x_14 = l_Lean_PrettyPrinter_Delaborator_SubExpr_descend___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__5(x_12, x_13, x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_11);
return x_14;
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__6(size_t x_1, size_t x_2, lean_object* x_3) {
_start:
{
uint8_t x_4; 
x_4 = lean_usize_dec_lt(x_2, x_1);
if (x_4 == 0)
{
return x_3;
}
else
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; size_t x_8; size_t x_9; lean_object* x_10; 
x_5 = lean_array_uget(x_3, x_2);
x_6 = lean_unsigned_to_nat(0u);
x_7 = lean_array_uset(x_3, x_2, x_6);
x_8 = 1;
x_9 = lean_usize_add(x_2, x_8);
x_10 = lean_array_uset(x_7, x_2, x_5);
x_2 = x_9;
x_3 = x_10;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__7(size_t x_1, size_t x_2, lean_object* x_3) {
_start:
{
uint8_t x_4; 
x_4 = lean_usize_dec_lt(x_2, x_1);
if (x_4 == 0)
{
return x_3;
}
else
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; size_t x_8; size_t x_9; lean_object* x_10; 
x_5 = lean_array_uget(x_3, x_2);
x_6 = lean_unsigned_to_nat(0u);
x_7 = lean_array_uset(x_3, x_2, x_6);
x_8 = 1;
x_9 = lean_usize_add(x_2, x_8);
x_10 = lean_array_uset(x_7, x_2, x_5);
x_2 = x_9;
x_3 = x_10;
goto _start;
}
}
}
static lean_object* _init_l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__1___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Json", 4, 4);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
if (lean_obj_tag(x_2) == 5)
{
lean_object* x_10; 
x_10 = lean_ctor_get(x_2, 0);
if (lean_obj_tag(x_10) == 4)
{
lean_object* x_11; 
x_11 = lean_ctor_get(x_10, 0);
if (lean_obj_tag(x_11) == 1)
{
lean_object* x_12; 
x_12 = lean_ctor_get(x_11, 0);
if (lean_obj_tag(x_12) == 1)
{
lean_object* x_13; 
x_13 = lean_ctor_get(x_12, 0);
if (lean_obj_tag(x_13) == 1)
{
lean_object* x_14; 
x_14 = lean_ctor_get(x_13, 0);
if (lean_obj_tag(x_14) == 0)
{
lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; uint8_t x_20; 
x_15 = lean_ctor_get(x_2, 1);
x_16 = lean_ctor_get(x_11, 1);
x_17 = lean_ctor_get(x_12, 1);
x_18 = lean_ctor_get(x_13, 1);
x_19 = l_ProofWidgets_Jsx_jsxElement_quot___closed__1;
x_20 = lean_string_dec_eq(x_18, x_19);
if (x_20 == 0)
{
lean_object* x_21; 
lean_inc(x_7);
x_21 = l_Lean_PrettyPrinter_Delaborator_delab(x_3, x_4, x_5, x_6, x_7, x_8, x_9);
if (lean_obj_tag(x_21) == 0)
{
uint8_t x_22; 
x_22 = !lean_is_exclusive(x_21);
if (x_22 == 0)
{
lean_object* x_23; lean_object* x_24; uint8_t x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; 
x_23 = lean_ctor_get(x_21, 0);
x_24 = lean_ctor_get(x_7, 5);
lean_inc(x_24);
lean_dec(x_7);
x_25 = 0;
x_26 = l_Lean_SourceInfo_fromRef(x_24, x_25);
lean_dec(x_24);
x_27 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
lean_inc(x_26);
x_28 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_28, 0, x_26);
lean_ctor_set(x_28, 1, x_27);
x_29 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_26);
x_30 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_30, 0, x_26);
lean_ctor_set(x_30, 1, x_29);
x_31 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_26);
x_32 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_32, 0, x_26);
lean_ctor_set(x_32, 1, x_31);
x_33 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_26);
x_34 = l_Lean_Syntax_node3(x_26, x_33, x_30, x_23, x_32);
x_35 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2;
lean_inc(x_26);
x_36 = l_Lean_Syntax_node1(x_26, x_35, x_34);
x_37 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
x_38 = l_Lean_Syntax_node3(x_26, x_37, x_1, x_28, x_36);
lean_ctor_set(x_21, 0, x_38);
return x_21;
}
else
{
lean_object* x_39; lean_object* x_40; lean_object* x_41; uint8_t x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; 
x_39 = lean_ctor_get(x_21, 0);
x_40 = lean_ctor_get(x_21, 1);
lean_inc(x_40);
lean_inc(x_39);
lean_dec(x_21);
x_41 = lean_ctor_get(x_7, 5);
lean_inc(x_41);
lean_dec(x_7);
x_42 = 0;
x_43 = l_Lean_SourceInfo_fromRef(x_41, x_42);
lean_dec(x_41);
x_44 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
lean_inc(x_43);
x_45 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_45, 0, x_43);
lean_ctor_set(x_45, 1, x_44);
x_46 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_43);
x_47 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_47, 0, x_43);
lean_ctor_set(x_47, 1, x_46);
x_48 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_43);
x_49 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_49, 0, x_43);
lean_ctor_set(x_49, 1, x_48);
x_50 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_43);
x_51 = l_Lean_Syntax_node3(x_43, x_50, x_47, x_39, x_49);
x_52 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2;
lean_inc(x_43);
x_53 = l_Lean_Syntax_node1(x_43, x_52, x_51);
x_54 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
x_55 = l_Lean_Syntax_node3(x_43, x_54, x_1, x_45, x_53);
x_56 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_56, 0, x_55);
lean_ctor_set(x_56, 1, x_40);
return x_56;
}
}
else
{
uint8_t x_57; 
lean_dec(x_7);
lean_dec(x_1);
x_57 = !lean_is_exclusive(x_21);
if (x_57 == 0)
{
return x_21;
}
else
{
lean_object* x_58; lean_object* x_59; lean_object* x_60; 
x_58 = lean_ctor_get(x_21, 0);
x_59 = lean_ctor_get(x_21, 1);
lean_inc(x_59);
lean_inc(x_58);
lean_dec(x_21);
x_60 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_60, 0, x_58);
lean_ctor_set(x_60, 1, x_59);
return x_60;
}
}
}
else
{
lean_object* x_61; uint8_t x_62; 
x_61 = l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__1___closed__1;
x_62 = lean_string_dec_eq(x_17, x_61);
if (x_62 == 0)
{
lean_object* x_63; 
lean_inc(x_7);
x_63 = l_Lean_PrettyPrinter_Delaborator_delab(x_3, x_4, x_5, x_6, x_7, x_8, x_9);
if (lean_obj_tag(x_63) == 0)
{
uint8_t x_64; 
x_64 = !lean_is_exclusive(x_63);
if (x_64 == 0)
{
lean_object* x_65; lean_object* x_66; uint8_t x_67; lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; lean_object* x_79; lean_object* x_80; 
x_65 = lean_ctor_get(x_63, 0);
x_66 = lean_ctor_get(x_7, 5);
lean_inc(x_66);
lean_dec(x_7);
x_67 = 0;
x_68 = l_Lean_SourceInfo_fromRef(x_66, x_67);
lean_dec(x_66);
x_69 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
lean_inc(x_68);
x_70 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_70, 0, x_68);
lean_ctor_set(x_70, 1, x_69);
x_71 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_68);
x_72 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_72, 0, x_68);
lean_ctor_set(x_72, 1, x_71);
x_73 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_68);
x_74 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_74, 0, x_68);
lean_ctor_set(x_74, 1, x_73);
x_75 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_68);
x_76 = l_Lean_Syntax_node3(x_68, x_75, x_72, x_65, x_74);
x_77 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2;
lean_inc(x_68);
x_78 = l_Lean_Syntax_node1(x_68, x_77, x_76);
x_79 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
x_80 = l_Lean_Syntax_node3(x_68, x_79, x_1, x_70, x_78);
lean_ctor_set(x_63, 0, x_80);
return x_63;
}
else
{
lean_object* x_81; lean_object* x_82; lean_object* x_83; uint8_t x_84; lean_object* x_85; lean_object* x_86; lean_object* x_87; lean_object* x_88; lean_object* x_89; lean_object* x_90; lean_object* x_91; lean_object* x_92; lean_object* x_93; lean_object* x_94; lean_object* x_95; lean_object* x_96; lean_object* x_97; lean_object* x_98; 
x_81 = lean_ctor_get(x_63, 0);
x_82 = lean_ctor_get(x_63, 1);
lean_inc(x_82);
lean_inc(x_81);
lean_dec(x_63);
x_83 = lean_ctor_get(x_7, 5);
lean_inc(x_83);
lean_dec(x_7);
x_84 = 0;
x_85 = l_Lean_SourceInfo_fromRef(x_83, x_84);
lean_dec(x_83);
x_86 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
lean_inc(x_85);
x_87 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_87, 0, x_85);
lean_ctor_set(x_87, 1, x_86);
x_88 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_85);
x_89 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_89, 0, x_85);
lean_ctor_set(x_89, 1, x_88);
x_90 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_85);
x_91 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_91, 0, x_85);
lean_ctor_set(x_91, 1, x_90);
x_92 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_85);
x_93 = l_Lean_Syntax_node3(x_85, x_92, x_89, x_81, x_91);
x_94 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2;
lean_inc(x_85);
x_95 = l_Lean_Syntax_node1(x_85, x_94, x_93);
x_96 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
x_97 = l_Lean_Syntax_node3(x_85, x_96, x_1, x_87, x_95);
x_98 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_98, 0, x_97);
lean_ctor_set(x_98, 1, x_82);
return x_98;
}
}
else
{
uint8_t x_99; 
lean_dec(x_7);
lean_dec(x_1);
x_99 = !lean_is_exclusive(x_63);
if (x_99 == 0)
{
return x_63;
}
else
{
lean_object* x_100; lean_object* x_101; lean_object* x_102; 
x_100 = lean_ctor_get(x_63, 0);
x_101 = lean_ctor_get(x_63, 1);
lean_inc(x_101);
lean_inc(x_100);
lean_dec(x_63);
x_102 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_102, 0, x_100);
lean_ctor_set(x_102, 1, x_101);
return x_102;
}
}
}
else
{
lean_object* x_103; uint8_t x_104; 
x_103 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__5;
x_104 = lean_string_dec_eq(x_16, x_103);
if (x_104 == 0)
{
lean_object* x_105; 
lean_inc(x_7);
x_105 = l_Lean_PrettyPrinter_Delaborator_delab(x_3, x_4, x_5, x_6, x_7, x_8, x_9);
if (lean_obj_tag(x_105) == 0)
{
uint8_t x_106; 
x_106 = !lean_is_exclusive(x_105);
if (x_106 == 0)
{
lean_object* x_107; lean_object* x_108; uint8_t x_109; lean_object* x_110; lean_object* x_111; lean_object* x_112; lean_object* x_113; lean_object* x_114; lean_object* x_115; lean_object* x_116; lean_object* x_117; lean_object* x_118; lean_object* x_119; lean_object* x_120; lean_object* x_121; lean_object* x_122; 
x_107 = lean_ctor_get(x_105, 0);
x_108 = lean_ctor_get(x_7, 5);
lean_inc(x_108);
lean_dec(x_7);
x_109 = 0;
x_110 = l_Lean_SourceInfo_fromRef(x_108, x_109);
lean_dec(x_108);
x_111 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
lean_inc(x_110);
x_112 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_112, 0, x_110);
lean_ctor_set(x_112, 1, x_111);
x_113 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_110);
x_114 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_114, 0, x_110);
lean_ctor_set(x_114, 1, x_113);
x_115 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_110);
x_116 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_116, 0, x_110);
lean_ctor_set(x_116, 1, x_115);
x_117 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_110);
x_118 = l_Lean_Syntax_node3(x_110, x_117, x_114, x_107, x_116);
x_119 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2;
lean_inc(x_110);
x_120 = l_Lean_Syntax_node1(x_110, x_119, x_118);
x_121 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
x_122 = l_Lean_Syntax_node3(x_110, x_121, x_1, x_112, x_120);
lean_ctor_set(x_105, 0, x_122);
return x_105;
}
else
{
lean_object* x_123; lean_object* x_124; lean_object* x_125; uint8_t x_126; lean_object* x_127; lean_object* x_128; lean_object* x_129; lean_object* x_130; lean_object* x_131; lean_object* x_132; lean_object* x_133; lean_object* x_134; lean_object* x_135; lean_object* x_136; lean_object* x_137; lean_object* x_138; lean_object* x_139; lean_object* x_140; 
x_123 = lean_ctor_get(x_105, 0);
x_124 = lean_ctor_get(x_105, 1);
lean_inc(x_124);
lean_inc(x_123);
lean_dec(x_105);
x_125 = lean_ctor_get(x_7, 5);
lean_inc(x_125);
lean_dec(x_7);
x_126 = 0;
x_127 = l_Lean_SourceInfo_fromRef(x_125, x_126);
lean_dec(x_125);
x_128 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
lean_inc(x_127);
x_129 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_129, 0, x_127);
lean_ctor_set(x_129, 1, x_128);
x_130 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_127);
x_131 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_131, 0, x_127);
lean_ctor_set(x_131, 1, x_130);
x_132 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_127);
x_133 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_133, 0, x_127);
lean_ctor_set(x_133, 1, x_132);
x_134 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_127);
x_135 = l_Lean_Syntax_node3(x_127, x_134, x_131, x_123, x_133);
x_136 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2;
lean_inc(x_127);
x_137 = l_Lean_Syntax_node1(x_127, x_136, x_135);
x_138 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
x_139 = l_Lean_Syntax_node3(x_127, x_138, x_1, x_129, x_137);
x_140 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_140, 0, x_139);
lean_ctor_set(x_140, 1, x_124);
return x_140;
}
}
else
{
uint8_t x_141; 
lean_dec(x_7);
lean_dec(x_1);
x_141 = !lean_is_exclusive(x_105);
if (x_141 == 0)
{
return x_105;
}
else
{
lean_object* x_142; lean_object* x_143; lean_object* x_144; 
x_142 = lean_ctor_get(x_105, 0);
x_143 = lean_ctor_get(x_105, 1);
lean_inc(x_143);
lean_inc(x_142);
lean_dec(x_105);
x_144 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_144, 0, x_142);
lean_ctor_set(x_144, 1, x_143);
return x_144;
}
}
}
else
{
if (lean_obj_tag(x_15) == 9)
{
lean_object* x_145; 
x_145 = lean_ctor_get(x_15, 0);
if (lean_obj_tag(x_145) == 0)
{
lean_object* x_146; 
lean_inc(x_7);
x_146 = l_Lean_PrettyPrinter_Delaborator_delab(x_3, x_4, x_5, x_6, x_7, x_8, x_9);
if (lean_obj_tag(x_146) == 0)
{
uint8_t x_147; 
x_147 = !lean_is_exclusive(x_146);
if (x_147 == 0)
{
lean_object* x_148; lean_object* x_149; uint8_t x_150; lean_object* x_151; lean_object* x_152; lean_object* x_153; lean_object* x_154; lean_object* x_155; lean_object* x_156; lean_object* x_157; lean_object* x_158; lean_object* x_159; lean_object* x_160; lean_object* x_161; lean_object* x_162; lean_object* x_163; 
x_148 = lean_ctor_get(x_146, 0);
x_149 = lean_ctor_get(x_7, 5);
lean_inc(x_149);
lean_dec(x_7);
x_150 = 0;
x_151 = l_Lean_SourceInfo_fromRef(x_149, x_150);
lean_dec(x_149);
x_152 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
lean_inc(x_151);
x_153 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_153, 0, x_151);
lean_ctor_set(x_153, 1, x_152);
x_154 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_151);
x_155 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_155, 0, x_151);
lean_ctor_set(x_155, 1, x_154);
x_156 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_151);
x_157 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_157, 0, x_151);
lean_ctor_set(x_157, 1, x_156);
x_158 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_151);
x_159 = l_Lean_Syntax_node3(x_151, x_158, x_155, x_148, x_157);
x_160 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2;
lean_inc(x_151);
x_161 = l_Lean_Syntax_node1(x_151, x_160, x_159);
x_162 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
x_163 = l_Lean_Syntax_node3(x_151, x_162, x_1, x_153, x_161);
lean_ctor_set(x_146, 0, x_163);
return x_146;
}
else
{
lean_object* x_164; lean_object* x_165; lean_object* x_166; uint8_t x_167; lean_object* x_168; lean_object* x_169; lean_object* x_170; lean_object* x_171; lean_object* x_172; lean_object* x_173; lean_object* x_174; lean_object* x_175; lean_object* x_176; lean_object* x_177; lean_object* x_178; lean_object* x_179; lean_object* x_180; lean_object* x_181; 
x_164 = lean_ctor_get(x_146, 0);
x_165 = lean_ctor_get(x_146, 1);
lean_inc(x_165);
lean_inc(x_164);
lean_dec(x_146);
x_166 = lean_ctor_get(x_7, 5);
lean_inc(x_166);
lean_dec(x_7);
x_167 = 0;
x_168 = l_Lean_SourceInfo_fromRef(x_166, x_167);
lean_dec(x_166);
x_169 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
lean_inc(x_168);
x_170 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_170, 0, x_168);
lean_ctor_set(x_170, 1, x_169);
x_171 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_168);
x_172 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_172, 0, x_168);
lean_ctor_set(x_172, 1, x_171);
x_173 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_168);
x_174 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_174, 0, x_168);
lean_ctor_set(x_174, 1, x_173);
x_175 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_168);
x_176 = l_Lean_Syntax_node3(x_168, x_175, x_172, x_164, x_174);
x_177 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2;
lean_inc(x_168);
x_178 = l_Lean_Syntax_node1(x_168, x_177, x_176);
x_179 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
x_180 = l_Lean_Syntax_node3(x_168, x_179, x_1, x_170, x_178);
x_181 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_181, 0, x_180);
lean_ctor_set(x_181, 1, x_165);
return x_181;
}
}
else
{
uint8_t x_182; 
lean_dec(x_7);
lean_dec(x_1);
x_182 = !lean_is_exclusive(x_146);
if (x_182 == 0)
{
return x_146;
}
else
{
lean_object* x_183; lean_object* x_184; lean_object* x_185; 
x_183 = lean_ctor_get(x_146, 0);
x_184 = lean_ctor_get(x_146, 1);
lean_inc(x_184);
lean_inc(x_183);
lean_dec(x_146);
x_185 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_185, 0, x_183);
lean_ctor_set(x_185, 1, x_184);
return x_185;
}
}
}
else
{
lean_object* x_186; lean_object* x_187; lean_object* x_188; lean_object* x_189; uint8_t x_190; 
x_186 = lean_ctor_get(x_145, 0);
x_187 = lean_box(2);
x_188 = l_Lean_Syntax_mkStrLit(x_186, x_187);
x_189 = l_Lean_PrettyPrinter_Delaborator_annotateTermLikeInfo___rarg(x_188, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_8);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
x_190 = !lean_is_exclusive(x_189);
if (x_190 == 0)
{
lean_object* x_191; lean_object* x_192; uint8_t x_193; lean_object* x_194; lean_object* x_195; lean_object* x_196; lean_object* x_197; lean_object* x_198; lean_object* x_199; lean_object* x_200; 
x_191 = lean_ctor_get(x_189, 0);
x_192 = lean_ctor_get(x_7, 5);
lean_inc(x_192);
lean_dec(x_7);
x_193 = 0;
x_194 = l_Lean_SourceInfo_fromRef(x_192, x_193);
lean_dec(x_192);
x_195 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
lean_inc(x_194);
x_196 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_196, 0, x_194);
lean_ctor_set(x_196, 1, x_195);
x_197 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__4;
lean_inc(x_194);
x_198 = l_Lean_Syntax_node1(x_194, x_197, x_191);
x_199 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
x_200 = l_Lean_Syntax_node3(x_194, x_199, x_1, x_196, x_198);
lean_ctor_set(x_189, 0, x_200);
return x_189;
}
else
{
lean_object* x_201; lean_object* x_202; lean_object* x_203; uint8_t x_204; lean_object* x_205; lean_object* x_206; lean_object* x_207; lean_object* x_208; lean_object* x_209; lean_object* x_210; lean_object* x_211; lean_object* x_212; 
x_201 = lean_ctor_get(x_189, 0);
x_202 = lean_ctor_get(x_189, 1);
lean_inc(x_202);
lean_inc(x_201);
lean_dec(x_189);
x_203 = lean_ctor_get(x_7, 5);
lean_inc(x_203);
lean_dec(x_7);
x_204 = 0;
x_205 = l_Lean_SourceInfo_fromRef(x_203, x_204);
lean_dec(x_203);
x_206 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
lean_inc(x_205);
x_207 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_207, 0, x_205);
lean_ctor_set(x_207, 1, x_206);
x_208 = l_ProofWidgets_Jsx_jsxAttrVal_____closed__4;
lean_inc(x_205);
x_209 = l_Lean_Syntax_node1(x_205, x_208, x_201);
x_210 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
x_211 = l_Lean_Syntax_node3(x_205, x_210, x_1, x_207, x_209);
x_212 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_212, 0, x_211);
lean_ctor_set(x_212, 1, x_202);
return x_212;
}
}
}
else
{
lean_object* x_213; 
lean_inc(x_7);
x_213 = l_Lean_PrettyPrinter_Delaborator_delab(x_3, x_4, x_5, x_6, x_7, x_8, x_9);
if (lean_obj_tag(x_213) == 0)
{
uint8_t x_214; 
x_214 = !lean_is_exclusive(x_213);
if (x_214 == 0)
{
lean_object* x_215; lean_object* x_216; uint8_t x_217; lean_object* x_218; lean_object* x_219; lean_object* x_220; lean_object* x_221; lean_object* x_222; lean_object* x_223; lean_object* x_224; lean_object* x_225; lean_object* x_226; lean_object* x_227; lean_object* x_228; lean_object* x_229; lean_object* x_230; 
x_215 = lean_ctor_get(x_213, 0);
x_216 = lean_ctor_get(x_7, 5);
lean_inc(x_216);
lean_dec(x_7);
x_217 = 0;
x_218 = l_Lean_SourceInfo_fromRef(x_216, x_217);
lean_dec(x_216);
x_219 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
lean_inc(x_218);
x_220 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_220, 0, x_218);
lean_ctor_set(x_220, 1, x_219);
x_221 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_218);
x_222 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_222, 0, x_218);
lean_ctor_set(x_222, 1, x_221);
x_223 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_218);
x_224 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_224, 0, x_218);
lean_ctor_set(x_224, 1, x_223);
x_225 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_218);
x_226 = l_Lean_Syntax_node3(x_218, x_225, x_222, x_215, x_224);
x_227 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2;
lean_inc(x_218);
x_228 = l_Lean_Syntax_node1(x_218, x_227, x_226);
x_229 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
x_230 = l_Lean_Syntax_node3(x_218, x_229, x_1, x_220, x_228);
lean_ctor_set(x_213, 0, x_230);
return x_213;
}
else
{
lean_object* x_231; lean_object* x_232; lean_object* x_233; uint8_t x_234; lean_object* x_235; lean_object* x_236; lean_object* x_237; lean_object* x_238; lean_object* x_239; lean_object* x_240; lean_object* x_241; lean_object* x_242; lean_object* x_243; lean_object* x_244; lean_object* x_245; lean_object* x_246; lean_object* x_247; lean_object* x_248; 
x_231 = lean_ctor_get(x_213, 0);
x_232 = lean_ctor_get(x_213, 1);
lean_inc(x_232);
lean_inc(x_231);
lean_dec(x_213);
x_233 = lean_ctor_get(x_7, 5);
lean_inc(x_233);
lean_dec(x_7);
x_234 = 0;
x_235 = l_Lean_SourceInfo_fromRef(x_233, x_234);
lean_dec(x_233);
x_236 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
lean_inc(x_235);
x_237 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_237, 0, x_235);
lean_ctor_set(x_237, 1, x_236);
x_238 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_235);
x_239 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_239, 0, x_235);
lean_ctor_set(x_239, 1, x_238);
x_240 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_235);
x_241 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_241, 0, x_235);
lean_ctor_set(x_241, 1, x_240);
x_242 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_235);
x_243 = l_Lean_Syntax_node3(x_235, x_242, x_239, x_231, x_241);
x_244 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2;
lean_inc(x_235);
x_245 = l_Lean_Syntax_node1(x_235, x_244, x_243);
x_246 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
x_247 = l_Lean_Syntax_node3(x_235, x_246, x_1, x_237, x_245);
x_248 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_248, 0, x_247);
lean_ctor_set(x_248, 1, x_232);
return x_248;
}
}
else
{
uint8_t x_249; 
lean_dec(x_7);
lean_dec(x_1);
x_249 = !lean_is_exclusive(x_213);
if (x_249 == 0)
{
return x_213;
}
else
{
lean_object* x_250; lean_object* x_251; lean_object* x_252; 
x_250 = lean_ctor_get(x_213, 0);
x_251 = lean_ctor_get(x_213, 1);
lean_inc(x_251);
lean_inc(x_250);
lean_dec(x_213);
x_252 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_252, 0, x_250);
lean_ctor_set(x_252, 1, x_251);
return x_252;
}
}
}
}
}
}
}
else
{
lean_object* x_253; 
lean_inc(x_7);
x_253 = l_Lean_PrettyPrinter_Delaborator_delab(x_3, x_4, x_5, x_6, x_7, x_8, x_9);
if (lean_obj_tag(x_253) == 0)
{
uint8_t x_254; 
x_254 = !lean_is_exclusive(x_253);
if (x_254 == 0)
{
lean_object* x_255; lean_object* x_256; uint8_t x_257; lean_object* x_258; lean_object* x_259; lean_object* x_260; lean_object* x_261; lean_object* x_262; lean_object* x_263; lean_object* x_264; lean_object* x_265; lean_object* x_266; lean_object* x_267; lean_object* x_268; lean_object* x_269; lean_object* x_270; 
x_255 = lean_ctor_get(x_253, 0);
x_256 = lean_ctor_get(x_7, 5);
lean_inc(x_256);
lean_dec(x_7);
x_257 = 0;
x_258 = l_Lean_SourceInfo_fromRef(x_256, x_257);
lean_dec(x_256);
x_259 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
lean_inc(x_258);
x_260 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_260, 0, x_258);
lean_ctor_set(x_260, 1, x_259);
x_261 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_258);
x_262 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_262, 0, x_258);
lean_ctor_set(x_262, 1, x_261);
x_263 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_258);
x_264 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_264, 0, x_258);
lean_ctor_set(x_264, 1, x_263);
x_265 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_258);
x_266 = l_Lean_Syntax_node3(x_258, x_265, x_262, x_255, x_264);
x_267 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2;
lean_inc(x_258);
x_268 = l_Lean_Syntax_node1(x_258, x_267, x_266);
x_269 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
x_270 = l_Lean_Syntax_node3(x_258, x_269, x_1, x_260, x_268);
lean_ctor_set(x_253, 0, x_270);
return x_253;
}
else
{
lean_object* x_271; lean_object* x_272; lean_object* x_273; uint8_t x_274; lean_object* x_275; lean_object* x_276; lean_object* x_277; lean_object* x_278; lean_object* x_279; lean_object* x_280; lean_object* x_281; lean_object* x_282; lean_object* x_283; lean_object* x_284; lean_object* x_285; lean_object* x_286; lean_object* x_287; lean_object* x_288; 
x_271 = lean_ctor_get(x_253, 0);
x_272 = lean_ctor_get(x_253, 1);
lean_inc(x_272);
lean_inc(x_271);
lean_dec(x_253);
x_273 = lean_ctor_get(x_7, 5);
lean_inc(x_273);
lean_dec(x_7);
x_274 = 0;
x_275 = l_Lean_SourceInfo_fromRef(x_273, x_274);
lean_dec(x_273);
x_276 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
lean_inc(x_275);
x_277 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_277, 0, x_275);
lean_ctor_set(x_277, 1, x_276);
x_278 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_275);
x_279 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_279, 0, x_275);
lean_ctor_set(x_279, 1, x_278);
x_280 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_275);
x_281 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_281, 0, x_275);
lean_ctor_set(x_281, 1, x_280);
x_282 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_275);
x_283 = l_Lean_Syntax_node3(x_275, x_282, x_279, x_271, x_281);
x_284 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2;
lean_inc(x_275);
x_285 = l_Lean_Syntax_node1(x_275, x_284, x_283);
x_286 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
x_287 = l_Lean_Syntax_node3(x_275, x_286, x_1, x_277, x_285);
x_288 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_288, 0, x_287);
lean_ctor_set(x_288, 1, x_272);
return x_288;
}
}
else
{
uint8_t x_289; 
lean_dec(x_7);
lean_dec(x_1);
x_289 = !lean_is_exclusive(x_253);
if (x_289 == 0)
{
return x_253;
}
else
{
lean_object* x_290; lean_object* x_291; lean_object* x_292; 
x_290 = lean_ctor_get(x_253, 0);
x_291 = lean_ctor_get(x_253, 1);
lean_inc(x_291);
lean_inc(x_290);
lean_dec(x_253);
x_292 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_292, 0, x_290);
lean_ctor_set(x_292, 1, x_291);
return x_292;
}
}
}
}
else
{
lean_object* x_293; 
lean_inc(x_7);
x_293 = l_Lean_PrettyPrinter_Delaborator_delab(x_3, x_4, x_5, x_6, x_7, x_8, x_9);
if (lean_obj_tag(x_293) == 0)
{
uint8_t x_294; 
x_294 = !lean_is_exclusive(x_293);
if (x_294 == 0)
{
lean_object* x_295; lean_object* x_296; uint8_t x_297; lean_object* x_298; lean_object* x_299; lean_object* x_300; lean_object* x_301; lean_object* x_302; lean_object* x_303; lean_object* x_304; lean_object* x_305; lean_object* x_306; lean_object* x_307; lean_object* x_308; lean_object* x_309; lean_object* x_310; 
x_295 = lean_ctor_get(x_293, 0);
x_296 = lean_ctor_get(x_7, 5);
lean_inc(x_296);
lean_dec(x_7);
x_297 = 0;
x_298 = l_Lean_SourceInfo_fromRef(x_296, x_297);
lean_dec(x_296);
x_299 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
lean_inc(x_298);
x_300 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_300, 0, x_298);
lean_ctor_set(x_300, 1, x_299);
x_301 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_298);
x_302 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_302, 0, x_298);
lean_ctor_set(x_302, 1, x_301);
x_303 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_298);
x_304 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_304, 0, x_298);
lean_ctor_set(x_304, 1, x_303);
x_305 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_298);
x_306 = l_Lean_Syntax_node3(x_298, x_305, x_302, x_295, x_304);
x_307 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2;
lean_inc(x_298);
x_308 = l_Lean_Syntax_node1(x_298, x_307, x_306);
x_309 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
x_310 = l_Lean_Syntax_node3(x_298, x_309, x_1, x_300, x_308);
lean_ctor_set(x_293, 0, x_310);
return x_293;
}
else
{
lean_object* x_311; lean_object* x_312; lean_object* x_313; uint8_t x_314; lean_object* x_315; lean_object* x_316; lean_object* x_317; lean_object* x_318; lean_object* x_319; lean_object* x_320; lean_object* x_321; lean_object* x_322; lean_object* x_323; lean_object* x_324; lean_object* x_325; lean_object* x_326; lean_object* x_327; lean_object* x_328; 
x_311 = lean_ctor_get(x_293, 0);
x_312 = lean_ctor_get(x_293, 1);
lean_inc(x_312);
lean_inc(x_311);
lean_dec(x_293);
x_313 = lean_ctor_get(x_7, 5);
lean_inc(x_313);
lean_dec(x_7);
x_314 = 0;
x_315 = l_Lean_SourceInfo_fromRef(x_313, x_314);
lean_dec(x_313);
x_316 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
lean_inc(x_315);
x_317 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_317, 0, x_315);
lean_ctor_set(x_317, 1, x_316);
x_318 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_315);
x_319 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_319, 0, x_315);
lean_ctor_set(x_319, 1, x_318);
x_320 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_315);
x_321 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_321, 0, x_315);
lean_ctor_set(x_321, 1, x_320);
x_322 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_315);
x_323 = l_Lean_Syntax_node3(x_315, x_322, x_319, x_311, x_321);
x_324 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2;
lean_inc(x_315);
x_325 = l_Lean_Syntax_node1(x_315, x_324, x_323);
x_326 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
x_327 = l_Lean_Syntax_node3(x_315, x_326, x_1, x_317, x_325);
x_328 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_328, 0, x_327);
lean_ctor_set(x_328, 1, x_312);
return x_328;
}
}
else
{
uint8_t x_329; 
lean_dec(x_7);
lean_dec(x_1);
x_329 = !lean_is_exclusive(x_293);
if (x_329 == 0)
{
return x_293;
}
else
{
lean_object* x_330; lean_object* x_331; lean_object* x_332; 
x_330 = lean_ctor_get(x_293, 0);
x_331 = lean_ctor_get(x_293, 1);
lean_inc(x_331);
lean_inc(x_330);
lean_dec(x_293);
x_332 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_332, 0, x_330);
lean_ctor_set(x_332, 1, x_331);
return x_332;
}
}
}
}
else
{
lean_object* x_333; 
lean_inc(x_7);
x_333 = l_Lean_PrettyPrinter_Delaborator_delab(x_3, x_4, x_5, x_6, x_7, x_8, x_9);
if (lean_obj_tag(x_333) == 0)
{
uint8_t x_334; 
x_334 = !lean_is_exclusive(x_333);
if (x_334 == 0)
{
lean_object* x_335; lean_object* x_336; uint8_t x_337; lean_object* x_338; lean_object* x_339; lean_object* x_340; lean_object* x_341; lean_object* x_342; lean_object* x_343; lean_object* x_344; lean_object* x_345; lean_object* x_346; lean_object* x_347; lean_object* x_348; lean_object* x_349; lean_object* x_350; 
x_335 = lean_ctor_get(x_333, 0);
x_336 = lean_ctor_get(x_7, 5);
lean_inc(x_336);
lean_dec(x_7);
x_337 = 0;
x_338 = l_Lean_SourceInfo_fromRef(x_336, x_337);
lean_dec(x_336);
x_339 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
lean_inc(x_338);
x_340 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_340, 0, x_338);
lean_ctor_set(x_340, 1, x_339);
x_341 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_338);
x_342 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_342, 0, x_338);
lean_ctor_set(x_342, 1, x_341);
x_343 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_338);
x_344 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_344, 0, x_338);
lean_ctor_set(x_344, 1, x_343);
x_345 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_338);
x_346 = l_Lean_Syntax_node3(x_338, x_345, x_342, x_335, x_344);
x_347 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2;
lean_inc(x_338);
x_348 = l_Lean_Syntax_node1(x_338, x_347, x_346);
x_349 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
x_350 = l_Lean_Syntax_node3(x_338, x_349, x_1, x_340, x_348);
lean_ctor_set(x_333, 0, x_350);
return x_333;
}
else
{
lean_object* x_351; lean_object* x_352; lean_object* x_353; uint8_t x_354; lean_object* x_355; lean_object* x_356; lean_object* x_357; lean_object* x_358; lean_object* x_359; lean_object* x_360; lean_object* x_361; lean_object* x_362; lean_object* x_363; lean_object* x_364; lean_object* x_365; lean_object* x_366; lean_object* x_367; lean_object* x_368; 
x_351 = lean_ctor_get(x_333, 0);
x_352 = lean_ctor_get(x_333, 1);
lean_inc(x_352);
lean_inc(x_351);
lean_dec(x_333);
x_353 = lean_ctor_get(x_7, 5);
lean_inc(x_353);
lean_dec(x_7);
x_354 = 0;
x_355 = l_Lean_SourceInfo_fromRef(x_353, x_354);
lean_dec(x_353);
x_356 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
lean_inc(x_355);
x_357 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_357, 0, x_355);
lean_ctor_set(x_357, 1, x_356);
x_358 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_355);
x_359 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_359, 0, x_355);
lean_ctor_set(x_359, 1, x_358);
x_360 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_355);
x_361 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_361, 0, x_355);
lean_ctor_set(x_361, 1, x_360);
x_362 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_355);
x_363 = l_Lean_Syntax_node3(x_355, x_362, x_359, x_351, x_361);
x_364 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2;
lean_inc(x_355);
x_365 = l_Lean_Syntax_node1(x_355, x_364, x_363);
x_366 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
x_367 = l_Lean_Syntax_node3(x_355, x_366, x_1, x_357, x_365);
x_368 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_368, 0, x_367);
lean_ctor_set(x_368, 1, x_352);
return x_368;
}
}
else
{
uint8_t x_369; 
lean_dec(x_7);
lean_dec(x_1);
x_369 = !lean_is_exclusive(x_333);
if (x_369 == 0)
{
return x_333;
}
else
{
lean_object* x_370; lean_object* x_371; lean_object* x_372; 
x_370 = lean_ctor_get(x_333, 0);
x_371 = lean_ctor_get(x_333, 1);
lean_inc(x_371);
lean_inc(x_370);
lean_dec(x_333);
x_372 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_372, 0, x_370);
lean_ctor_set(x_372, 1, x_371);
return x_372;
}
}
}
}
else
{
lean_object* x_373; 
lean_inc(x_7);
x_373 = l_Lean_PrettyPrinter_Delaborator_delab(x_3, x_4, x_5, x_6, x_7, x_8, x_9);
if (lean_obj_tag(x_373) == 0)
{
uint8_t x_374; 
x_374 = !lean_is_exclusive(x_373);
if (x_374 == 0)
{
lean_object* x_375; lean_object* x_376; uint8_t x_377; lean_object* x_378; lean_object* x_379; lean_object* x_380; lean_object* x_381; lean_object* x_382; lean_object* x_383; lean_object* x_384; lean_object* x_385; lean_object* x_386; lean_object* x_387; lean_object* x_388; lean_object* x_389; lean_object* x_390; 
x_375 = lean_ctor_get(x_373, 0);
x_376 = lean_ctor_get(x_7, 5);
lean_inc(x_376);
lean_dec(x_7);
x_377 = 0;
x_378 = l_Lean_SourceInfo_fromRef(x_376, x_377);
lean_dec(x_376);
x_379 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
lean_inc(x_378);
x_380 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_380, 0, x_378);
lean_ctor_set(x_380, 1, x_379);
x_381 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_378);
x_382 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_382, 0, x_378);
lean_ctor_set(x_382, 1, x_381);
x_383 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_378);
x_384 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_384, 0, x_378);
lean_ctor_set(x_384, 1, x_383);
x_385 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_378);
x_386 = l_Lean_Syntax_node3(x_378, x_385, x_382, x_375, x_384);
x_387 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2;
lean_inc(x_378);
x_388 = l_Lean_Syntax_node1(x_378, x_387, x_386);
x_389 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
x_390 = l_Lean_Syntax_node3(x_378, x_389, x_1, x_380, x_388);
lean_ctor_set(x_373, 0, x_390);
return x_373;
}
else
{
lean_object* x_391; lean_object* x_392; lean_object* x_393; uint8_t x_394; lean_object* x_395; lean_object* x_396; lean_object* x_397; lean_object* x_398; lean_object* x_399; lean_object* x_400; lean_object* x_401; lean_object* x_402; lean_object* x_403; lean_object* x_404; lean_object* x_405; lean_object* x_406; lean_object* x_407; lean_object* x_408; 
x_391 = lean_ctor_get(x_373, 0);
x_392 = lean_ctor_get(x_373, 1);
lean_inc(x_392);
lean_inc(x_391);
lean_dec(x_373);
x_393 = lean_ctor_get(x_7, 5);
lean_inc(x_393);
lean_dec(x_7);
x_394 = 0;
x_395 = l_Lean_SourceInfo_fromRef(x_393, x_394);
lean_dec(x_393);
x_396 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
lean_inc(x_395);
x_397 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_397, 0, x_395);
lean_ctor_set(x_397, 1, x_396);
x_398 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_395);
x_399 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_399, 0, x_395);
lean_ctor_set(x_399, 1, x_398);
x_400 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_395);
x_401 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_401, 0, x_395);
lean_ctor_set(x_401, 1, x_400);
x_402 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_395);
x_403 = l_Lean_Syntax_node3(x_395, x_402, x_399, x_391, x_401);
x_404 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2;
lean_inc(x_395);
x_405 = l_Lean_Syntax_node1(x_395, x_404, x_403);
x_406 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
x_407 = l_Lean_Syntax_node3(x_395, x_406, x_1, x_397, x_405);
x_408 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_408, 0, x_407);
lean_ctor_set(x_408, 1, x_392);
return x_408;
}
}
else
{
uint8_t x_409; 
lean_dec(x_7);
lean_dec(x_1);
x_409 = !lean_is_exclusive(x_373);
if (x_409 == 0)
{
return x_373;
}
else
{
lean_object* x_410; lean_object* x_411; lean_object* x_412; 
x_410 = lean_ctor_get(x_373, 0);
x_411 = lean_ctor_get(x_373, 1);
lean_inc(x_411);
lean_inc(x_410);
lean_dec(x_373);
x_412 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_412, 0, x_410);
lean_ctor_set(x_412, 1, x_411);
return x_412;
}
}
}
}
else
{
lean_object* x_413; 
lean_inc(x_7);
x_413 = l_Lean_PrettyPrinter_Delaborator_delab(x_3, x_4, x_5, x_6, x_7, x_8, x_9);
if (lean_obj_tag(x_413) == 0)
{
uint8_t x_414; 
x_414 = !lean_is_exclusive(x_413);
if (x_414 == 0)
{
lean_object* x_415; lean_object* x_416; uint8_t x_417; lean_object* x_418; lean_object* x_419; lean_object* x_420; lean_object* x_421; lean_object* x_422; lean_object* x_423; lean_object* x_424; lean_object* x_425; lean_object* x_426; lean_object* x_427; lean_object* x_428; lean_object* x_429; lean_object* x_430; 
x_415 = lean_ctor_get(x_413, 0);
x_416 = lean_ctor_get(x_7, 5);
lean_inc(x_416);
lean_dec(x_7);
x_417 = 0;
x_418 = l_Lean_SourceInfo_fromRef(x_416, x_417);
lean_dec(x_416);
x_419 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
lean_inc(x_418);
x_420 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_420, 0, x_418);
lean_ctor_set(x_420, 1, x_419);
x_421 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_418);
x_422 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_422, 0, x_418);
lean_ctor_set(x_422, 1, x_421);
x_423 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_418);
x_424 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_424, 0, x_418);
lean_ctor_set(x_424, 1, x_423);
x_425 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_418);
x_426 = l_Lean_Syntax_node3(x_418, x_425, x_422, x_415, x_424);
x_427 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2;
lean_inc(x_418);
x_428 = l_Lean_Syntax_node1(x_418, x_427, x_426);
x_429 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
x_430 = l_Lean_Syntax_node3(x_418, x_429, x_1, x_420, x_428);
lean_ctor_set(x_413, 0, x_430);
return x_413;
}
else
{
lean_object* x_431; lean_object* x_432; lean_object* x_433; uint8_t x_434; lean_object* x_435; lean_object* x_436; lean_object* x_437; lean_object* x_438; lean_object* x_439; lean_object* x_440; lean_object* x_441; lean_object* x_442; lean_object* x_443; lean_object* x_444; lean_object* x_445; lean_object* x_446; lean_object* x_447; lean_object* x_448; 
x_431 = lean_ctor_get(x_413, 0);
x_432 = lean_ctor_get(x_413, 1);
lean_inc(x_432);
lean_inc(x_431);
lean_dec(x_413);
x_433 = lean_ctor_get(x_7, 5);
lean_inc(x_433);
lean_dec(x_7);
x_434 = 0;
x_435 = l_Lean_SourceInfo_fromRef(x_433, x_434);
lean_dec(x_433);
x_436 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
lean_inc(x_435);
x_437 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_437, 0, x_435);
lean_ctor_set(x_437, 1, x_436);
x_438 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_435);
x_439 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_439, 0, x_435);
lean_ctor_set(x_439, 1, x_438);
x_440 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_435);
x_441 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_441, 0, x_435);
lean_ctor_set(x_441, 1, x_440);
x_442 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_435);
x_443 = l_Lean_Syntax_node3(x_435, x_442, x_439, x_431, x_441);
x_444 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2;
lean_inc(x_435);
x_445 = l_Lean_Syntax_node1(x_435, x_444, x_443);
x_446 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
x_447 = l_Lean_Syntax_node3(x_435, x_446, x_1, x_437, x_445);
x_448 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_448, 0, x_447);
lean_ctor_set(x_448, 1, x_432);
return x_448;
}
}
else
{
uint8_t x_449; 
lean_dec(x_7);
lean_dec(x_1);
x_449 = !lean_is_exclusive(x_413);
if (x_449 == 0)
{
return x_413;
}
else
{
lean_object* x_450; lean_object* x_451; lean_object* x_452; 
x_450 = lean_ctor_get(x_413, 0);
x_451 = lean_ctor_get(x_413, 1);
lean_inc(x_451);
lean_inc(x_450);
lean_dec(x_413);
x_452 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_452, 0, x_450);
lean_ctor_set(x_452, 1, x_451);
return x_452;
}
}
}
}
else
{
lean_object* x_453; 
lean_inc(x_7);
x_453 = l_Lean_PrettyPrinter_Delaborator_delab(x_3, x_4, x_5, x_6, x_7, x_8, x_9);
if (lean_obj_tag(x_453) == 0)
{
uint8_t x_454; 
x_454 = !lean_is_exclusive(x_453);
if (x_454 == 0)
{
lean_object* x_455; lean_object* x_456; uint8_t x_457; lean_object* x_458; lean_object* x_459; lean_object* x_460; lean_object* x_461; lean_object* x_462; lean_object* x_463; lean_object* x_464; lean_object* x_465; lean_object* x_466; lean_object* x_467; lean_object* x_468; lean_object* x_469; lean_object* x_470; 
x_455 = lean_ctor_get(x_453, 0);
x_456 = lean_ctor_get(x_7, 5);
lean_inc(x_456);
lean_dec(x_7);
x_457 = 0;
x_458 = l_Lean_SourceInfo_fromRef(x_456, x_457);
lean_dec(x_456);
x_459 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
lean_inc(x_458);
x_460 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_460, 0, x_458);
lean_ctor_set(x_460, 1, x_459);
x_461 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_458);
x_462 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_462, 0, x_458);
lean_ctor_set(x_462, 1, x_461);
x_463 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_458);
x_464 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_464, 0, x_458);
lean_ctor_set(x_464, 1, x_463);
x_465 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_458);
x_466 = l_Lean_Syntax_node3(x_458, x_465, x_462, x_455, x_464);
x_467 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2;
lean_inc(x_458);
x_468 = l_Lean_Syntax_node1(x_458, x_467, x_466);
x_469 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
x_470 = l_Lean_Syntax_node3(x_458, x_469, x_1, x_460, x_468);
lean_ctor_set(x_453, 0, x_470);
return x_453;
}
else
{
lean_object* x_471; lean_object* x_472; lean_object* x_473; uint8_t x_474; lean_object* x_475; lean_object* x_476; lean_object* x_477; lean_object* x_478; lean_object* x_479; lean_object* x_480; lean_object* x_481; lean_object* x_482; lean_object* x_483; lean_object* x_484; lean_object* x_485; lean_object* x_486; lean_object* x_487; lean_object* x_488; 
x_471 = lean_ctor_get(x_453, 0);
x_472 = lean_ctor_get(x_453, 1);
lean_inc(x_472);
lean_inc(x_471);
lean_dec(x_453);
x_473 = lean_ctor_get(x_7, 5);
lean_inc(x_473);
lean_dec(x_7);
x_474 = 0;
x_475 = l_Lean_SourceInfo_fromRef(x_473, x_474);
lean_dec(x_473);
x_476 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
lean_inc(x_475);
x_477 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_477, 0, x_475);
lean_ctor_set(x_477, 1, x_476);
x_478 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_475);
x_479 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_479, 0, x_475);
lean_ctor_set(x_479, 1, x_478);
x_480 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_475);
x_481 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_481, 0, x_475);
lean_ctor_set(x_481, 1, x_480);
x_482 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_475);
x_483 = l_Lean_Syntax_node3(x_475, x_482, x_479, x_471, x_481);
x_484 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2;
lean_inc(x_475);
x_485 = l_Lean_Syntax_node1(x_475, x_484, x_483);
x_486 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
x_487 = l_Lean_Syntax_node3(x_475, x_486, x_1, x_477, x_485);
x_488 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_488, 0, x_487);
lean_ctor_set(x_488, 1, x_472);
return x_488;
}
}
else
{
uint8_t x_489; 
lean_dec(x_7);
lean_dec(x_1);
x_489 = !lean_is_exclusive(x_453);
if (x_489 == 0)
{
return x_453;
}
else
{
lean_object* x_490; lean_object* x_491; lean_object* x_492; 
x_490 = lean_ctor_get(x_453, 0);
x_491 = lean_ctor_get(x_453, 1);
lean_inc(x_491);
lean_inc(x_490);
lean_dec(x_453);
x_492 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_492, 0, x_490);
lean_ctor_set(x_492, 1, x_491);
return x_492;
}
}
}
}
}
static lean_object* _init_l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__2___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_Lean_PrettyPrinter_Delaborator_SubExpr_getExpr___at_Lean_PrettyPrinter_Delaborator_getExprKind___spec__1___boxed), 7, 0);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
if (lean_obj_tag(x_1) == 9)
{
lean_object* x_9; 
x_9 = lean_ctor_get(x_1, 0);
lean_inc(x_9);
lean_dec(x_1);
if (lean_obj_tag(x_9) == 0)
{
lean_object* x_10; 
lean_dec(x_9);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_10 = l_Lean_PrettyPrinter_Delaborator_failure___rarg(x_8);
return x_10;
}
else
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; 
x_11 = lean_ctor_get(x_9, 0);
lean_inc(x_11);
lean_dec(x_9);
x_12 = lean_box(0);
x_13 = l_Lean_Name_str___override(x_12, x_11);
x_14 = lean_mk_syntax_ident(x_13);
x_15 = lean_alloc_closure((void*)(l_Lean_PrettyPrinter_Delaborator_annotateTermLikeInfo___rarg___boxed), 8, 1);
lean_closure_set(x_15, 0, x_14);
x_16 = lean_unsigned_to_nat(2u);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
lean_inc(x_3);
lean_inc(x_2);
x_17 = l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__1(x_16, x_15, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
if (lean_obj_tag(x_17) == 0)
{
lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; 
x_18 = lean_ctor_get(x_17, 0);
lean_inc(x_18);
x_19 = lean_ctor_get(x_17, 1);
lean_inc(x_19);
lean_dec(x_17);
x_20 = lean_alloc_closure((void*)(l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__1___boxed), 9, 1);
lean_closure_set(x_20, 0, x_18);
x_21 = l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__2___closed__1;
x_22 = lean_alloc_closure((void*)(l_ReaderT_bind___at_Lean_PrettyPrinter_Delaborator_delabMVar___spec__1___rarg), 9, 2);
lean_closure_set(x_22, 0, x_21);
lean_closure_set(x_22, 1, x_20);
x_23 = lean_unsigned_to_nat(3u);
x_24 = l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__2(x_23, x_22, x_2, x_3, x_4, x_5, x_6, x_7, x_19);
return x_24;
}
else
{
uint8_t x_25; 
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_25 = !lean_is_exclusive(x_17);
if (x_25 == 0)
{
return x_17;
}
else
{
lean_object* x_26; lean_object* x_27; lean_object* x_28; 
x_26 = lean_ctor_get(x_17, 0);
x_27 = lean_ctor_get(x_17, 1);
lean_inc(x_27);
lean_inc(x_26);
lean_dec(x_17);
x_28 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_28, 0, x_26);
lean_ctor_set(x_28, 1, x_27);
return x_28;
}
}
}
}
else
{
lean_object* x_29; 
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_29 = l_Lean_PrettyPrinter_Delaborator_failure___rarg(x_8);
return x_29;
}
}
}
static lean_object* _init_l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__3___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__2), 8, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__3___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("Prod", 4, 4);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__3___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_mk_string_unchecked("mk", 2, 2);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__3___closed__4() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__3___closed__2;
x_2 = l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__3___closed__3;
x_3 = l_Lean_Name_mkStr2(x_1, x_2);
return x_3;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__3(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; lean_object* x_10; uint8_t x_11; 
x_9 = l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__3___closed__1;
x_10 = l_Lean_Expr_cleanupAnnotations(x_1);
x_11 = l_Lean_Expr_isApp(x_10);
if (x_11 == 0)
{
lean_object* x_12; 
lean_dec(x_10);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_12 = l_Lean_PrettyPrinter_Delaborator_failure___rarg(x_8);
return x_12;
}
else
{
lean_object* x_13; uint8_t x_14; 
x_13 = l_Lean_Expr_appFnCleanup(x_10, lean_box(0));
x_14 = l_Lean_Expr_isApp(x_13);
if (x_14 == 0)
{
lean_object* x_15; 
lean_dec(x_13);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_15 = l_Lean_PrettyPrinter_Delaborator_failure___rarg(x_8);
return x_15;
}
else
{
lean_object* x_16; lean_object* x_17; uint8_t x_18; 
x_16 = l_Lean_Expr_appArg(x_13, lean_box(0));
x_17 = l_Lean_Expr_appFnCleanup(x_13, lean_box(0));
x_18 = l_Lean_Expr_isApp(x_17);
if (x_18 == 0)
{
lean_object* x_19; 
lean_dec(x_17);
lean_dec(x_16);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_19 = l_Lean_PrettyPrinter_Delaborator_failure___rarg(x_8);
return x_19;
}
else
{
lean_object* x_20; uint8_t x_21; 
x_20 = l_Lean_Expr_appFnCleanup(x_17, lean_box(0));
x_21 = l_Lean_Expr_isApp(x_20);
if (x_21 == 0)
{
lean_object* x_22; 
lean_dec(x_20);
lean_dec(x_16);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_22 = l_Lean_PrettyPrinter_Delaborator_failure___rarg(x_8);
return x_22;
}
else
{
lean_object* x_23; lean_object* x_24; uint8_t x_25; 
x_23 = l_Lean_Expr_appFnCleanup(x_20, lean_box(0));
x_24 = l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__3___closed__4;
x_25 = l_Lean_Expr_isConstOf(x_23, x_24);
lean_dec(x_23);
if (x_25 == 0)
{
lean_object* x_26; 
lean_dec(x_16);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_26 = l_Lean_PrettyPrinter_Delaborator_failure___rarg(x_8);
return x_26;
}
else
{
lean_object* x_27; 
x_27 = lean_apply_8(x_9, x_16, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
return x_27;
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__4(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
lean_inc(x_3);
lean_inc(x_2);
x_9 = l_Lean_PrettyPrinter_Delaborator_delabArrayLiteral___rarg(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
if (lean_obj_tag(x_9) == 0)
{
uint8_t x_10; 
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_10 = !lean_is_exclusive(x_9);
if (x_10 == 0)
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; 
x_11 = lean_ctor_get(x_9, 0);
x_12 = lean_box(0);
x_13 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_13, 0, x_11);
lean_ctor_set(x_13, 1, x_12);
lean_ctor_set(x_9, 0, x_13);
return x_9;
}
else
{
lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_14 = lean_ctor_get(x_9, 0);
x_15 = lean_ctor_get(x_9, 1);
lean_inc(x_15);
lean_inc(x_14);
lean_dec(x_9);
x_16 = lean_box(0);
x_17 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_17, 0, x_14);
lean_ctor_set(x_17, 1, x_16);
x_18 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_18, 0, x_17);
lean_ctor_set(x_18, 1, x_15);
return x_18;
}
}
else
{
uint8_t x_19; 
x_19 = !lean_is_exclusive(x_9);
if (x_19 == 0)
{
lean_object* x_20; lean_object* x_21; uint8_t x_22; 
x_20 = lean_ctor_get(x_9, 0);
x_21 = lean_ctor_get(x_9, 1);
x_22 = l_Lean_Exception_isInterrupt(x_20);
if (x_22 == 0)
{
uint8_t x_23; 
x_23 = l_Lean_Exception_isRuntime(x_20);
if (x_23 == 0)
{
lean_object* x_24; 
lean_free_object(x_9);
lean_dec(x_20);
lean_inc(x_6);
x_24 = l_Lean_PrettyPrinter_Delaborator_delab(x_2, x_3, x_4, x_5, x_6, x_7, x_21);
if (lean_obj_tag(x_24) == 0)
{
uint8_t x_25; 
x_25 = !lean_is_exclusive(x_24);
if (x_25 == 0)
{
lean_object* x_26; lean_object* x_27; uint8_t x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; 
x_26 = lean_ctor_get(x_24, 0);
x_27 = lean_ctor_get(x_6, 5);
lean_inc(x_27);
lean_dec(x_6);
x_28 = 0;
x_29 = l_Lean_SourceInfo_fromRef(x_27, x_28);
lean_dec(x_27);
x_30 = l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__3;
lean_inc(x_29);
x_31 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_31, 0, x_29);
lean_ctor_set(x_31, 1, x_30);
x_32 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_29);
x_33 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_33, 0, x_29);
lean_ctor_set(x_33, 1, x_32);
x_34 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_29);
x_35 = l_Lean_Syntax_node3(x_29, x_34, x_31, x_26, x_33);
x_36 = l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__2;
x_37 = l_Lean_Syntax_node1(x_29, x_36, x_35);
x_38 = l_ProofWidgets_Jsx_delabHtmlText___lambda__1___closed__1;
x_39 = lean_array_push(x_38, x_37);
x_40 = lean_box(0);
x_41 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_41, 0, x_39);
lean_ctor_set(x_41, 1, x_40);
lean_ctor_set(x_24, 0, x_41);
return x_24;
}
else
{
lean_object* x_42; lean_object* x_43; lean_object* x_44; uint8_t x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; 
x_42 = lean_ctor_get(x_24, 0);
x_43 = lean_ctor_get(x_24, 1);
lean_inc(x_43);
lean_inc(x_42);
lean_dec(x_24);
x_44 = lean_ctor_get(x_6, 5);
lean_inc(x_44);
lean_dec(x_6);
x_45 = 0;
x_46 = l_Lean_SourceInfo_fromRef(x_44, x_45);
lean_dec(x_44);
x_47 = l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__3;
lean_inc(x_46);
x_48 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_48, 0, x_46);
lean_ctor_set(x_48, 1, x_47);
x_49 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_46);
x_50 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_50, 0, x_46);
lean_ctor_set(x_50, 1, x_49);
x_51 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_46);
x_52 = l_Lean_Syntax_node3(x_46, x_51, x_48, x_42, x_50);
x_53 = l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__2;
x_54 = l_Lean_Syntax_node1(x_46, x_53, x_52);
x_55 = l_ProofWidgets_Jsx_delabHtmlText___lambda__1___closed__1;
x_56 = lean_array_push(x_55, x_54);
x_57 = lean_box(0);
x_58 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_58, 0, x_56);
lean_ctor_set(x_58, 1, x_57);
x_59 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_59, 0, x_58);
lean_ctor_set(x_59, 1, x_43);
return x_59;
}
}
else
{
uint8_t x_60; 
lean_dec(x_6);
x_60 = !lean_is_exclusive(x_24);
if (x_60 == 0)
{
return x_24;
}
else
{
lean_object* x_61; lean_object* x_62; lean_object* x_63; 
x_61 = lean_ctor_get(x_24, 0);
x_62 = lean_ctor_get(x_24, 1);
lean_inc(x_62);
lean_inc(x_61);
lean_dec(x_24);
x_63 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_63, 0, x_61);
lean_ctor_set(x_63, 1, x_62);
return x_63;
}
}
}
else
{
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
return x_9;
}
}
else
{
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
return x_9;
}
}
else
{
lean_object* x_64; lean_object* x_65; uint8_t x_66; 
x_64 = lean_ctor_get(x_9, 0);
x_65 = lean_ctor_get(x_9, 1);
lean_inc(x_65);
lean_inc(x_64);
lean_dec(x_9);
x_66 = l_Lean_Exception_isInterrupt(x_64);
if (x_66 == 0)
{
uint8_t x_67; 
x_67 = l_Lean_Exception_isRuntime(x_64);
if (x_67 == 0)
{
lean_object* x_68; 
lean_dec(x_64);
lean_inc(x_6);
x_68 = l_Lean_PrettyPrinter_Delaborator_delab(x_2, x_3, x_4, x_5, x_6, x_7, x_65);
if (lean_obj_tag(x_68) == 0)
{
lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; uint8_t x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; lean_object* x_79; lean_object* x_80; lean_object* x_81; lean_object* x_82; lean_object* x_83; lean_object* x_84; lean_object* x_85; lean_object* x_86; lean_object* x_87; 
x_69 = lean_ctor_get(x_68, 0);
lean_inc(x_69);
x_70 = lean_ctor_get(x_68, 1);
lean_inc(x_70);
if (lean_is_exclusive(x_68)) {
 lean_ctor_release(x_68, 0);
 lean_ctor_release(x_68, 1);
 x_71 = x_68;
} else {
 lean_dec_ref(x_68);
 x_71 = lean_box(0);
}
x_72 = lean_ctor_get(x_6, 5);
lean_inc(x_72);
lean_dec(x_6);
x_73 = 0;
x_74 = l_Lean_SourceInfo_fromRef(x_72, x_73);
lean_dec(x_72);
x_75 = l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__3;
lean_inc(x_74);
x_76 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_76, 0, x_74);
lean_ctor_set(x_76, 1, x_75);
x_77 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_74);
x_78 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_78, 0, x_74);
lean_ctor_set(x_78, 1, x_77);
x_79 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_74);
x_80 = l_Lean_Syntax_node3(x_74, x_79, x_76, x_69, x_78);
x_81 = l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__2;
x_82 = l_Lean_Syntax_node1(x_74, x_81, x_80);
x_83 = l_ProofWidgets_Jsx_delabHtmlText___lambda__1___closed__1;
x_84 = lean_array_push(x_83, x_82);
x_85 = lean_box(0);
x_86 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_86, 0, x_84);
lean_ctor_set(x_86, 1, x_85);
if (lean_is_scalar(x_71)) {
 x_87 = lean_alloc_ctor(0, 2, 0);
} else {
 x_87 = x_71;
}
lean_ctor_set(x_87, 0, x_86);
lean_ctor_set(x_87, 1, x_70);
return x_87;
}
else
{
lean_object* x_88; lean_object* x_89; lean_object* x_90; lean_object* x_91; 
lean_dec(x_6);
x_88 = lean_ctor_get(x_68, 0);
lean_inc(x_88);
x_89 = lean_ctor_get(x_68, 1);
lean_inc(x_89);
if (lean_is_exclusive(x_68)) {
 lean_ctor_release(x_68, 0);
 lean_ctor_release(x_68, 1);
 x_90 = x_68;
} else {
 lean_dec_ref(x_68);
 x_90 = lean_box(0);
}
if (lean_is_scalar(x_90)) {
 x_91 = lean_alloc_ctor(1, 2, 0);
} else {
 x_91 = x_90;
}
lean_ctor_set(x_91, 0, x_88);
lean_ctor_set(x_91, 1, x_89);
return x_91;
}
}
else
{
lean_object* x_92; 
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_92 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_92, 0, x_64);
lean_ctor_set(x_92, 1, x_65);
return x_92;
}
}
else
{
lean_object* x_93; 
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_93 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_93, 0, x_64);
lean_ctor_set(x_93, 1, x_65);
return x_93;
}
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__5(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
if (lean_obj_tag(x_1) == 0)
{
uint8_t x_9; 
x_9 = !lean_is_exclusive(x_1);
if (x_9 == 0)
{
lean_object* x_10; 
x_10 = lean_ctor_get(x_1, 1);
lean_dec(x_10);
lean_ctor_set(x_1, 1, x_8);
return x_1;
}
else
{
lean_object* x_11; lean_object* x_12; 
x_11 = lean_ctor_get(x_1, 0);
lean_inc(x_11);
lean_dec(x_1);
x_12 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_12, 0, x_11);
lean_ctor_set(x_12, 1, x_8);
return x_12;
}
}
else
{
uint8_t x_13; 
x_13 = !lean_is_exclusive(x_1);
if (x_13 == 0)
{
lean_object* x_14; 
x_14 = lean_ctor_get(x_1, 1);
lean_dec(x_14);
lean_ctor_set_tag(x_1, 0);
lean_ctor_set(x_1, 1, x_8);
return x_1;
}
else
{
lean_object* x_15; lean_object* x_16; 
x_15 = lean_ctor_get(x_1, 0);
lean_inc(x_15);
lean_dec(x_1);
x_16 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_16, 0, x_15);
lean_ctor_set(x_16, 1, x_8);
return x_16;
}
}
}
}
static lean_object* _init_l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__3), 8, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__2___closed__1;
x_2 = l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__1;
x_3 = lean_alloc_closure((void*)(l_ReaderT_bind___at_Lean_PrettyPrinter_Delaborator_delabMVar___spec__1___rarg), 9, 2);
lean_closure_set(x_3, 0, x_1);
lean_closure_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__2;
x_2 = lean_alloc_closure((void*)(l_Lean_PrettyPrinter_Delaborator_withAnnotateTermLikeInfo___rarg), 8, 1);
lean_closure_set(x_2, 0, x_1);
return x_2;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__5___boxed), 8, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__5() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_Jsx_delabJsxChildren), 7, 0);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
if (lean_obj_tag(x_1) == 9)
{
lean_object* x_11; 
x_11 = lean_ctor_get(x_1, 0);
lean_inc(x_11);
lean_dec(x_1);
if (lean_obj_tag(x_11) == 0)
{
lean_object* x_12; 
lean_dec(x_11);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
x_12 = l_Lean_PrettyPrinter_Delaborator_failure___rarg(x_10);
return x_12;
}
else
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; 
x_13 = lean_ctor_get(x_11, 0);
lean_inc(x_13);
lean_dec(x_11);
x_14 = lean_box(0);
x_15 = l_Lean_Name_str___override(x_14, x_13);
x_16 = lean_mk_syntax_ident(x_15);
x_17 = lean_alloc_closure((void*)(l_Lean_PrettyPrinter_Delaborator_annotateTermLikeInfo___rarg___boxed), 8, 1);
lean_closure_set(x_17, 0, x_16);
x_18 = lean_unsigned_to_nat(0u);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
x_19 = l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__1(x_18, x_17, x_4, x_5, x_6, x_7, x_8, x_9, x_10);
if (lean_obj_tag(x_19) == 0)
{
lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; 
x_20 = lean_ctor_get(x_19, 0);
lean_inc(x_20);
x_21 = lean_ctor_get(x_19, 1);
lean_inc(x_21);
lean_dec(x_19);
x_22 = l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__3;
x_23 = lean_alloc_closure((void*)(l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__4), 8, 1);
lean_closure_set(x_23, 0, x_22);
x_24 = l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__4;
x_25 = lean_alloc_closure((void*)(l_ReaderT_bind___at_Lean_PrettyPrinter_Delaborator_delabMVar___spec__1___rarg), 9, 2);
lean_closure_set(x_25, 0, x_23);
lean_closure_set(x_25, 1, x_24);
x_26 = lean_unsigned_to_nat(1u);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
x_27 = l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__3(x_26, x_25, x_4, x_5, x_6, x_7, x_8, x_9, x_21);
if (lean_obj_tag(x_27) == 0)
{
lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; 
x_28 = lean_ctor_get(x_27, 0);
lean_inc(x_28);
x_29 = lean_ctor_get(x_27, 1);
lean_inc(x_29);
lean_dec(x_27);
x_30 = l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__5;
lean_inc(x_8);
x_31 = l_Lean_PrettyPrinter_Delaborator_SubExpr_withAppArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__4(x_30, x_4, x_5, x_6, x_7, x_8, x_9, x_29);
if (lean_obj_tag(x_31) == 0)
{
uint8_t x_32; 
x_32 = !lean_is_exclusive(x_31);
if (x_32 == 0)
{
lean_object* x_33; uint8_t x_34; 
x_33 = lean_ctor_get(x_31, 0);
x_34 = l_Array_isEmpty___rarg(x_33);
if (x_34 == 0)
{
lean_object* x_35; uint8_t x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; size_t x_40; size_t x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; size_t x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; 
x_35 = lean_ctor_get(x_8, 5);
lean_inc(x_35);
lean_dec(x_8);
x_36 = 0;
x_37 = l_Lean_SourceInfo_fromRef(x_35, x_36);
lean_dec(x_35);
x_38 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__3;
lean_inc(x_37);
x_39 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_39, 0, x_37);
lean_ctor_set(x_39, 1, x_38);
x_40 = lean_array_size(x_28);
x_41 = 0;
x_42 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__6(x_40, x_41, x_28);
x_43 = l_ProofWidgets_instInhabitedHtml___closed__1;
x_44 = l_Array_append___rarg(x_43, x_42);
lean_dec(x_42);
x_45 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_37);
x_46 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_46, 0, x_37);
lean_ctor_set(x_46, 1, x_45);
lean_ctor_set(x_46, 2, x_44);
x_47 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__3;
lean_inc(x_37);
x_48 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_48, 0, x_37);
lean_ctor_set(x_48, 1, x_47);
x_49 = lean_array_size(x_33);
x_50 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__7(x_49, x_41, x_33);
x_51 = l_Array_append___rarg(x_43, x_50);
lean_dec(x_50);
lean_inc(x_37);
x_52 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_52, 0, x_37);
lean_ctor_set(x_52, 1, x_45);
lean_ctor_set(x_52, 2, x_51);
x_53 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__8;
lean_inc(x_37);
x_54 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_54, 0, x_37);
lean_ctor_set(x_54, 1, x_53);
x_55 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__2;
lean_inc(x_48);
lean_inc(x_20);
x_56 = l_Lean_Syntax_node8(x_37, x_55, x_39, x_20, x_46, x_48, x_52, x_54, x_20, x_48);
lean_ctor_set(x_31, 0, x_56);
return x_31;
}
else
{
lean_object* x_57; uint8_t x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; size_t x_62; size_t x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; lean_object* x_72; 
lean_dec(x_33);
x_57 = lean_ctor_get(x_8, 5);
lean_inc(x_57);
lean_dec(x_8);
x_58 = 0;
x_59 = l_Lean_SourceInfo_fromRef(x_57, x_58);
lean_dec(x_57);
x_60 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__3;
lean_inc(x_59);
x_61 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_61, 0, x_59);
lean_ctor_set(x_61, 1, x_60);
x_62 = lean_array_size(x_28);
x_63 = 0;
x_64 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__6(x_62, x_63, x_28);
x_65 = l_ProofWidgets_instInhabitedHtml___closed__1;
x_66 = l_Array_append___rarg(x_65, x_64);
lean_dec(x_64);
x_67 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_59);
x_68 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_68, 0, x_59);
lean_ctor_set(x_68, 1, x_67);
lean_ctor_set(x_68, 2, x_66);
x_69 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__10;
lean_inc(x_59);
x_70 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_70, 0, x_59);
lean_ctor_set(x_70, 1, x_69);
x_71 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__2;
x_72 = l_Lean_Syntax_node4(x_59, x_71, x_61, x_20, x_68, x_70);
lean_ctor_set(x_31, 0, x_72);
return x_31;
}
}
else
{
lean_object* x_73; lean_object* x_74; uint8_t x_75; 
x_73 = lean_ctor_get(x_31, 0);
x_74 = lean_ctor_get(x_31, 1);
lean_inc(x_74);
lean_inc(x_73);
lean_dec(x_31);
x_75 = l_Array_isEmpty___rarg(x_73);
if (x_75 == 0)
{
lean_object* x_76; uint8_t x_77; lean_object* x_78; lean_object* x_79; lean_object* x_80; size_t x_81; size_t x_82; lean_object* x_83; lean_object* x_84; lean_object* x_85; lean_object* x_86; lean_object* x_87; lean_object* x_88; lean_object* x_89; size_t x_90; lean_object* x_91; lean_object* x_92; lean_object* x_93; lean_object* x_94; lean_object* x_95; lean_object* x_96; lean_object* x_97; lean_object* x_98; 
x_76 = lean_ctor_get(x_8, 5);
lean_inc(x_76);
lean_dec(x_8);
x_77 = 0;
x_78 = l_Lean_SourceInfo_fromRef(x_76, x_77);
lean_dec(x_76);
x_79 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__3;
lean_inc(x_78);
x_80 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_80, 0, x_78);
lean_ctor_set(x_80, 1, x_79);
x_81 = lean_array_size(x_28);
x_82 = 0;
x_83 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__6(x_81, x_82, x_28);
x_84 = l_ProofWidgets_instInhabitedHtml___closed__1;
x_85 = l_Array_append___rarg(x_84, x_83);
lean_dec(x_83);
x_86 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_78);
x_87 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_87, 0, x_78);
lean_ctor_set(x_87, 1, x_86);
lean_ctor_set(x_87, 2, x_85);
x_88 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__3;
lean_inc(x_78);
x_89 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_89, 0, x_78);
lean_ctor_set(x_89, 1, x_88);
x_90 = lean_array_size(x_73);
x_91 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__7(x_90, x_82, x_73);
x_92 = l_Array_append___rarg(x_84, x_91);
lean_dec(x_91);
lean_inc(x_78);
x_93 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_93, 0, x_78);
lean_ctor_set(x_93, 1, x_86);
lean_ctor_set(x_93, 2, x_92);
x_94 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__8;
lean_inc(x_78);
x_95 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_95, 0, x_78);
lean_ctor_set(x_95, 1, x_94);
x_96 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__2;
lean_inc(x_89);
lean_inc(x_20);
x_97 = l_Lean_Syntax_node8(x_78, x_96, x_80, x_20, x_87, x_89, x_93, x_95, x_20, x_89);
x_98 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_98, 0, x_97);
lean_ctor_set(x_98, 1, x_74);
return x_98;
}
else
{
lean_object* x_99; uint8_t x_100; lean_object* x_101; lean_object* x_102; lean_object* x_103; size_t x_104; size_t x_105; lean_object* x_106; lean_object* x_107; lean_object* x_108; lean_object* x_109; lean_object* x_110; lean_object* x_111; lean_object* x_112; lean_object* x_113; lean_object* x_114; lean_object* x_115; 
lean_dec(x_73);
x_99 = lean_ctor_get(x_8, 5);
lean_inc(x_99);
lean_dec(x_8);
x_100 = 0;
x_101 = l_Lean_SourceInfo_fromRef(x_99, x_100);
lean_dec(x_99);
x_102 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__3;
lean_inc(x_101);
x_103 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_103, 0, x_101);
lean_ctor_set(x_103, 1, x_102);
x_104 = lean_array_size(x_28);
x_105 = 0;
x_106 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__6(x_104, x_105, x_28);
x_107 = l_ProofWidgets_instInhabitedHtml___closed__1;
x_108 = l_Array_append___rarg(x_107, x_106);
lean_dec(x_106);
x_109 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_101);
x_110 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_110, 0, x_101);
lean_ctor_set(x_110, 1, x_109);
lean_ctor_set(x_110, 2, x_108);
x_111 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__10;
lean_inc(x_101);
x_112 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_112, 0, x_101);
lean_ctor_set(x_112, 1, x_111);
x_113 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__2;
x_114 = l_Lean_Syntax_node4(x_101, x_113, x_103, x_20, x_110, x_112);
x_115 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_115, 0, x_114);
lean_ctor_set(x_115, 1, x_74);
return x_115;
}
}
}
else
{
uint8_t x_116; 
lean_dec(x_28);
lean_dec(x_20);
lean_dec(x_8);
x_116 = !lean_is_exclusive(x_31);
if (x_116 == 0)
{
return x_31;
}
else
{
lean_object* x_117; lean_object* x_118; lean_object* x_119; 
x_117 = lean_ctor_get(x_31, 0);
x_118 = lean_ctor_get(x_31, 1);
lean_inc(x_118);
lean_inc(x_117);
lean_dec(x_31);
x_119 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_119, 0, x_117);
lean_ctor_set(x_119, 1, x_118);
return x_119;
}
}
}
else
{
uint8_t x_120; 
lean_dec(x_20);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
x_120 = !lean_is_exclusive(x_27);
if (x_120 == 0)
{
return x_27;
}
else
{
lean_object* x_121; lean_object* x_122; lean_object* x_123; 
x_121 = lean_ctor_get(x_27, 0);
x_122 = lean_ctor_get(x_27, 1);
lean_inc(x_122);
lean_inc(x_121);
lean_dec(x_27);
x_123 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_123, 0, x_121);
lean_ctor_set(x_123, 1, x_122);
return x_123;
}
}
}
else
{
uint8_t x_124; 
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
x_124 = !lean_is_exclusive(x_19);
if (x_124 == 0)
{
return x_19;
}
else
{
lean_object* x_125; lean_object* x_126; lean_object* x_127; 
x_125 = lean_ctor_get(x_19, 0);
x_126 = lean_ctor_get(x_19, 1);
lean_inc(x_126);
lean_inc(x_125);
lean_dec(x_19);
x_127 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_127, 0, x_125);
lean_ctor_set(x_127, 1, x_126);
return x_127;
}
}
}
}
else
{
lean_object* x_128; 
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_1);
x_128 = l_Lean_PrettyPrinter_Delaborator_failure___rarg(x_10);
return x_128;
}
}
}
static lean_object* _init_l_ProofWidgets_Jsx_delabHtmlElement_x27___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___boxed), 10, 0);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; uint8_t x_13; 
lean_inc(x_1);
x_8 = l_Lean_PrettyPrinter_Delaborator_SubExpr_getExpr___at_Lean_PrettyPrinter_Delaborator_getExprKind___spec__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
x_9 = lean_ctor_get(x_8, 0);
lean_inc(x_9);
x_10 = lean_ctor_get(x_8, 1);
lean_inc(x_10);
lean_dec(x_8);
x_11 = l_ProofWidgets_Jsx_delabHtmlElement_x27___closed__1;
x_12 = l_Lean_Expr_cleanupAnnotations(x_9);
x_13 = l_Lean_Expr_isApp(x_12);
if (x_13 == 0)
{
lean_object* x_14; 
lean_dec(x_12);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_14 = l_Lean_PrettyPrinter_Delaborator_failure___rarg(x_10);
return x_14;
}
else
{
lean_object* x_15; lean_object* x_16; uint8_t x_17; 
x_15 = l_Lean_Expr_appArg(x_12, lean_box(0));
x_16 = l_Lean_Expr_appFnCleanup(x_12, lean_box(0));
x_17 = l_Lean_Expr_isApp(x_16);
if (x_17 == 0)
{
lean_object* x_18; 
lean_dec(x_16);
lean_dec(x_15);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_18 = l_Lean_PrettyPrinter_Delaborator_failure___rarg(x_10);
return x_18;
}
else
{
lean_object* x_19; lean_object* x_20; uint8_t x_21; 
x_19 = l_Lean_Expr_appArg(x_16, lean_box(0));
x_20 = l_Lean_Expr_appFnCleanup(x_16, lean_box(0));
x_21 = l_Lean_Expr_isApp(x_20);
if (x_21 == 0)
{
lean_object* x_22; 
lean_dec(x_20);
lean_dec(x_19);
lean_dec(x_15);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_22 = l_Lean_PrettyPrinter_Delaborator_failure___rarg(x_10);
return x_22;
}
else
{
lean_object* x_23; lean_object* x_24; lean_object* x_25; uint8_t x_26; 
x_23 = l_Lean_Expr_appArg(x_20, lean_box(0));
x_24 = l_Lean_Expr_appFnCleanup(x_20, lean_box(0));
x_25 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__4;
x_26 = l_Lean_Expr_isConstOf(x_24, x_25);
lean_dec(x_24);
if (x_26 == 0)
{
lean_object* x_27; 
lean_dec(x_23);
lean_dec(x_19);
lean_dec(x_15);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_27 = l_Lean_PrettyPrinter_Delaborator_failure___rarg(x_10);
return x_27;
}
else
{
lean_object* x_28; 
x_28 = lean_apply_10(x_11, x_23, x_19, x_15, x_1, x_2, x_3, x_4, x_5, x_6, x_10);
return x_28;
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabJsxChildren___lambda__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
lean_inc(x_6);
x_9 = l_ProofWidgets_Jsx_delabHtmlOfComponent_x27(x_2, x_3, x_4, x_5, x_6, x_7, x_8);
if (lean_obj_tag(x_9) == 0)
{
uint8_t x_10; 
x_10 = !lean_is_exclusive(x_9);
if (x_10 == 0)
{
lean_object* x_11; lean_object* x_12; uint8_t x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_11 = lean_ctor_get(x_9, 0);
x_12 = lean_ctor_get(x_6, 5);
lean_inc(x_12);
lean_dec(x_6);
x_13 = 0;
x_14 = l_Lean_SourceInfo_fromRef(x_12, x_13);
lean_dec(x_12);
x_15 = l_ProofWidgets_Jsx_jsxChild____1___closed__2;
x_16 = l_Lean_Syntax_node1(x_14, x_15, x_11);
x_17 = lean_box(0);
x_18 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_18, 0, x_16);
lean_ctor_set(x_18, 1, x_17);
lean_ctor_set(x_9, 0, x_18);
return x_9;
}
else
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; uint8_t x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; 
x_19 = lean_ctor_get(x_9, 0);
x_20 = lean_ctor_get(x_9, 1);
lean_inc(x_20);
lean_inc(x_19);
lean_dec(x_9);
x_21 = lean_ctor_get(x_6, 5);
lean_inc(x_21);
lean_dec(x_6);
x_22 = 0;
x_23 = l_Lean_SourceInfo_fromRef(x_21, x_22);
lean_dec(x_21);
x_24 = l_ProofWidgets_Jsx_jsxChild____1___closed__2;
x_25 = l_Lean_Syntax_node1(x_23, x_24, x_19);
x_26 = lean_box(0);
x_27 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_27, 0, x_25);
lean_ctor_set(x_27, 1, x_26);
x_28 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_28, 0, x_27);
lean_ctor_set(x_28, 1, x_20);
return x_28;
}
}
else
{
uint8_t x_29; 
lean_dec(x_6);
x_29 = !lean_is_exclusive(x_9);
if (x_29 == 0)
{
return x_9;
}
else
{
lean_object* x_30; lean_object* x_31; lean_object* x_32; 
x_30 = lean_ctor_get(x_9, 0);
x_31 = lean_ctor_get(x_9, 1);
lean_inc(x_31);
lean_inc(x_30);
lean_dec(x_9);
x_32 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_32, 0, x_30);
lean_ctor_set(x_32, 1, x_31);
return x_32;
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabJsxChildren___lambda__2(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
lean_inc(x_6);
x_9 = l_ProofWidgets_Jsx_delabHtmlElement_x27(x_2, x_3, x_4, x_5, x_6, x_7, x_8);
if (lean_obj_tag(x_9) == 0)
{
uint8_t x_10; 
x_10 = !lean_is_exclusive(x_9);
if (x_10 == 0)
{
lean_object* x_11; lean_object* x_12; uint8_t x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_11 = lean_ctor_get(x_9, 0);
x_12 = lean_ctor_get(x_6, 5);
lean_inc(x_12);
lean_dec(x_6);
x_13 = 0;
x_14 = l_Lean_SourceInfo_fromRef(x_12, x_13);
lean_dec(x_12);
x_15 = l_ProofWidgets_Jsx_jsxChild____1___closed__2;
x_16 = l_Lean_Syntax_node1(x_14, x_15, x_11);
x_17 = lean_box(0);
x_18 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_18, 0, x_16);
lean_ctor_set(x_18, 1, x_17);
lean_ctor_set(x_9, 0, x_18);
return x_9;
}
else
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; uint8_t x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; 
x_19 = lean_ctor_get(x_9, 0);
x_20 = lean_ctor_get(x_9, 1);
lean_inc(x_20);
lean_inc(x_19);
lean_dec(x_9);
x_21 = lean_ctor_get(x_6, 5);
lean_inc(x_21);
lean_dec(x_6);
x_22 = 0;
x_23 = l_Lean_SourceInfo_fromRef(x_21, x_22);
lean_dec(x_21);
x_24 = l_ProofWidgets_Jsx_jsxChild____1___closed__2;
x_25 = l_Lean_Syntax_node1(x_23, x_24, x_19);
x_26 = lean_box(0);
x_27 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_27, 0, x_25);
lean_ctor_set(x_27, 1, x_26);
x_28 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_28, 0, x_27);
lean_ctor_set(x_28, 1, x_20);
return x_28;
}
}
else
{
uint8_t x_29; 
lean_dec(x_6);
x_29 = !lean_is_exclusive(x_9);
if (x_29 == 0)
{
return x_9;
}
else
{
lean_object* x_30; lean_object* x_31; lean_object* x_32; 
x_30 = lean_ctor_get(x_9, 0);
x_31 = lean_ctor_get(x_9, 1);
lean_inc(x_31);
lean_inc(x_30);
lean_dec(x_9);
x_32 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_32, 0, x_30);
lean_ctor_set(x_32, 1, x_31);
return x_32;
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabJsxChildren___lambda__3(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
lean_inc(x_6);
x_9 = l_ProofWidgets_Jsx_delabHtmlText(x_2, x_3, x_4, x_5, x_6, x_7, x_8);
if (lean_obj_tag(x_9) == 0)
{
uint8_t x_10; 
x_10 = !lean_is_exclusive(x_9);
if (x_10 == 0)
{
lean_object* x_11; lean_object* x_12; uint8_t x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_11 = lean_ctor_get(x_9, 0);
x_12 = lean_ctor_get(x_6, 5);
lean_inc(x_12);
lean_dec(x_6);
x_13 = 0;
x_14 = l_Lean_SourceInfo_fromRef(x_12, x_13);
lean_dec(x_12);
x_15 = l_ProofWidgets_Jsx_jsxChild_____closed__2;
x_16 = l_Lean_Syntax_node1(x_14, x_15, x_11);
x_17 = lean_box(0);
x_18 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_18, 0, x_16);
lean_ctor_set(x_18, 1, x_17);
lean_ctor_set(x_9, 0, x_18);
return x_9;
}
else
{
lean_object* x_19; lean_object* x_20; lean_object* x_21; uint8_t x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; 
x_19 = lean_ctor_get(x_9, 0);
x_20 = lean_ctor_get(x_9, 1);
lean_inc(x_20);
lean_inc(x_19);
lean_dec(x_9);
x_21 = lean_ctor_get(x_6, 5);
lean_inc(x_21);
lean_dec(x_6);
x_22 = 0;
x_23 = l_Lean_SourceInfo_fromRef(x_21, x_22);
lean_dec(x_21);
x_24 = l_ProofWidgets_Jsx_jsxChild_____closed__2;
x_25 = l_Lean_Syntax_node1(x_23, x_24, x_19);
x_26 = lean_box(0);
x_27 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_27, 0, x_25);
lean_ctor_set(x_27, 1, x_26);
x_28 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_28, 0, x_27);
lean_ctor_set(x_28, 1, x_20);
return x_28;
}
}
else
{
uint8_t x_29; 
lean_dec(x_6);
x_29 = !lean_is_exclusive(x_9);
if (x_29 == 0)
{
return x_9;
}
else
{
lean_object* x_30; lean_object* x_31; lean_object* x_32; 
x_30 = lean_ctor_get(x_9, 0);
x_31 = lean_ctor_get(x_9, 1);
lean_inc(x_31);
lean_inc(x_30);
lean_dec(x_9);
x_32 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_32, 0, x_30);
lean_ctor_set(x_32, 1, x_31);
return x_32;
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabJsxChildren___lambda__4(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; uint8_t x_10; 
x_9 = l_Lean_PrettyPrinter_Delaborator_failure___rarg(x_8);
x_10 = !lean_is_exclusive(x_9);
if (x_10 == 0)
{
return x_9;
}
else
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; 
x_11 = lean_ctor_get(x_9, 0);
x_12 = lean_ctor_get(x_9, 1);
lean_inc(x_12);
lean_inc(x_11);
lean_dec(x_9);
x_13 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_13, 0, x_11);
lean_ctor_set(x_13, 1, x_12);
return x_13;
}
}
}
static lean_object* _init_l_ProofWidgets_Jsx_delabJsxChildren___lambda__5___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_Jsx_delabJsxChildren___lambda__1___boxed), 8, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_delabJsxChildren___lambda__5___closed__2() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_Jsx_delabJsxChildren___lambda__2___boxed), 8, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_delabJsxChildren___lambda__5___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_Jsx_delabJsxChildren___lambda__3___boxed), 8, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_delabJsxChildren___lambda__5___closed__4() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_Jsx_delabJsxChildren___lambda__4___boxed), 8, 0);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabJsxChildren___lambda__5(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; lean_object* x_9; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; lean_object* x_55; lean_object* x_56; lean_object* x_57; uint8_t x_58; 
lean_inc(x_1);
x_47 = l_Lean_PrettyPrinter_Delaborator_SubExpr_getExpr___at_Lean_PrettyPrinter_Delaborator_getExprKind___spec__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
x_48 = lean_ctor_get(x_47, 0);
lean_inc(x_48);
x_49 = lean_ctor_get(x_47, 1);
lean_inc(x_49);
lean_dec(x_47);
x_50 = l_Lean_Meta_instantiateMVarsIfMVarApp(x_48, x_3, x_4, x_5, x_6, x_49);
x_51 = lean_ctor_get(x_50, 0);
lean_inc(x_51);
x_52 = lean_ctor_get(x_50, 1);
lean_inc(x_52);
lean_dec(x_50);
x_53 = l_ProofWidgets_Jsx_delabJsxChildren___lambda__5___closed__1;
x_54 = l_ProofWidgets_Jsx_delabJsxChildren___lambda__5___closed__2;
x_55 = l_ProofWidgets_Jsx_delabJsxChildren___lambda__5___closed__3;
x_56 = l_ProofWidgets_Jsx_delabJsxChildren___lambda__5___closed__4;
x_57 = l_Lean_Expr_cleanupAnnotations(x_51);
x_58 = l_Lean_Expr_isApp(x_57);
if (x_58 == 0)
{
lean_object* x_59; lean_object* x_60; 
lean_dec(x_57);
x_59 = lean_box(0);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
lean_inc(x_3);
lean_inc(x_2);
lean_inc(x_1);
x_60 = lean_apply_8(x_56, x_59, x_1, x_2, x_3, x_4, x_5, x_6, x_52);
if (lean_obj_tag(x_60) == 0)
{
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_60;
}
else
{
lean_object* x_61; lean_object* x_62; 
x_61 = lean_ctor_get(x_60, 0);
lean_inc(x_61);
x_62 = lean_ctor_get(x_60, 1);
lean_inc(x_62);
lean_dec(x_60);
x_8 = x_61;
x_9 = x_62;
goto block_46;
}
}
else
{
lean_object* x_63; lean_object* x_64; uint8_t x_65; 
x_63 = l_Lean_Expr_appFnCleanup(x_57, lean_box(0));
x_64 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__15;
x_65 = l_Lean_Expr_isConstOf(x_63, x_64);
if (x_65 == 0)
{
uint8_t x_66; 
x_66 = l_Lean_Expr_isApp(x_63);
if (x_66 == 0)
{
lean_object* x_67; lean_object* x_68; 
lean_dec(x_63);
x_67 = lean_box(0);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
lean_inc(x_3);
lean_inc(x_2);
lean_inc(x_1);
x_68 = lean_apply_8(x_56, x_67, x_1, x_2, x_3, x_4, x_5, x_6, x_52);
if (lean_obj_tag(x_68) == 0)
{
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_68;
}
else
{
lean_object* x_69; lean_object* x_70; 
x_69 = lean_ctor_get(x_68, 0);
lean_inc(x_69);
x_70 = lean_ctor_get(x_68, 1);
lean_inc(x_70);
lean_dec(x_68);
x_8 = x_69;
x_9 = x_70;
goto block_46;
}
}
else
{
lean_object* x_71; uint8_t x_72; 
x_71 = l_Lean_Expr_appFnCleanup(x_63, lean_box(0));
x_72 = l_Lean_Expr_isApp(x_71);
if (x_72 == 0)
{
lean_object* x_73; lean_object* x_74; 
lean_dec(x_71);
x_73 = lean_box(0);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
lean_inc(x_3);
lean_inc(x_2);
lean_inc(x_1);
x_74 = lean_apply_8(x_56, x_73, x_1, x_2, x_3, x_4, x_5, x_6, x_52);
if (lean_obj_tag(x_74) == 0)
{
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_74;
}
else
{
lean_object* x_75; lean_object* x_76; 
x_75 = lean_ctor_get(x_74, 0);
lean_inc(x_75);
x_76 = lean_ctor_get(x_74, 1);
lean_inc(x_76);
lean_dec(x_74);
x_8 = x_75;
x_9 = x_76;
goto block_46;
}
}
else
{
lean_object* x_77; lean_object* x_78; uint8_t x_79; 
x_77 = l_Lean_Expr_appFnCleanup(x_71, lean_box(0));
x_78 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__4;
x_79 = l_Lean_Expr_isConstOf(x_77, x_78);
if (x_79 == 0)
{
uint8_t x_80; 
x_80 = l_Lean_Expr_isApp(x_77);
if (x_80 == 0)
{
lean_object* x_81; lean_object* x_82; 
lean_dec(x_77);
x_81 = lean_box(0);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
lean_inc(x_3);
lean_inc(x_2);
lean_inc(x_1);
x_82 = lean_apply_8(x_56, x_81, x_1, x_2, x_3, x_4, x_5, x_6, x_52);
if (lean_obj_tag(x_82) == 0)
{
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_82;
}
else
{
lean_object* x_83; lean_object* x_84; 
x_83 = lean_ctor_get(x_82, 0);
lean_inc(x_83);
x_84 = lean_ctor_get(x_82, 1);
lean_inc(x_84);
lean_dec(x_82);
x_8 = x_83;
x_9 = x_84;
goto block_46;
}
}
else
{
lean_object* x_85; uint8_t x_86; 
x_85 = l_Lean_Expr_appFnCleanup(x_77, lean_box(0));
x_86 = l_Lean_Expr_isApp(x_85);
if (x_86 == 0)
{
lean_object* x_87; lean_object* x_88; 
lean_dec(x_85);
x_87 = lean_box(0);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
lean_inc(x_3);
lean_inc(x_2);
lean_inc(x_1);
x_88 = lean_apply_8(x_56, x_87, x_1, x_2, x_3, x_4, x_5, x_6, x_52);
if (lean_obj_tag(x_88) == 0)
{
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_88;
}
else
{
lean_object* x_89; lean_object* x_90; 
x_89 = lean_ctor_get(x_88, 0);
lean_inc(x_89);
x_90 = lean_ctor_get(x_88, 1);
lean_inc(x_90);
lean_dec(x_88);
x_8 = x_89;
x_9 = x_90;
goto block_46;
}
}
else
{
lean_object* x_91; lean_object* x_92; uint8_t x_93; 
x_91 = l_Lean_Expr_appFnCleanup(x_85, lean_box(0));
x_92 = l_ProofWidgets_Jsx_transformTag___lambda__2___closed__5;
x_93 = l_Lean_Expr_isConstOf(x_91, x_92);
lean_dec(x_91);
if (x_93 == 0)
{
lean_object* x_94; lean_object* x_95; 
x_94 = lean_box(0);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
lean_inc(x_3);
lean_inc(x_2);
lean_inc(x_1);
x_95 = lean_apply_8(x_56, x_94, x_1, x_2, x_3, x_4, x_5, x_6, x_52);
if (lean_obj_tag(x_95) == 0)
{
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_95;
}
else
{
lean_object* x_96; lean_object* x_97; 
x_96 = lean_ctor_get(x_95, 0);
lean_inc(x_96);
x_97 = lean_ctor_get(x_95, 1);
lean_inc(x_97);
lean_dec(x_95);
x_8 = x_96;
x_9 = x_97;
goto block_46;
}
}
else
{
lean_object* x_98; lean_object* x_99; 
x_98 = lean_box(0);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
lean_inc(x_3);
lean_inc(x_2);
lean_inc(x_1);
x_99 = lean_apply_8(x_53, x_98, x_1, x_2, x_3, x_4, x_5, x_6, x_52);
if (lean_obj_tag(x_99) == 0)
{
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_99;
}
else
{
lean_object* x_100; lean_object* x_101; 
x_100 = lean_ctor_get(x_99, 0);
lean_inc(x_100);
x_101 = lean_ctor_get(x_99, 1);
lean_inc(x_101);
lean_dec(x_99);
x_8 = x_100;
x_9 = x_101;
goto block_46;
}
}
}
}
}
else
{
lean_object* x_102; lean_object* x_103; 
lean_dec(x_77);
x_102 = lean_box(0);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
lean_inc(x_3);
lean_inc(x_2);
lean_inc(x_1);
x_103 = lean_apply_8(x_54, x_102, x_1, x_2, x_3, x_4, x_5, x_6, x_52);
if (lean_obj_tag(x_103) == 0)
{
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_103;
}
else
{
lean_object* x_104; lean_object* x_105; 
x_104 = lean_ctor_get(x_103, 0);
lean_inc(x_104);
x_105 = lean_ctor_get(x_103, 1);
lean_inc(x_105);
lean_dec(x_103);
x_8 = x_104;
x_9 = x_105;
goto block_46;
}
}
}
}
}
else
{
lean_object* x_106; lean_object* x_107; 
lean_dec(x_63);
x_106 = lean_box(0);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
lean_inc(x_3);
lean_inc(x_2);
lean_inc(x_1);
x_107 = lean_apply_8(x_55, x_106, x_1, x_2, x_3, x_4, x_5, x_6, x_52);
if (lean_obj_tag(x_107) == 0)
{
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_107;
}
else
{
lean_object* x_108; lean_object* x_109; 
x_108 = lean_ctor_get(x_107, 0);
lean_inc(x_108);
x_109 = lean_ctor_get(x_107, 1);
lean_inc(x_109);
lean_dec(x_107);
x_8 = x_108;
x_9 = x_109;
goto block_46;
}
}
}
block_46:
{
uint8_t x_10; 
x_10 = l_Lean_Exception_isInterrupt(x_8);
if (x_10 == 0)
{
uint8_t x_11; 
x_11 = l_Lean_Exception_isRuntime(x_8);
if (x_11 == 0)
{
lean_object* x_12; 
lean_dec(x_8);
lean_inc(x_5);
x_12 = l_Lean_PrettyPrinter_Delaborator_delab(x_1, x_2, x_3, x_4, x_5, x_6, x_9);
if (lean_obj_tag(x_12) == 0)
{
uint8_t x_13; 
x_13 = !lean_is_exclusive(x_12);
if (x_13 == 0)
{
lean_object* x_14; lean_object* x_15; uint8_t x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; 
x_14 = lean_ctor_get(x_12, 0);
x_15 = lean_ctor_get(x_5, 5);
lean_inc(x_15);
lean_dec(x_5);
x_16 = 0;
x_17 = l_Lean_SourceInfo_fromRef(x_15, x_16);
lean_dec(x_15);
x_18 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_17);
x_19 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_19, 0, x_17);
lean_ctor_set(x_19, 1, x_18);
x_20 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_17);
x_21 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_21, 0, x_17);
lean_ctor_set(x_21, 1, x_20);
x_22 = l_ProofWidgets_Jsx_jsxChild_x7b___x7d___closed__2;
x_23 = l_Lean_Syntax_node3(x_17, x_22, x_19, x_14, x_21);
x_24 = lean_box(0);
x_25 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_25, 0, x_23);
lean_ctor_set(x_25, 1, x_24);
lean_ctor_set(x_12, 0, x_25);
return x_12;
}
else
{
lean_object* x_26; lean_object* x_27; lean_object* x_28; uint8_t x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; 
x_26 = lean_ctor_get(x_12, 0);
x_27 = lean_ctor_get(x_12, 1);
lean_inc(x_27);
lean_inc(x_26);
lean_dec(x_12);
x_28 = lean_ctor_get(x_5, 5);
lean_inc(x_28);
lean_dec(x_5);
x_29 = 0;
x_30 = l_Lean_SourceInfo_fromRef(x_28, x_29);
lean_dec(x_28);
x_31 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_30);
x_32 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_32, 0, x_30);
lean_ctor_set(x_32, 1, x_31);
x_33 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_30);
x_34 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_34, 0, x_30);
lean_ctor_set(x_34, 1, x_33);
x_35 = l_ProofWidgets_Jsx_jsxChild_x7b___x7d___closed__2;
x_36 = l_Lean_Syntax_node3(x_30, x_35, x_32, x_26, x_34);
x_37 = lean_box(0);
x_38 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_38, 0, x_36);
lean_ctor_set(x_38, 1, x_37);
x_39 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_39, 0, x_38);
lean_ctor_set(x_39, 1, x_27);
return x_39;
}
}
else
{
uint8_t x_40; 
lean_dec(x_5);
x_40 = !lean_is_exclusive(x_12);
if (x_40 == 0)
{
return x_12;
}
else
{
lean_object* x_41; lean_object* x_42; lean_object* x_43; 
x_41 = lean_ctor_get(x_12, 0);
x_42 = lean_ctor_get(x_12, 1);
lean_inc(x_42);
lean_inc(x_41);
lean_dec(x_12);
x_43 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_43, 0, x_41);
lean_ctor_set(x_43, 1, x_42);
return x_43;
}
}
}
else
{
lean_object* x_44; 
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_44 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_44, 0, x_8);
lean_ctor_set(x_44, 1, x_9);
return x_44;
}
}
else
{
lean_object* x_45; 
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_45 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_45, 0, x_8);
lean_ctor_set(x_45, 1, x_9);
return x_45;
}
}
}
}
static lean_object* _init_l_ProofWidgets_Jsx_delabJsxChildren___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_Jsx_delabJsxChildren___lambda__5), 7, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_delabJsxChildren___closed__2() {
_start:
{
lean_object* x_1; lean_object* x_2; lean_object* x_3; 
x_1 = l_ProofWidgets_Jsx_delabJsxChildren___closed__1;
x_2 = l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__4;
x_3 = lean_alloc_closure((void*)(l_ReaderT_bind___at_Lean_PrettyPrinter_Delaborator_delabMVar___spec__1___rarg), 9, 2);
lean_closure_set(x_3, 0, x_1);
lean_closure_set(x_3, 1, x_2);
return x_3;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_delabJsxChildren___closed__3() {
_start:
{
lean_object* x_1; lean_object* x_2; 
x_1 = l_ProofWidgets_Jsx_delabJsxChildren___closed__2;
x_2 = lean_alloc_closure((void*)(l_Lean_PrettyPrinter_Delaborator_withAnnotateTermLikeInfo___rarg), 8, 1);
lean_closure_set(x_2, 0, x_1);
return x_2;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabJsxChildren(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; lean_object* x_9; 
x_8 = l_ProofWidgets_Jsx_delabJsxChildren___closed__3;
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
lean_inc(x_3);
lean_inc(x_2);
lean_inc(x_1);
x_9 = l_Lean_PrettyPrinter_Delaborator_delabArrayLiteral___rarg(x_8, x_1, x_2, x_3, x_4, x_5, x_6, x_7);
if (lean_obj_tag(x_9) == 0)
{
uint8_t x_10; 
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_10 = !lean_is_exclusive(x_9);
if (x_10 == 0)
{
return x_9;
}
else
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; 
x_11 = lean_ctor_get(x_9, 0);
x_12 = lean_ctor_get(x_9, 1);
lean_inc(x_12);
lean_inc(x_11);
lean_dec(x_9);
x_13 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_13, 0, x_11);
lean_ctor_set(x_13, 1, x_12);
return x_13;
}
}
else
{
uint8_t x_14; 
x_14 = !lean_is_exclusive(x_9);
if (x_14 == 0)
{
lean_object* x_15; lean_object* x_16; uint8_t x_17; 
x_15 = lean_ctor_get(x_9, 0);
x_16 = lean_ctor_get(x_9, 1);
x_17 = l_Lean_Exception_isInterrupt(x_15);
if (x_17 == 0)
{
uint8_t x_18; 
x_18 = l_Lean_Exception_isRuntime(x_15);
if (x_18 == 0)
{
lean_object* x_19; 
lean_free_object(x_9);
lean_dec(x_15);
lean_inc(x_5);
x_19 = l_Lean_PrettyPrinter_Delaborator_delab(x_1, x_2, x_3, x_4, x_5, x_6, x_16);
if (lean_obj_tag(x_19) == 0)
{
uint8_t x_20; 
x_20 = !lean_is_exclusive(x_19);
if (x_20 == 0)
{
lean_object* x_21; lean_object* x_22; uint8_t x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; 
x_21 = lean_ctor_get(x_19, 0);
x_22 = lean_ctor_get(x_5, 5);
lean_inc(x_22);
lean_dec(x_5);
x_23 = 0;
x_24 = l_Lean_SourceInfo_fromRef(x_22, x_23);
lean_dec(x_22);
x_25 = l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__3;
lean_inc(x_24);
x_26 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_26, 0, x_24);
lean_ctor_set(x_26, 1, x_25);
x_27 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_24);
x_28 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_28, 0, x_24);
lean_ctor_set(x_28, 1, x_27);
x_29 = l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__2;
x_30 = l_Lean_Syntax_node3(x_24, x_29, x_26, x_21, x_28);
x_31 = l_ProofWidgets_Jsx_delabHtmlText___lambda__1___closed__1;
x_32 = lean_array_push(x_31, x_30);
lean_ctor_set(x_19, 0, x_32);
return x_19;
}
else
{
lean_object* x_33; lean_object* x_34; lean_object* x_35; uint8_t x_36; lean_object* x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; 
x_33 = lean_ctor_get(x_19, 0);
x_34 = lean_ctor_get(x_19, 1);
lean_inc(x_34);
lean_inc(x_33);
lean_dec(x_19);
x_35 = lean_ctor_get(x_5, 5);
lean_inc(x_35);
lean_dec(x_5);
x_36 = 0;
x_37 = l_Lean_SourceInfo_fromRef(x_35, x_36);
lean_dec(x_35);
x_38 = l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__3;
lean_inc(x_37);
x_39 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_39, 0, x_37);
lean_ctor_set(x_39, 1, x_38);
x_40 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_37);
x_41 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_41, 0, x_37);
lean_ctor_set(x_41, 1, x_40);
x_42 = l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__2;
x_43 = l_Lean_Syntax_node3(x_37, x_42, x_39, x_33, x_41);
x_44 = l_ProofWidgets_Jsx_delabHtmlText___lambda__1___closed__1;
x_45 = lean_array_push(x_44, x_43);
x_46 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_46, 0, x_45);
lean_ctor_set(x_46, 1, x_34);
return x_46;
}
}
else
{
uint8_t x_47; 
lean_dec(x_5);
x_47 = !lean_is_exclusive(x_19);
if (x_47 == 0)
{
return x_19;
}
else
{
lean_object* x_48; lean_object* x_49; lean_object* x_50; 
x_48 = lean_ctor_get(x_19, 0);
x_49 = lean_ctor_get(x_19, 1);
lean_inc(x_49);
lean_inc(x_48);
lean_dec(x_19);
x_50 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_50, 0, x_48);
lean_ctor_set(x_50, 1, x_49);
return x_50;
}
}
}
else
{
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_9;
}
}
else
{
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_9;
}
}
else
{
lean_object* x_51; lean_object* x_52; uint8_t x_53; 
x_51 = lean_ctor_get(x_9, 0);
x_52 = lean_ctor_get(x_9, 1);
lean_inc(x_52);
lean_inc(x_51);
lean_dec(x_9);
x_53 = l_Lean_Exception_isInterrupt(x_51);
if (x_53 == 0)
{
uint8_t x_54; 
x_54 = l_Lean_Exception_isRuntime(x_51);
if (x_54 == 0)
{
lean_object* x_55; 
lean_dec(x_51);
lean_inc(x_5);
x_55 = l_Lean_PrettyPrinter_Delaborator_delab(x_1, x_2, x_3, x_4, x_5, x_6, x_52);
if (lean_obj_tag(x_55) == 0)
{
lean_object* x_56; lean_object* x_57; lean_object* x_58; lean_object* x_59; uint8_t x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; lean_object* x_70; 
x_56 = lean_ctor_get(x_55, 0);
lean_inc(x_56);
x_57 = lean_ctor_get(x_55, 1);
lean_inc(x_57);
if (lean_is_exclusive(x_55)) {
 lean_ctor_release(x_55, 0);
 lean_ctor_release(x_55, 1);
 x_58 = x_55;
} else {
 lean_dec_ref(x_55);
 x_58 = lean_box(0);
}
x_59 = lean_ctor_get(x_5, 5);
lean_inc(x_59);
lean_dec(x_5);
x_60 = 0;
x_61 = l_Lean_SourceInfo_fromRef(x_59, x_60);
lean_dec(x_59);
x_62 = l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__3;
lean_inc(x_61);
x_63 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_63, 0, x_61);
lean_ctor_set(x_63, 1, x_62);
x_64 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_61);
x_65 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_65, 0, x_61);
lean_ctor_set(x_65, 1, x_64);
x_66 = l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__2;
x_67 = l_Lean_Syntax_node3(x_61, x_66, x_63, x_56, x_65);
x_68 = l_ProofWidgets_Jsx_delabHtmlText___lambda__1___closed__1;
x_69 = lean_array_push(x_68, x_67);
if (lean_is_scalar(x_58)) {
 x_70 = lean_alloc_ctor(0, 2, 0);
} else {
 x_70 = x_58;
}
lean_ctor_set(x_70, 0, x_69);
lean_ctor_set(x_70, 1, x_57);
return x_70;
}
else
{
lean_object* x_71; lean_object* x_72; lean_object* x_73; lean_object* x_74; 
lean_dec(x_5);
x_71 = lean_ctor_get(x_55, 0);
lean_inc(x_71);
x_72 = lean_ctor_get(x_55, 1);
lean_inc(x_72);
if (lean_is_exclusive(x_55)) {
 lean_ctor_release(x_55, 0);
 lean_ctor_release(x_55, 1);
 x_73 = x_55;
} else {
 lean_dec_ref(x_55);
 x_73 = lean_box(0);
}
if (lean_is_scalar(x_73)) {
 x_74 = lean_alloc_ctor(1, 2, 0);
} else {
 x_74 = x_73;
}
lean_ctor_set(x_74, 0, x_71);
lean_ctor_set(x_74, 1, x_72);
return x_74;
}
}
else
{
lean_object* x_75; 
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_75 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_75, 0, x_51);
lean_ctor_set(x_75, 1, x_52);
return x_75;
}
}
else
{
lean_object* x_76; 
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_76 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_76, 0, x_51);
lean_ctor_set(x_76, 1, x_52);
return x_76;
}
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; lean_object* x_16; lean_object* x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; uint8_t x_21; 
lean_inc(x_3);
x_10 = l_Lean_PrettyPrinter_Delaborator_SubExpr_getExpr___at_Lean_PrettyPrinter_Delaborator_getExprKind___spec__1(x_3, x_4, x_5, x_6, x_7, x_8, x_9);
x_11 = lean_ctor_get(x_10, 0);
lean_inc(x_11);
x_12 = lean_ctor_get(x_10, 1);
lean_inc(x_12);
lean_dec(x_10);
x_13 = lean_unsigned_to_nat(0u);
x_14 = l___private_Lean_Expr_0__Lean_Expr_getAppNumArgsAux(x_11, x_13);
x_15 = l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__1___closed__1;
lean_inc(x_14);
x_16 = lean_mk_array(x_14, x_15);
x_17 = lean_unsigned_to_nat(1u);
x_18 = lean_nat_sub(x_14, x_17);
lean_dec(x_14);
x_19 = l___private_Lean_Expr_0__Lean_Expr_getAppArgsAux(x_11, x_16, x_18);
x_20 = l_Lean_PrettyPrinter_Delaborator_SubExpr_getPos___at_Lean_PrettyPrinter_Delaborator_getOptionsAtCurrPos___spec__1(x_3, x_4, x_5, x_6, x_7, x_8, x_12);
x_21 = !lean_is_exclusive(x_20);
if (x_21 == 0)
{
lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; uint8_t x_26; 
x_22 = lean_ctor_get(x_20, 0);
x_23 = lean_ctor_get(x_20, 1);
x_24 = lean_array_get_size(x_19);
x_25 = l_Lean_SubExpr_Pos_pushNaryArg(x_24, x_1, x_22);
lean_dec(x_22);
x_26 = !lean_is_exclusive(x_3);
if (x_26 == 0)
{
lean_object* x_27; uint8_t x_28; 
x_27 = lean_ctor_get(x_3, 3);
lean_dec(x_27);
x_28 = lean_nat_dec_lt(x_1, x_24);
lean_dec(x_24);
if (x_28 == 0)
{
lean_object* x_29; lean_object* x_30; lean_object* x_31; 
lean_dec(x_19);
x_29 = l_Lean_instInhabitedExpr;
x_30 = l_outOfBounds___rarg(x_29);
lean_ctor_set(x_20, 1, x_25);
lean_ctor_set(x_20, 0, x_30);
lean_ctor_set(x_3, 3, x_20);
x_31 = lean_apply_7(x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_23);
return x_31;
}
else
{
lean_object* x_32; lean_object* x_33; 
x_32 = lean_array_fget(x_19, x_1);
lean_dec(x_19);
lean_ctor_set(x_20, 1, x_25);
lean_ctor_set(x_20, 0, x_32);
lean_ctor_set(x_3, 3, x_20);
x_33 = lean_apply_7(x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_23);
return x_33;
}
}
else
{
lean_object* x_34; lean_object* x_35; lean_object* x_36; uint8_t x_37; lean_object* x_38; uint8_t x_39; 
x_34 = lean_ctor_get(x_3, 0);
x_35 = lean_ctor_get(x_3, 1);
x_36 = lean_ctor_get(x_3, 2);
x_37 = lean_ctor_get_uint8(x_3, sizeof(void*)*5);
x_38 = lean_ctor_get(x_3, 4);
lean_inc(x_38);
lean_inc(x_36);
lean_inc(x_35);
lean_inc(x_34);
lean_dec(x_3);
x_39 = lean_nat_dec_lt(x_1, x_24);
lean_dec(x_24);
if (x_39 == 0)
{
lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; 
lean_dec(x_19);
x_40 = l_Lean_instInhabitedExpr;
x_41 = l_outOfBounds___rarg(x_40);
lean_ctor_set(x_20, 1, x_25);
lean_ctor_set(x_20, 0, x_41);
x_42 = lean_alloc_ctor(0, 5, 1);
lean_ctor_set(x_42, 0, x_34);
lean_ctor_set(x_42, 1, x_35);
lean_ctor_set(x_42, 2, x_36);
lean_ctor_set(x_42, 3, x_20);
lean_ctor_set(x_42, 4, x_38);
lean_ctor_set_uint8(x_42, sizeof(void*)*5, x_37);
x_43 = lean_apply_7(x_2, x_42, x_4, x_5, x_6, x_7, x_8, x_23);
return x_43;
}
else
{
lean_object* x_44; lean_object* x_45; lean_object* x_46; 
x_44 = lean_array_fget(x_19, x_1);
lean_dec(x_19);
lean_ctor_set(x_20, 1, x_25);
lean_ctor_set(x_20, 0, x_44);
x_45 = lean_alloc_ctor(0, 5, 1);
lean_ctor_set(x_45, 0, x_34);
lean_ctor_set(x_45, 1, x_35);
lean_ctor_set(x_45, 2, x_36);
lean_ctor_set(x_45, 3, x_20);
lean_ctor_set(x_45, 4, x_38);
lean_ctor_set_uint8(x_45, sizeof(void*)*5, x_37);
x_46 = lean_apply_7(x_2, x_45, x_4, x_5, x_6, x_7, x_8, x_23);
return x_46;
}
}
}
else
{
lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; uint8_t x_54; lean_object* x_55; lean_object* x_56; uint8_t x_57; 
x_47 = lean_ctor_get(x_20, 0);
x_48 = lean_ctor_get(x_20, 1);
lean_inc(x_48);
lean_inc(x_47);
lean_dec(x_20);
x_49 = lean_array_get_size(x_19);
x_50 = l_Lean_SubExpr_Pos_pushNaryArg(x_49, x_1, x_47);
lean_dec(x_47);
x_51 = lean_ctor_get(x_3, 0);
lean_inc(x_51);
x_52 = lean_ctor_get(x_3, 1);
lean_inc(x_52);
x_53 = lean_ctor_get(x_3, 2);
lean_inc(x_53);
x_54 = lean_ctor_get_uint8(x_3, sizeof(void*)*5);
x_55 = lean_ctor_get(x_3, 4);
lean_inc(x_55);
if (lean_is_exclusive(x_3)) {
 lean_ctor_release(x_3, 0);
 lean_ctor_release(x_3, 1);
 lean_ctor_release(x_3, 2);
 lean_ctor_release(x_3, 3);
 lean_ctor_release(x_3, 4);
 x_56 = x_3;
} else {
 lean_dec_ref(x_3);
 x_56 = lean_box(0);
}
x_57 = lean_nat_dec_lt(x_1, x_49);
lean_dec(x_49);
if (x_57 == 0)
{
lean_object* x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; 
lean_dec(x_19);
x_58 = l_Lean_instInhabitedExpr;
x_59 = l_outOfBounds___rarg(x_58);
x_60 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_60, 0, x_59);
lean_ctor_set(x_60, 1, x_50);
if (lean_is_scalar(x_56)) {
 x_61 = lean_alloc_ctor(0, 5, 1);
} else {
 x_61 = x_56;
}
lean_ctor_set(x_61, 0, x_51);
lean_ctor_set(x_61, 1, x_52);
lean_ctor_set(x_61, 2, x_53);
lean_ctor_set(x_61, 3, x_60);
lean_ctor_set(x_61, 4, x_55);
lean_ctor_set_uint8(x_61, sizeof(void*)*5, x_54);
x_62 = lean_apply_7(x_2, x_61, x_4, x_5, x_6, x_7, x_8, x_48);
return x_62;
}
else
{
lean_object* x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; 
x_63 = lean_array_fget(x_19, x_1);
lean_dec(x_19);
x_64 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_64, 0, x_63);
lean_ctor_set(x_64, 1, x_50);
if (lean_is_scalar(x_56)) {
 x_65 = lean_alloc_ctor(0, 5, 1);
} else {
 x_65 = x_56;
}
lean_ctor_set(x_65, 0, x_51);
lean_ctor_set(x_65, 1, x_52);
lean_ctor_set(x_65, 2, x_53);
lean_ctor_set(x_65, 3, x_64);
lean_ctor_set(x_65, 4, x_55);
lean_ctor_set_uint8(x_65, sizeof(void*)*5, x_54);
x_66 = lean_apply_7(x_2, x_65, x_4, x_5, x_6, x_7, x_8, x_48);
return x_66;
}
}
}
}
LEAN_EXPORT lean_object* l_Array_sequenceMap_loop___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__3(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; uint8_t x_7; 
x_6 = lean_array_get_size(x_1);
x_7 = lean_nat_dec_lt(x_4, x_6);
lean_dec(x_6);
if (x_7 == 0)
{
lean_object* x_8; 
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_8 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_8, 0, x_5);
return x_8;
}
else
{
lean_object* x_9; uint8_t x_10; 
x_9 = lean_unsigned_to_nat(0u);
x_10 = lean_nat_dec_eq(x_3, x_9);
if (x_10 == 0)
{
lean_object* x_11; lean_object* x_12; lean_object* x_13; lean_object* x_14; 
x_11 = lean_unsigned_to_nat(1u);
x_12 = lean_nat_sub(x_3, x_11);
lean_dec(x_3);
x_13 = lean_array_fget(x_1, x_4);
lean_inc(x_2);
x_14 = lean_apply_1(x_2, x_13);
if (lean_obj_tag(x_14) == 0)
{
lean_object* x_15; 
lean_dec(x_12);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_2);
x_15 = lean_box(0);
return x_15;
}
else
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; 
x_16 = lean_ctor_get(x_14, 0);
lean_inc(x_16);
lean_dec(x_14);
x_17 = lean_nat_add(x_4, x_11);
lean_dec(x_4);
x_18 = lean_array_push(x_5, x_16);
x_3 = x_12;
x_4 = x_17;
x_5 = x_18;
goto _start;
}
}
else
{
lean_object* x_20; 
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
x_20 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_20, 0, x_5);
return x_20;
}
}
}
}
LEAN_EXPORT lean_object* l_Array_sequenceMap___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__2(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; lean_object* x_4; lean_object* x_5; lean_object* x_6; 
x_3 = lean_array_get_size(x_1);
x_4 = lean_mk_empty_array_with_capacity(x_3);
x_5 = lean_unsigned_to_nat(0u);
x_6 = l_Array_sequenceMap_loop___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__3(x_1, x_2, x_3, x_5, x_4);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__4(size_t x_1, size_t x_2, lean_object* x_3) {
_start:
{
uint8_t x_4; 
x_4 = lean_usize_dec_lt(x_2, x_1);
if (x_4 == 0)
{
return x_3;
}
else
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; size_t x_8; size_t x_9; lean_object* x_10; lean_object* x_11; 
x_5 = lean_array_uget(x_3, x_2);
x_6 = lean_unsigned_to_nat(0u);
x_7 = lean_array_uset(x_3, x_2, x_6);
x_8 = 1;
x_9 = lean_usize_add(x_2, x_8);
x_10 = lean_ctor_get(x_5, 1);
lean_inc(x_10);
lean_dec(x_5);
x_11 = lean_array_uset(x_7, x_2, x_10);
x_2 = x_9;
x_3 = x_11;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__5(size_t x_1, size_t x_2, lean_object* x_3) {
_start:
{
uint8_t x_4; 
x_4 = lean_usize_dec_lt(x_2, x_1);
if (x_4 == 0)
{
return x_3;
}
else
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; size_t x_8; size_t x_9; lean_object* x_10; lean_object* x_11; 
x_5 = lean_array_uget(x_3, x_2);
x_6 = lean_unsigned_to_nat(0u);
x_7 = lean_array_uset(x_3, x_2, x_6);
x_8 = 1;
x_9 = lean_usize_add(x_2, x_8);
x_10 = lean_ctor_get(x_5, 0);
lean_inc(x_10);
lean_dec(x_5);
x_11 = lean_array_uset(x_7, x_2, x_10);
x_2 = x_9;
x_3 = x_11;
goto _start;
}
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__6(lean_object* x_1, size_t x_2, size_t x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11) {
_start:
{
uint8_t x_12; 
x_12 = lean_usize_dec_lt(x_3, x_2);
if (x_12 == 0)
{
lean_object* x_13; 
x_13 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_13, 0, x_4);
lean_ctor_set(x_13, 1, x_11);
return x_13;
}
else
{
lean_object* x_14; lean_object* x_15; lean_object* x_16; uint8_t x_17; 
x_14 = lean_array_uget(x_4, x_3);
x_15 = lean_unsigned_to_nat(0u);
x_16 = lean_array_uset(x_4, x_3, x_15);
x_17 = !lean_is_exclusive(x_14);
if (x_17 == 0)
{
lean_object* x_18; lean_object* x_19; lean_object* x_20; uint8_t x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; size_t x_34; size_t x_35; lean_object* x_36; 
x_18 = lean_ctor_get(x_14, 0);
x_19 = lean_ctor_get(x_14, 1);
x_20 = lean_ctor_get(x_9, 5);
x_21 = 0;
x_22 = l_Lean_SourceInfo_fromRef(x_20, x_21);
x_23 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
lean_inc(x_22);
lean_ctor_set_tag(x_14, 2);
lean_ctor_set(x_14, 1, x_23);
lean_ctor_set(x_14, 0, x_22);
x_24 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_22);
x_25 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_25, 0, x_22);
lean_ctor_set(x_25, 1, x_24);
x_26 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_22);
x_27 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_27, 0, x_22);
lean_ctor_set(x_27, 1, x_26);
x_28 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_22);
x_29 = l_Lean_Syntax_node3(x_22, x_28, x_25, x_19, x_27);
x_30 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2;
lean_inc(x_22);
x_31 = l_Lean_Syntax_node1(x_22, x_30, x_29);
x_32 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
x_33 = l_Lean_Syntax_node3(x_22, x_32, x_18, x_14, x_31);
x_34 = 1;
x_35 = lean_usize_add(x_3, x_34);
x_36 = lean_array_uset(x_16, x_3, x_33);
x_3 = x_35;
x_4 = x_36;
goto _start;
}
else
{
lean_object* x_38; lean_object* x_39; lean_object* x_40; uint8_t x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; lean_object* x_54; size_t x_55; size_t x_56; lean_object* x_57; 
x_38 = lean_ctor_get(x_14, 0);
x_39 = lean_ctor_get(x_14, 1);
lean_inc(x_39);
lean_inc(x_38);
lean_dec(x_14);
x_40 = lean_ctor_get(x_9, 5);
x_41 = 0;
x_42 = l_Lean_SourceInfo_fromRef(x_40, x_41);
x_43 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6;
lean_inc(x_42);
x_44 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_44, 0, x_42);
lean_ctor_set(x_44, 1, x_43);
x_45 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5;
lean_inc(x_42);
x_46 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_46, 0, x_42);
lean_ctor_set(x_46, 1, x_45);
x_47 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_42);
x_48 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_48, 0, x_42);
lean_ctor_set(x_48, 1, x_47);
x_49 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_42);
x_50 = l_Lean_Syntax_node3(x_42, x_49, x_46, x_39, x_48);
x_51 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2;
lean_inc(x_42);
x_52 = l_Lean_Syntax_node1(x_42, x_51, x_50);
x_53 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2;
x_54 = l_Lean_Syntax_node3(x_42, x_53, x_38, x_44, x_52);
x_55 = 1;
x_56 = lean_usize_add(x_3, x_55);
x_57 = lean_array_uset(x_16, x_3, x_54);
x_3 = x_56;
x_4 = x_57;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__1(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; 
x_10 = lean_unsigned_to_nat(4u);
x_11 = l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__5;
lean_inc(x_7);
x_12 = l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__1(x_10, x_11, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
if (lean_obj_tag(x_12) == 0)
{
uint8_t x_13; 
x_13 = !lean_is_exclusive(x_12);
if (x_13 == 0)
{
lean_object* x_14; uint8_t x_15; 
x_14 = lean_ctor_get(x_12, 0);
x_15 = l_Array_isEmpty___rarg(x_14);
if (x_15 == 0)
{
lean_object* x_16; uint8_t x_17; lean_object* x_18; lean_object* x_19; lean_object* x_20; size_t x_21; size_t x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; size_t x_30; lean_object* x_31; lean_object* x_32; lean_object* x_33; lean_object* x_34; lean_object* x_35; lean_object* x_36; lean_object* x_37; 
x_16 = lean_ctor_get(x_7, 5);
lean_inc(x_16);
lean_dec(x_7);
x_17 = 0;
x_18 = l_Lean_SourceInfo_fromRef(x_16, x_17);
lean_dec(x_16);
x_19 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__3;
lean_inc(x_18);
x_20 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_20, 0, x_18);
lean_ctor_set(x_20, 1, x_19);
x_21 = lean_array_size(x_2);
x_22 = 0;
x_23 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__6(x_21, x_22, x_2);
x_24 = l_ProofWidgets_instInhabitedHtml___closed__1;
x_25 = l_Array_append___rarg(x_24, x_23);
lean_dec(x_23);
x_26 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_18);
x_27 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_27, 0, x_18);
lean_ctor_set(x_27, 1, x_26);
lean_ctor_set(x_27, 2, x_25);
x_28 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__3;
lean_inc(x_18);
x_29 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_29, 0, x_18);
lean_ctor_set(x_29, 1, x_28);
x_30 = lean_array_size(x_14);
x_31 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__7(x_30, x_22, x_14);
x_32 = l_Array_append___rarg(x_24, x_31);
lean_dec(x_31);
lean_inc(x_18);
x_33 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_33, 0, x_18);
lean_ctor_set(x_33, 1, x_26);
lean_ctor_set(x_33, 2, x_32);
x_34 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__8;
lean_inc(x_18);
x_35 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_35, 0, x_18);
lean_ctor_set(x_35, 1, x_34);
x_36 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__2;
lean_inc(x_29);
lean_inc(x_1);
x_37 = l_Lean_Syntax_node8(x_18, x_36, x_20, x_1, x_27, x_29, x_33, x_35, x_1, x_29);
lean_ctor_set(x_12, 0, x_37);
return x_12;
}
else
{
lean_object* x_38; uint8_t x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; size_t x_43; size_t x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; 
lean_dec(x_14);
x_38 = lean_ctor_get(x_7, 5);
lean_inc(x_38);
lean_dec(x_7);
x_39 = 0;
x_40 = l_Lean_SourceInfo_fromRef(x_38, x_39);
lean_dec(x_38);
x_41 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__3;
lean_inc(x_40);
x_42 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_42, 0, x_40);
lean_ctor_set(x_42, 1, x_41);
x_43 = lean_array_size(x_2);
x_44 = 0;
x_45 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__6(x_43, x_44, x_2);
x_46 = l_ProofWidgets_instInhabitedHtml___closed__1;
x_47 = l_Array_append___rarg(x_46, x_45);
lean_dec(x_45);
x_48 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_40);
x_49 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_49, 0, x_40);
lean_ctor_set(x_49, 1, x_48);
lean_ctor_set(x_49, 2, x_47);
x_50 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__10;
lean_inc(x_40);
x_51 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_51, 0, x_40);
lean_ctor_set(x_51, 1, x_50);
x_52 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__2;
x_53 = l_Lean_Syntax_node4(x_40, x_52, x_42, x_1, x_49, x_51);
lean_ctor_set(x_12, 0, x_53);
return x_12;
}
}
else
{
lean_object* x_54; lean_object* x_55; uint8_t x_56; 
x_54 = lean_ctor_get(x_12, 0);
x_55 = lean_ctor_get(x_12, 1);
lean_inc(x_55);
lean_inc(x_54);
lean_dec(x_12);
x_56 = l_Array_isEmpty___rarg(x_54);
if (x_56 == 0)
{
lean_object* x_57; uint8_t x_58; lean_object* x_59; lean_object* x_60; lean_object* x_61; size_t x_62; size_t x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; lean_object* x_70; size_t x_71; lean_object* x_72; lean_object* x_73; lean_object* x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; lean_object* x_79; 
x_57 = lean_ctor_get(x_7, 5);
lean_inc(x_57);
lean_dec(x_7);
x_58 = 0;
x_59 = l_Lean_SourceInfo_fromRef(x_57, x_58);
lean_dec(x_57);
x_60 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__3;
lean_inc(x_59);
x_61 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_61, 0, x_59);
lean_ctor_set(x_61, 1, x_60);
x_62 = lean_array_size(x_2);
x_63 = 0;
x_64 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__6(x_62, x_63, x_2);
x_65 = l_ProofWidgets_instInhabitedHtml___closed__1;
x_66 = l_Array_append___rarg(x_65, x_64);
lean_dec(x_64);
x_67 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_59);
x_68 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_68, 0, x_59);
lean_ctor_set(x_68, 1, x_67);
lean_ctor_set(x_68, 2, x_66);
x_69 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__3;
lean_inc(x_59);
x_70 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_70, 0, x_59);
lean_ctor_set(x_70, 1, x_69);
x_71 = lean_array_size(x_54);
x_72 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__7(x_71, x_63, x_54);
x_73 = l_Array_append___rarg(x_65, x_72);
lean_dec(x_72);
lean_inc(x_59);
x_74 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_74, 0, x_59);
lean_ctor_set(x_74, 1, x_67);
lean_ctor_set(x_74, 2, x_73);
x_75 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__8;
lean_inc(x_59);
x_76 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_76, 0, x_59);
lean_ctor_set(x_76, 1, x_75);
x_77 = l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__2;
lean_inc(x_70);
lean_inc(x_1);
x_78 = l_Lean_Syntax_node8(x_59, x_77, x_61, x_1, x_68, x_70, x_74, x_76, x_1, x_70);
x_79 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_79, 0, x_78);
lean_ctor_set(x_79, 1, x_55);
return x_79;
}
else
{
lean_object* x_80; uint8_t x_81; lean_object* x_82; lean_object* x_83; lean_object* x_84; size_t x_85; size_t x_86; lean_object* x_87; lean_object* x_88; lean_object* x_89; lean_object* x_90; lean_object* x_91; lean_object* x_92; lean_object* x_93; lean_object* x_94; lean_object* x_95; lean_object* x_96; 
lean_dec(x_54);
x_80 = lean_ctor_get(x_7, 5);
lean_inc(x_80);
lean_dec(x_7);
x_81 = 0;
x_82 = l_Lean_SourceInfo_fromRef(x_80, x_81);
lean_dec(x_80);
x_83 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__3;
lean_inc(x_82);
x_84 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_84, 0, x_82);
lean_ctor_set(x_84, 1, x_83);
x_85 = lean_array_size(x_2);
x_86 = 0;
x_87 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__6(x_85, x_86, x_2);
x_88 = l_ProofWidgets_instInhabitedHtml___closed__1;
x_89 = l_Array_append___rarg(x_88, x_87);
lean_dec(x_87);
x_90 = l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6;
lean_inc(x_82);
x_91 = lean_alloc_ctor(1, 3, 0);
lean_ctor_set(x_91, 0, x_82);
lean_ctor_set(x_91, 1, x_90);
lean_ctor_set(x_91, 2, x_89);
x_92 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__10;
lean_inc(x_82);
x_93 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_93, 0, x_82);
lean_ctor_set(x_93, 1, x_92);
x_94 = l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__2;
x_95 = l_Lean_Syntax_node4(x_82, x_94, x_84, x_1, x_91, x_93);
x_96 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_96, 0, x_95);
lean_ctor_set(x_96, 1, x_55);
return x_96;
}
}
}
else
{
uint8_t x_97; 
lean_dec(x_7);
lean_dec(x_2);
lean_dec(x_1);
x_97 = !lean_is_exclusive(x_12);
if (x_97 == 0)
{
return x_12;
}
else
{
lean_object* x_98; lean_object* x_99; lean_object* x_100; 
x_98 = lean_ctor_get(x_12, 0);
x_99 = lean_ctor_get(x_12, 1);
lean_inc(x_99);
lean_inc(x_98);
lean_dec(x_12);
x_100 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_100, 0, x_98);
lean_ctor_set(x_100, 1, x_99);
return x_100;
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__2(lean_object* x_1) {
_start:
{
lean_object* x_2; uint8_t x_3; 
x_2 = l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__2;
lean_inc(x_1);
x_3 = l_Lean_Syntax_isOfKind(x_1, x_2);
if (x_3 == 0)
{
lean_object* x_4; 
lean_dec(x_1);
x_4 = lean_box(0);
return x_4;
}
else
{
lean_object* x_5; lean_object* x_6; lean_object* x_7; uint8_t x_8; 
x_5 = lean_unsigned_to_nat(0u);
x_6 = l_Lean_Syntax_getArg(x_1, x_5);
x_7 = l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__4;
lean_inc(x_6);
x_8 = l_Lean_Syntax_isOfKind(x_6, x_7);
if (x_8 == 0)
{
lean_object* x_9; 
lean_dec(x_6);
lean_dec(x_1);
x_9 = lean_box(0);
return x_9;
}
else
{
lean_object* x_10; lean_object* x_11; uint8_t x_12; 
x_10 = l_Lean_Syntax_getArg(x_6, x_5);
x_11 = l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__4;
lean_inc(x_10);
x_12 = l_Lean_Syntax_isOfKind(x_10, x_11);
if (x_12 == 0)
{
lean_object* x_13; 
lean_dec(x_10);
lean_dec(x_6);
lean_dec(x_1);
x_13 = lean_box(0);
return x_13;
}
else
{
lean_object* x_14; lean_object* x_15; uint8_t x_16; 
x_14 = lean_unsigned_to_nat(1u);
x_15 = l_Lean_Syntax_getArg(x_6, x_14);
lean_dec(x_6);
x_16 = l_Lean_Syntax_matchesNull(x_15, x_5);
if (x_16 == 0)
{
lean_object* x_17; 
lean_dec(x_10);
lean_dec(x_1);
x_17 = lean_box(0);
return x_17;
}
else
{
lean_object* x_18; lean_object* x_19; lean_object* x_20; lean_object* x_21; 
x_18 = lean_unsigned_to_nat(2u);
x_19 = l_Lean_Syntax_getArg(x_1, x_18);
lean_dec(x_1);
x_20 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_20, 0, x_10);
lean_ctor_set(x_20, 1, x_19);
x_21 = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(x_21, 0, x_20);
return x_21;
}
}
}
}
}
}
static lean_object* _init_l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__3___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_Lean_PrettyPrinter_Delaborator_delab), 7, 0);
return x_1;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__3___closed__2() {
_start:
{
uint8_t x_1; lean_object* x_2; lean_object* x_3; lean_object* x_4; 
x_1 = 1;
x_2 = l_ProofWidgets_instInhabitedHtml___closed__1;
x_3 = lean_box(x_1);
x_4 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_4, 0, x_3);
lean_ctor_set(x_4, 1, x_2);
return x_4;
}
}
static lean_object* _init_l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__3___closed__3() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__2), 1, 0);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__3(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; lean_object* x_11; lean_object* x_12; lean_object* x_13; 
x_10 = lean_box(0);
x_11 = lean_unsigned_to_nat(3u);
x_12 = l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__3___closed__1;
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
lean_inc(x_5);
lean_inc(x_4);
lean_inc(x_3);
x_13 = l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_Lean_PrettyPrinter_Delaborator_delabLetFun___spec__5(x_11, x_12, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
if (lean_obj_tag(x_13) == 0)
{
lean_object* x_14; lean_object* x_15; lean_object* x_16; uint8_t x_17; 
x_14 = lean_ctor_get(x_13, 0);
lean_inc(x_14);
x_15 = lean_ctor_get(x_13, 1);
lean_inc(x_15);
lean_dec(x_13);
x_16 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__10;
lean_inc(x_14);
x_17 = l_Lean_Syntax_isOfKind(x_14, x_16);
if (x_17 == 0)
{
lean_object* x_18; uint8_t x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; lean_object* x_24; lean_object* x_25; lean_object* x_26; lean_object* x_27; lean_object* x_28; lean_object* x_29; lean_object* x_30; lean_object* x_31; 
x_18 = lean_ctor_get(x_7, 5);
lean_inc(x_18);
x_19 = 0;
x_20 = l_Lean_SourceInfo_fromRef(x_18, x_19);
lean_dec(x_18);
x_21 = l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__3;
lean_inc(x_20);
x_22 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_22, 0, x_20);
lean_ctor_set(x_22, 1, x_21);
x_23 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_20);
x_24 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_24, 0, x_20);
lean_ctor_set(x_24, 1, x_23);
x_25 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_20);
x_26 = l_Lean_Syntax_node3(x_20, x_25, x_22, x_14, x_24);
x_27 = l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__2;
x_28 = l_Lean_Syntax_node1(x_20, x_27, x_26);
x_29 = l_ProofWidgets_Jsx_delabHtmlText___lambda__1___closed__1;
x_30 = lean_array_push(x_29, x_28);
x_31 = l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__1(x_1, x_30, x_3, x_4, x_5, x_6, x_7, x_8, x_15);
return x_31;
}
else
{
lean_object* x_32; lean_object* x_33; lean_object* x_34; uint8_t x_35; 
x_32 = lean_unsigned_to_nat(1u);
x_33 = l_Lean_Syntax_getArg(x_14, x_32);
x_34 = lean_unsigned_to_nat(0u);
x_35 = l_Lean_Syntax_matchesNull(x_33, x_34);
if (x_35 == 0)
{
lean_object* x_36; uint8_t x_37; lean_object* x_38; lean_object* x_39; lean_object* x_40; lean_object* x_41; lean_object* x_42; lean_object* x_43; lean_object* x_44; lean_object* x_45; lean_object* x_46; lean_object* x_47; lean_object* x_48; lean_object* x_49; 
x_36 = lean_ctor_get(x_7, 5);
lean_inc(x_36);
x_37 = 0;
x_38 = l_Lean_SourceInfo_fromRef(x_36, x_37);
lean_dec(x_36);
x_39 = l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__3;
lean_inc(x_38);
x_40 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_40, 0, x_38);
lean_ctor_set(x_40, 1, x_39);
x_41 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_38);
x_42 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_42, 0, x_38);
lean_ctor_set(x_42, 1, x_41);
x_43 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_38);
x_44 = l_Lean_Syntax_node3(x_38, x_43, x_40, x_14, x_42);
x_45 = l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__2;
x_46 = l_Lean_Syntax_node1(x_38, x_45, x_44);
x_47 = l_ProofWidgets_Jsx_delabHtmlText___lambda__1___closed__1;
x_48 = lean_array_push(x_47, x_46);
x_49 = l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__1(x_1, x_48, x_3, x_4, x_5, x_6, x_7, x_8, x_15);
return x_49;
}
else
{
lean_object* x_50; lean_object* x_51; lean_object* x_52; lean_object* x_53; uint8_t x_54; lean_object* x_55; 
x_50 = lean_unsigned_to_nat(2u);
x_51 = l_Lean_Syntax_getArg(x_14, x_50);
x_52 = l_Lean_Syntax_getArgs(x_51);
lean_dec(x_51);
x_53 = lean_array_get_size(x_52);
x_54 = lean_nat_dec_lt(x_34, x_53);
if (x_54 == 0)
{
lean_object* x_134; 
lean_dec(x_53);
lean_dec(x_52);
x_134 = l_ProofWidgets_instInhabitedHtml___closed__1;
x_55 = x_134;
goto block_133;
}
else
{
uint8_t x_135; 
x_135 = lean_nat_dec_le(x_53, x_53);
if (x_135 == 0)
{
lean_object* x_136; 
lean_dec(x_53);
lean_dec(x_52);
x_136 = l_ProofWidgets_instInhabitedHtml___closed__1;
x_55 = x_136;
goto block_133;
}
else
{
size_t x_137; size_t x_138; lean_object* x_139; lean_object* x_140; lean_object* x_141; 
x_137 = 0;
x_138 = lean_usize_of_nat(x_53);
lean_dec(x_53);
x_139 = l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__3___closed__2;
x_140 = l_Array_foldlMUnsafe_fold___at_Lean_Syntax_SepArray_getElems___spec__1(x_52, x_137, x_138, x_139);
lean_dec(x_52);
x_141 = lean_ctor_get(x_140, 1);
lean_inc(x_141);
lean_dec(x_140);
x_55 = x_141;
goto block_133;
}
}
block_133:
{
lean_object* x_56; lean_object* x_57; 
x_56 = l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__3___closed__3;
x_57 = l_Array_sequenceMap___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__2(x_55, x_56);
lean_dec(x_55);
if (lean_obj_tag(x_57) == 0)
{
lean_object* x_58; uint8_t x_59; lean_object* x_60; lean_object* x_61; lean_object* x_62; lean_object* x_63; lean_object* x_64; lean_object* x_65; lean_object* x_66; lean_object* x_67; lean_object* x_68; lean_object* x_69; lean_object* x_70; lean_object* x_71; 
x_58 = lean_ctor_get(x_7, 5);
lean_inc(x_58);
x_59 = 0;
x_60 = l_Lean_SourceInfo_fromRef(x_58, x_59);
lean_dec(x_58);
x_61 = l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__3;
lean_inc(x_60);
x_62 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_62, 0, x_60);
lean_ctor_set(x_62, 1, x_61);
x_63 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_60);
x_64 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_64, 0, x_60);
lean_ctor_set(x_64, 1, x_63);
x_65 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_60);
x_66 = l_Lean_Syntax_node3(x_60, x_65, x_62, x_14, x_64);
x_67 = l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__2;
x_68 = l_Lean_Syntax_node1(x_60, x_67, x_66);
x_69 = l_ProofWidgets_Jsx_delabHtmlText___lambda__1___closed__1;
x_70 = lean_array_push(x_69, x_68);
x_71 = l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__1(x_1, x_70, x_3, x_4, x_5, x_6, x_7, x_8, x_15);
return x_71;
}
else
{
lean_object* x_72; size_t x_73; size_t x_74; lean_object* x_75; lean_object* x_76; lean_object* x_77; lean_object* x_78; uint8_t x_79; 
x_72 = lean_ctor_get(x_57, 0);
lean_inc(x_72);
lean_dec(x_57);
x_73 = lean_array_size(x_72);
x_74 = 0;
lean_inc(x_72);
x_75 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__4(x_73, x_74, x_72);
x_76 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__5(x_73, x_74, x_72);
x_77 = l_Lean_Syntax_getArg(x_14, x_11);
x_78 = l_ProofWidgets_Jsx_transformTag___lambda__3___closed__13;
lean_inc(x_77);
x_79 = l_Lean_Syntax_isOfKind(x_77, x_78);
if (x_79 == 0)
{
lean_object* x_80; uint8_t x_81; lean_object* x_82; lean_object* x_83; lean_object* x_84; lean_object* x_85; lean_object* x_86; lean_object* x_87; lean_object* x_88; lean_object* x_89; lean_object* x_90; lean_object* x_91; lean_object* x_92; lean_object* x_93; 
lean_dec(x_77);
lean_dec(x_76);
lean_dec(x_75);
x_80 = lean_ctor_get(x_7, 5);
lean_inc(x_80);
x_81 = 0;
x_82 = l_Lean_SourceInfo_fromRef(x_80, x_81);
lean_dec(x_80);
x_83 = l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__3;
lean_inc(x_82);
x_84 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_84, 0, x_82);
lean_ctor_set(x_84, 1, x_83);
x_85 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_82);
x_86 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_86, 0, x_82);
lean_ctor_set(x_86, 1, x_85);
x_87 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_82);
x_88 = l_Lean_Syntax_node3(x_82, x_87, x_84, x_14, x_86);
x_89 = l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__2;
x_90 = l_Lean_Syntax_node1(x_82, x_89, x_88);
x_91 = l_ProofWidgets_Jsx_delabHtmlText___lambda__1___closed__1;
x_92 = lean_array_push(x_91, x_90);
x_93 = l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__1(x_1, x_92, x_3, x_4, x_5, x_6, x_7, x_8, x_15);
return x_93;
}
else
{
lean_object* x_94; uint8_t x_95; 
x_94 = l_Lean_Syntax_getArg(x_77, x_34);
lean_dec(x_77);
x_95 = l_Lean_Syntax_matchesNull(x_94, x_34);
if (x_95 == 0)
{
lean_object* x_96; uint8_t x_97; lean_object* x_98; lean_object* x_99; lean_object* x_100; lean_object* x_101; lean_object* x_102; lean_object* x_103; lean_object* x_104; lean_object* x_105; lean_object* x_106; lean_object* x_107; lean_object* x_108; lean_object* x_109; 
lean_dec(x_76);
lean_dec(x_75);
x_96 = lean_ctor_get(x_7, 5);
lean_inc(x_96);
x_97 = 0;
x_98 = l_Lean_SourceInfo_fromRef(x_96, x_97);
lean_dec(x_96);
x_99 = l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__3;
lean_inc(x_98);
x_100 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_100, 0, x_98);
lean_ctor_set(x_100, 1, x_99);
x_101 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_98);
x_102 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_102, 0, x_98);
lean_ctor_set(x_102, 1, x_101);
x_103 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_98);
x_104 = l_Lean_Syntax_node3(x_98, x_103, x_100, x_14, x_102);
x_105 = l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__2;
x_106 = l_Lean_Syntax_node1(x_98, x_105, x_104);
x_107 = l_ProofWidgets_Jsx_delabHtmlText___lambda__1___closed__1;
x_108 = lean_array_push(x_107, x_106);
x_109 = l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__1(x_1, x_108, x_3, x_4, x_5, x_6, x_7, x_8, x_15);
return x_109;
}
else
{
lean_object* x_110; lean_object* x_111; uint8_t x_112; 
x_110 = lean_unsigned_to_nat(4u);
x_111 = l_Lean_Syntax_getArg(x_14, x_110);
x_112 = l_Lean_Syntax_matchesNull(x_111, x_34);
if (x_112 == 0)
{
lean_object* x_113; uint8_t x_114; lean_object* x_115; lean_object* x_116; lean_object* x_117; lean_object* x_118; lean_object* x_119; lean_object* x_120; lean_object* x_121; lean_object* x_122; lean_object* x_123; lean_object* x_124; lean_object* x_125; lean_object* x_126; 
lean_dec(x_76);
lean_dec(x_75);
x_113 = lean_ctor_get(x_7, 5);
lean_inc(x_113);
x_114 = 0;
x_115 = l_Lean_SourceInfo_fromRef(x_113, x_114);
lean_dec(x_113);
x_116 = l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__3;
lean_inc(x_115);
x_117 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_117, 0, x_115);
lean_ctor_set(x_117, 1, x_116);
x_118 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11;
lean_inc(x_115);
x_119 = lean_alloc_ctor(2, 2, 0);
lean_ctor_set(x_119, 0, x_115);
lean_ctor_set(x_119, 1, x_118);
x_120 = l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4;
lean_inc(x_115);
x_121 = l_Lean_Syntax_node3(x_115, x_120, x_117, x_14, x_119);
x_122 = l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__2;
x_123 = l_Lean_Syntax_node1(x_115, x_122, x_121);
x_124 = l_ProofWidgets_Jsx_delabHtmlText___lambda__1___closed__1;
x_125 = lean_array_push(x_124, x_123);
x_126 = l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__1(x_1, x_125, x_3, x_4, x_5, x_6, x_7, x_8, x_15);
return x_126;
}
else
{
lean_object* x_127; size_t x_128; lean_object* x_129; lean_object* x_130; lean_object* x_131; lean_object* x_132; 
lean_dec(x_14);
x_127 = l_Array_zip___rarg(x_76, x_75);
lean_dec(x_75);
lean_dec(x_76);
x_128 = lean_array_size(x_127);
x_129 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__6(x_10, x_128, x_74, x_127, x_3, x_4, x_5, x_6, x_7, x_8, x_15);
x_130 = lean_ctor_get(x_129, 0);
lean_inc(x_130);
x_131 = lean_ctor_get(x_129, 1);
lean_inc(x_131);
lean_dec(x_129);
x_132 = l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__1(x_1, x_130, x_3, x_4, x_5, x_6, x_7, x_8, x_131);
return x_132;
}
}
}
}
}
}
}
}
else
{
uint8_t x_142; 
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_1);
x_142 = !lean_is_exclusive(x_13);
if (x_142 == 0)
{
return x_13;
}
else
{
lean_object* x_143; lean_object* x_144; lean_object* x_145; 
x_143 = lean_ctor_get(x_13, 0);
x_144 = lean_ctor_get(x_13, 1);
lean_inc(x_144);
lean_inc(x_143);
lean_dec(x_13);
x_145 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_145, 0, x_143);
lean_ctor_set(x_145, 1, x_144);
return x_145;
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__4(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12) {
_start:
{
lean_object* x_13; lean_object* x_14; lean_object* x_15; 
x_13 = lean_unsigned_to_nat(2u);
x_14 = l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__3___closed__1;
lean_inc(x_11);
lean_inc(x_10);
lean_inc(x_9);
lean_inc(x_8);
lean_inc(x_7);
lean_inc(x_6);
x_15 = l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_Lean_PrettyPrinter_Delaborator_delabLetFun___spec__5(x_13, x_14, x_6, x_7, x_8, x_9, x_10, x_11, x_12);
if (lean_obj_tag(x_15) == 0)
{
lean_object* x_16; lean_object* x_17; uint8_t x_18; 
x_16 = lean_ctor_get(x_15, 0);
lean_inc(x_16);
x_17 = lean_ctor_get(x_15, 1);
lean_inc(x_17);
lean_dec(x_15);
x_18 = l_Lean_Syntax_isIdent(x_16);
if (x_18 == 0)
{
lean_object* x_19; uint8_t x_20; 
lean_dec(x_16);
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
x_19 = l_Lean_PrettyPrinter_Delaborator_failure___rarg(x_17);
x_20 = !lean_is_exclusive(x_19);
if (x_20 == 0)
{
return x_19;
}
else
{
lean_object* x_21; lean_object* x_22; lean_object* x_23; 
x_21 = lean_ctor_get(x_19, 0);
x_22 = lean_ctor_get(x_19, 1);
lean_inc(x_22);
lean_inc(x_21);
lean_dec(x_19);
x_23 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_23, 0, x_21);
lean_ctor_set(x_23, 1, x_22);
return x_23;
}
}
else
{
lean_object* x_24; lean_object* x_25; 
x_24 = lean_box(0);
x_25 = l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__3(x_16, x_24, x_6, x_7, x_8, x_9, x_10, x_11, x_17);
return x_25;
}
}
else
{
uint8_t x_26; 
lean_dec(x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
x_26 = !lean_is_exclusive(x_15);
if (x_26 == 0)
{
return x_15;
}
else
{
lean_object* x_27; lean_object* x_28; lean_object* x_29; 
x_27 = lean_ctor_get(x_15, 0);
x_28 = lean_ctor_get(x_15, 1);
lean_inc(x_28);
lean_inc(x_27);
lean_dec(x_15);
x_29 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_29, 0, x_27);
lean_ctor_set(x_29, 1, x_28);
return x_29;
}
}
}
}
static lean_object* _init_l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___closed__1() {
_start:
{
lean_object* x_1; 
x_1 = lean_alloc_closure((void*)(l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__4___boxed), 12, 0);
return x_1;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlOfComponent_x27(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; lean_object* x_9; lean_object* x_10; lean_object* x_11; lean_object* x_12; uint8_t x_13; 
lean_inc(x_1);
x_8 = l_Lean_PrettyPrinter_Delaborator_SubExpr_getExpr___at_Lean_PrettyPrinter_Delaborator_getExprKind___spec__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
x_9 = lean_ctor_get(x_8, 0);
lean_inc(x_9);
x_10 = lean_ctor_get(x_8, 1);
lean_inc(x_10);
lean_dec(x_8);
x_11 = l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___closed__1;
x_12 = l_Lean_Expr_cleanupAnnotations(x_9);
x_13 = l_Lean_Expr_isApp(x_12);
if (x_13 == 0)
{
lean_object* x_14; 
lean_dec(x_12);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_14 = l_Lean_PrettyPrinter_Delaborator_failure___rarg(x_10);
return x_14;
}
else
{
lean_object* x_15; lean_object* x_16; uint8_t x_17; 
x_15 = l_Lean_Expr_appArg(x_12, lean_box(0));
x_16 = l_Lean_Expr_appFnCleanup(x_12, lean_box(0));
x_17 = l_Lean_Expr_isApp(x_16);
if (x_17 == 0)
{
lean_object* x_18; 
lean_dec(x_16);
lean_dec(x_15);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_18 = l_Lean_PrettyPrinter_Delaborator_failure___rarg(x_10);
return x_18;
}
else
{
lean_object* x_19; lean_object* x_20; uint8_t x_21; 
x_19 = l_Lean_Expr_appArg(x_16, lean_box(0));
x_20 = l_Lean_Expr_appFnCleanup(x_16, lean_box(0));
x_21 = l_Lean_Expr_isApp(x_20);
if (x_21 == 0)
{
lean_object* x_22; 
lean_dec(x_20);
lean_dec(x_19);
lean_dec(x_15);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_22 = l_Lean_PrettyPrinter_Delaborator_failure___rarg(x_10);
return x_22;
}
else
{
lean_object* x_23; lean_object* x_24; uint8_t x_25; 
x_23 = l_Lean_Expr_appArg(x_20, lean_box(0));
x_24 = l_Lean_Expr_appFnCleanup(x_20, lean_box(0));
x_25 = l_Lean_Expr_isApp(x_24);
if (x_25 == 0)
{
lean_object* x_26; 
lean_dec(x_24);
lean_dec(x_23);
lean_dec(x_19);
lean_dec(x_15);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_26 = l_Lean_PrettyPrinter_Delaborator_failure___rarg(x_10);
return x_26;
}
else
{
lean_object* x_27; lean_object* x_28; uint8_t x_29; 
x_27 = l_Lean_Expr_appArg(x_24, lean_box(0));
x_28 = l_Lean_Expr_appFnCleanup(x_24, lean_box(0));
x_29 = l_Lean_Expr_isApp(x_28);
if (x_29 == 0)
{
lean_object* x_30; 
lean_dec(x_28);
lean_dec(x_27);
lean_dec(x_23);
lean_dec(x_19);
lean_dec(x_15);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_30 = l_Lean_PrettyPrinter_Delaborator_failure___rarg(x_10);
return x_30;
}
else
{
lean_object* x_31; lean_object* x_32; lean_object* x_33; uint8_t x_34; 
x_31 = l_Lean_Expr_appArg(x_28, lean_box(0));
x_32 = l_Lean_Expr_appFnCleanup(x_28, lean_box(0));
x_33 = l_ProofWidgets_Jsx_transformTag___lambda__2___closed__5;
x_34 = l_Lean_Expr_isConstOf(x_32, x_33);
lean_dec(x_32);
if (x_34 == 0)
{
lean_object* x_35; 
lean_dec(x_31);
lean_dec(x_27);
lean_dec(x_23);
lean_dec(x_19);
lean_dec(x_15);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
x_35 = l_Lean_PrettyPrinter_Delaborator_failure___rarg(x_10);
return x_35;
}
else
{
lean_object* x_36; 
x_36 = lean_apply_12(x_11, x_31, x_27, x_23, x_19, x_15, x_1, x_2, x_3, x_4, x_5, x_6, x_10);
return x_36;
}
}
}
}
}
}
}
}
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_1);
return x_10;
}
}
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__2(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_1);
return x_10;
}
}
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__3___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__3(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_1);
return x_10;
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__6___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
size_t x_4; size_t x_5; lean_object* x_6; 
x_4 = lean_unbox_usize(x_1);
lean_dec(x_1);
x_5 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_6 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__6(x_4, x_5, x_3);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__7___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
size_t x_4; size_t x_5; lean_object* x_6; 
x_4 = lean_unbox_usize(x_1);
lean_dec(x_1);
x_5 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_6 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__7(x_4, x_5, x_3);
return x_6;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_2);
return x_10;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__5___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__5(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
return x_9;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10) {
_start:
{
lean_object* x_11; 
x_11 = l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10);
lean_dec(x_3);
lean_dec(x_2);
return x_11;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabJsxChildren___lambda__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l_ProofWidgets_Jsx_delabJsxChildren___lambda__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
lean_dec(x_1);
return x_9;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabJsxChildren___lambda__2___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l_ProofWidgets_Jsx_delabJsxChildren___lambda__2(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
lean_dec(x_1);
return x_9;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabJsxChildren___lambda__3___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l_ProofWidgets_Jsx_delabJsxChildren___lambda__3(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
lean_dec(x_1);
return x_9;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabJsxChildren___lambda__4___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8) {
_start:
{
lean_object* x_9; 
x_9 = l_ProofWidgets_Jsx_delabJsxChildren___lambda__4(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_9;
}
}
LEAN_EXPORT lean_object* l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__1___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__1(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_1);
return x_10;
}
}
LEAN_EXPORT lean_object* l_Array_sequenceMap_loop___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__3___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5) {
_start:
{
lean_object* x_6; 
x_6 = l_Array_sequenceMap_loop___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__3(x_1, x_2, x_3, x_4, x_5);
lean_dec(x_1);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Array_sequenceMap___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__2___boxed(lean_object* x_1, lean_object* x_2) {
_start:
{
lean_object* x_3; 
x_3 = l_Array_sequenceMap___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__2(x_1, x_2);
lean_dec(x_1);
return x_3;
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__4___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
size_t x_4; size_t x_5; lean_object* x_6; 
x_4 = lean_unbox_usize(x_1);
lean_dec(x_1);
x_5 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_6 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__4(x_4, x_5, x_3);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__5___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3) {
_start:
{
size_t x_4; size_t x_5; lean_object* x_6; 
x_4 = lean_unbox_usize(x_1);
lean_dec(x_1);
x_5 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_6 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__5(x_4, x_5, x_3);
return x_6;
}
}
LEAN_EXPORT lean_object* l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__6___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11) {
_start:
{
size_t x_12; size_t x_13; lean_object* x_14; 
x_12 = lean_unbox_usize(x_2);
lean_dec(x_2);
x_13 = lean_unbox_usize(x_3);
lean_dec(x_3);
x_14 = l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_delabHtmlOfComponent_x27___spec__6(x_1, x_12, x_13, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11);
lean_dec(x_10);
lean_dec(x_9);
lean_dec(x_8);
lean_dec(x_7);
lean_dec(x_6);
lean_dec(x_5);
lean_dec(x_1);
return x_14;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__3___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9) {
_start:
{
lean_object* x_10; 
x_10 = l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__3(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9);
lean_dec(x_2);
return x_10;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__4___boxed(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7, lean_object* x_8, lean_object* x_9, lean_object* x_10, lean_object* x_11, lean_object* x_12) {
_start:
{
lean_object* x_13; 
x_13 = l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__4(x_1, x_2, x_3, x_4, x_5, x_6, x_7, x_8, x_9, x_10, x_11, x_12);
lean_dec(x_5);
lean_dec(x_4);
lean_dec(x_3);
lean_dec(x_2);
lean_dec(x_1);
return x_13;
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlElement(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
lean_inc(x_5);
x_8 = l_ProofWidgets_Jsx_delabHtmlElement_x27(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
if (lean_obj_tag(x_8) == 0)
{
uint8_t x_9; 
x_9 = !lean_is_exclusive(x_8);
if (x_9 == 0)
{
lean_object* x_10; lean_object* x_11; uint8_t x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; 
x_10 = lean_ctor_get(x_8, 0);
x_11 = lean_ctor_get(x_5, 5);
lean_inc(x_11);
lean_dec(x_5);
x_12 = 0;
x_13 = l_Lean_SourceInfo_fromRef(x_11, x_12);
lean_dec(x_11);
x_14 = l_ProofWidgets_Jsx_term_____closed__2;
x_15 = l_Lean_Syntax_node1(x_13, x_14, x_10);
lean_ctor_set(x_8, 0, x_15);
return x_8;
}
else
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; uint8_t x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; 
x_16 = lean_ctor_get(x_8, 0);
x_17 = lean_ctor_get(x_8, 1);
lean_inc(x_17);
lean_inc(x_16);
lean_dec(x_8);
x_18 = lean_ctor_get(x_5, 5);
lean_inc(x_18);
lean_dec(x_5);
x_19 = 0;
x_20 = l_Lean_SourceInfo_fromRef(x_18, x_19);
lean_dec(x_18);
x_21 = l_ProofWidgets_Jsx_term_____closed__2;
x_22 = l_Lean_Syntax_node1(x_20, x_21, x_16);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_22);
lean_ctor_set(x_23, 1, x_17);
return x_23;
}
}
else
{
uint8_t x_24; 
lean_dec(x_5);
x_24 = !lean_is_exclusive(x_8);
if (x_24 == 0)
{
return x_8;
}
else
{
lean_object* x_25; lean_object* x_26; lean_object* x_27; 
x_25 = lean_ctor_get(x_8, 0);
x_26 = lean_ctor_get(x_8, 1);
lean_inc(x_26);
lean_inc(x_25);
lean_dec(x_8);
x_27 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_27, 0, x_25);
lean_ctor_set(x_27, 1, x_26);
return x_27;
}
}
}
}
LEAN_EXPORT lean_object* l_ProofWidgets_Jsx_delabHtmlOfComponent(lean_object* x_1, lean_object* x_2, lean_object* x_3, lean_object* x_4, lean_object* x_5, lean_object* x_6, lean_object* x_7) {
_start:
{
lean_object* x_8; 
lean_inc(x_5);
x_8 = l_ProofWidgets_Jsx_delabHtmlOfComponent_x27(x_1, x_2, x_3, x_4, x_5, x_6, x_7);
if (lean_obj_tag(x_8) == 0)
{
uint8_t x_9; 
x_9 = !lean_is_exclusive(x_8);
if (x_9 == 0)
{
lean_object* x_10; lean_object* x_11; uint8_t x_12; lean_object* x_13; lean_object* x_14; lean_object* x_15; 
x_10 = lean_ctor_get(x_8, 0);
x_11 = lean_ctor_get(x_5, 5);
lean_inc(x_11);
lean_dec(x_5);
x_12 = 0;
x_13 = l_Lean_SourceInfo_fromRef(x_11, x_12);
lean_dec(x_11);
x_14 = l_ProofWidgets_Jsx_term_____closed__2;
x_15 = l_Lean_Syntax_node1(x_13, x_14, x_10);
lean_ctor_set(x_8, 0, x_15);
return x_8;
}
else
{
lean_object* x_16; lean_object* x_17; lean_object* x_18; uint8_t x_19; lean_object* x_20; lean_object* x_21; lean_object* x_22; lean_object* x_23; 
x_16 = lean_ctor_get(x_8, 0);
x_17 = lean_ctor_get(x_8, 1);
lean_inc(x_17);
lean_inc(x_16);
lean_dec(x_8);
x_18 = lean_ctor_get(x_5, 5);
lean_inc(x_18);
lean_dec(x_5);
x_19 = 0;
x_20 = l_Lean_SourceInfo_fromRef(x_18, x_19);
lean_dec(x_18);
x_21 = l_ProofWidgets_Jsx_term_____closed__2;
x_22 = l_Lean_Syntax_node1(x_20, x_21, x_16);
x_23 = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(x_23, 0, x_22);
lean_ctor_set(x_23, 1, x_17);
return x_23;
}
}
else
{
uint8_t x_24; 
lean_dec(x_5);
x_24 = !lean_is_exclusive(x_8);
if (x_24 == 0)
{
return x_8;
}
else
{
lean_object* x_25; lean_object* x_26; lean_object* x_27; 
x_25 = lean_ctor_get(x_8, 0);
x_26 = lean_ctor_get(x_8, 1);
lean_inc(x_26);
lean_inc(x_25);
lean_dec(x_8);
x_27 = lean_alloc_ctor(1, 2, 0);
lean_ctor_set(x_27, 0, x_25);
lean_ctor_set(x_27, 1, x_26);
return x_27;
}
}
}
}
lean_object* initialize_Init(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_Data_Json_FromToJson(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_Parser(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_PrettyPrinter_Delaborator_Basic(uint8_t builtin, lean_object*);
lean_object* initialize_Lean_Server_Rpc_Basic(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Component_Basic(uint8_t builtin, lean_object*);
lean_object* initialize_ProofWidgets_Util(uint8_t builtin, lean_object*);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_ProofWidgets_Data_Html(uint8_t builtin, lean_object* w) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Data_Json_FromToJson(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Parser(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_PrettyPrinter_Delaborator_Basic(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Lean_Server_Rpc_Basic(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Component_Basic(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_ProofWidgets_Util(builtin, lean_io_mk_world());
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
l_ProofWidgets_instInhabitedHtml___closed__1 = _init_l_ProofWidgets_instInhabitedHtml___closed__1();
lean_mark_persistent(l_ProofWidgets_instInhabitedHtml___closed__1);
l_ProofWidgets_instInhabitedHtml___closed__2 = _init_l_ProofWidgets_instInhabitedHtml___closed__2();
lean_mark_persistent(l_ProofWidgets_instInhabitedHtml___closed__2);
l_ProofWidgets_instInhabitedHtml___closed__3 = _init_l_ProofWidgets_instInhabitedHtml___closed__3();
lean_mark_persistent(l_ProofWidgets_instInhabitedHtml___closed__3);
l_ProofWidgets_instInhabitedHtml = _init_l_ProofWidgets_instInhabitedHtml();
lean_mark_persistent(l_ProofWidgets_instInhabitedHtml);
l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__1___closed__1 = _init_l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__1___closed__1();
lean_mark_persistent(l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__1___closed__1);
l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__1___closed__2 = _init_l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__1___closed__2();
lean_mark_persistent(l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__1___closed__2);
l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2___closed__1 = _init_l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2___closed__1();
lean_mark_persistent(l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2___closed__1);
l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2___closed__2 = _init_l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2___closed__2();
lean_mark_persistent(l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__2___closed__2);
l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__3___closed__1 = _init_l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__3___closed__1();
lean_mark_persistent(l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____lambda__3___closed__1);
l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____closed__1 = _init_l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____closed__1();
lean_mark_persistent(l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_fromJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_189____closed__1);
l_ProofWidgets_ProofWidgets_Html_instFromJsonRpcEncodablePacket___closed__1 = _init_l_ProofWidgets_ProofWidgets_Html_instFromJsonRpcEncodablePacket___closed__1();
lean_mark_persistent(l_ProofWidgets_ProofWidgets_Html_instFromJsonRpcEncodablePacket___closed__1);
l_ProofWidgets_ProofWidgets_Html_instFromJsonRpcEncodablePacket = _init_l_ProofWidgets_ProofWidgets_Html_instFromJsonRpcEncodablePacket();
lean_mark_persistent(l_ProofWidgets_ProofWidgets_Html_instFromJsonRpcEncodablePacket);
l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_toJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_457____closed__1 = _init_l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_toJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_457____closed__1();
lean_mark_persistent(l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_toJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_457____closed__1);
l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_toJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_457____closed__2 = _init_l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_toJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_457____closed__2();
lean_mark_persistent(l___private_ProofWidgets_Data_Html_0__ProofWidgets_ProofWidgets_Html_toJsonRpcEncodablePacket____x40_ProofWidgets_Data_Html___hyg_457____closed__2);
l_ProofWidgets_ProofWidgets_Html_instToJsonRpcEncodablePacket___closed__1 = _init_l_ProofWidgets_ProofWidgets_Html_instToJsonRpcEncodablePacket___closed__1();
lean_mark_persistent(l_ProofWidgets_ProofWidgets_Html_instToJsonRpcEncodablePacket___closed__1);
l_ProofWidgets_ProofWidgets_Html_instToJsonRpcEncodablePacket = _init_l_ProofWidgets_ProofWidgets_Html_instToJsonRpcEncodablePacket();
lean_mark_persistent(l_ProofWidgets_ProofWidgets_Html_instToJsonRpcEncodablePacket);
l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__1 = _init_l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__1();
lean_mark_persistent(l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_enc____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__1);
l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__1 = _init_l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__1();
lean_mark_persistent(l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__1);
l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__2 = _init_l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__2();
lean_mark_persistent(l_Array_mapMUnsafe_map___at_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____spec__1___closed__2);
l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__1 = _init_l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__1();
lean_mark_persistent(l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__1);
l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__2 = _init_l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__2();
lean_mark_persistent(l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__2);
l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__3 = _init_l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__3();
lean_mark_persistent(l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__3);
l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__4 = _init_l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__4();
lean_mark_persistent(l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml_dec____x40_ProofWidgets_Data_Html___hyg_5____closed__4);
l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml___closed__1 = _init_l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml___closed__1();
lean_mark_persistent(l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml___closed__1);
l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml___closed__2 = _init_l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml___closed__2();
lean_mark_persistent(l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml___closed__2);
l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml___closed__3 = _init_l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml___closed__3();
lean_mark_persistent(l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml___closed__3);
l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml = _init_l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml();
lean_mark_persistent(l_ProofWidgets_ProofWidgets_Html_instRpcEncodableHtml);
l_ProofWidgets_LayoutKind_noConfusion___rarg___closed__1 = _init_l_ProofWidgets_LayoutKind_noConfusion___rarg___closed__1();
lean_mark_persistent(l_ProofWidgets_LayoutKind_noConfusion___rarg___closed__1);
l_ProofWidgets_Jsx_jsxElement_quot___closed__1 = _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_quot___closed__1);
l_ProofWidgets_Jsx_jsxElement_quot___closed__2 = _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__2();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_quot___closed__2);
l_ProofWidgets_Jsx_jsxElement_quot___closed__3 = _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__3();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_quot___closed__3);
l_ProofWidgets_Jsx_jsxElement_quot___closed__4 = _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__4();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_quot___closed__4);
l_ProofWidgets_Jsx_jsxElement_quot___closed__5 = _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__5();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_quot___closed__5);
l_ProofWidgets_Jsx_jsxElement_quot___closed__6 = _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__6();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_quot___closed__6);
l_ProofWidgets_Jsx_jsxElement_quot___closed__7 = _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__7();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_quot___closed__7);
l_ProofWidgets_Jsx_jsxElement_quot___closed__8 = _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__8();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_quot___closed__8);
l_ProofWidgets_Jsx_jsxElement_quot___closed__9 = _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__9();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_quot___closed__9);
l_ProofWidgets_Jsx_jsxElement_quot___closed__10 = _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__10();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_quot___closed__10);
l_ProofWidgets_Jsx_jsxElement_quot___closed__11 = _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__11();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_quot___closed__11);
l_ProofWidgets_Jsx_jsxElement_quot___closed__12 = _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__12();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_quot___closed__12);
l_ProofWidgets_Jsx_jsxElement_quot___closed__13 = _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__13();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_quot___closed__13);
l_ProofWidgets_Jsx_jsxElement_quot___closed__14 = _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__14();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_quot___closed__14);
l_ProofWidgets_Jsx_jsxElement_quot___closed__15 = _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__15();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_quot___closed__15);
l_ProofWidgets_Jsx_jsxElement_quot___closed__16 = _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__16();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_quot___closed__16);
l_ProofWidgets_Jsx_jsxElement_quot___closed__17 = _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__17();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_quot___closed__17);
l_ProofWidgets_Jsx_jsxElement_quot___closed__18 = _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__18();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_quot___closed__18);
l_ProofWidgets_Jsx_jsxElement_quot___closed__19 = _init_l_ProofWidgets_Jsx_jsxElement_quot___closed__19();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_quot___closed__19);
l_ProofWidgets_Jsx_jsxElement_quot = _init_l_ProofWidgets_Jsx_jsxElement_quot();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_quot);
l_Lean_Parser_Category_jsxElement = _init_l_Lean_Parser_Category_jsxElement();
lean_mark_persistent(l_Lean_Parser_Category_jsxElement);
l_ProofWidgets_Jsx_jsxChild_quot___closed__1 = _init_l_ProofWidgets_Jsx_jsxChild_quot___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild_quot___closed__1);
l_ProofWidgets_Jsx_jsxChild_quot___closed__2 = _init_l_ProofWidgets_Jsx_jsxChild_quot___closed__2();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild_quot___closed__2);
l_ProofWidgets_Jsx_jsxChild_quot___closed__3 = _init_l_ProofWidgets_Jsx_jsxChild_quot___closed__3();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild_quot___closed__3);
l_ProofWidgets_Jsx_jsxChild_quot___closed__4 = _init_l_ProofWidgets_Jsx_jsxChild_quot___closed__4();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild_quot___closed__4);
l_ProofWidgets_Jsx_jsxChild_quot___closed__5 = _init_l_ProofWidgets_Jsx_jsxChild_quot___closed__5();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild_quot___closed__5);
l_ProofWidgets_Jsx_jsxChild_quot___closed__6 = _init_l_ProofWidgets_Jsx_jsxChild_quot___closed__6();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild_quot___closed__6);
l_ProofWidgets_Jsx_jsxChild_quot___closed__7 = _init_l_ProofWidgets_Jsx_jsxChild_quot___closed__7();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild_quot___closed__7);
l_ProofWidgets_Jsx_jsxChild_quot___closed__8 = _init_l_ProofWidgets_Jsx_jsxChild_quot___closed__8();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild_quot___closed__8);
l_ProofWidgets_Jsx_jsxChild_quot___closed__9 = _init_l_ProofWidgets_Jsx_jsxChild_quot___closed__9();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild_quot___closed__9);
l_ProofWidgets_Jsx_jsxChild_quot___closed__10 = _init_l_ProofWidgets_Jsx_jsxChild_quot___closed__10();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild_quot___closed__10);
l_ProofWidgets_Jsx_jsxChild_quot = _init_l_ProofWidgets_Jsx_jsxChild_quot();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild_quot);
l_Lean_Parser_Category_jsxChild = _init_l_Lean_Parser_Category_jsxChild();
lean_mark_persistent(l_Lean_Parser_Category_jsxChild);
l_ProofWidgets_Jsx_jsxAttr_quot___closed__1 = _init_l_ProofWidgets_Jsx_jsxAttr_quot___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr_quot___closed__1);
l_ProofWidgets_Jsx_jsxAttr_quot___closed__2 = _init_l_ProofWidgets_Jsx_jsxAttr_quot___closed__2();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr_quot___closed__2);
l_ProofWidgets_Jsx_jsxAttr_quot___closed__3 = _init_l_ProofWidgets_Jsx_jsxAttr_quot___closed__3();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr_quot___closed__3);
l_ProofWidgets_Jsx_jsxAttr_quot___closed__4 = _init_l_ProofWidgets_Jsx_jsxAttr_quot___closed__4();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr_quot___closed__4);
l_ProofWidgets_Jsx_jsxAttr_quot___closed__5 = _init_l_ProofWidgets_Jsx_jsxAttr_quot___closed__5();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr_quot___closed__5);
l_ProofWidgets_Jsx_jsxAttr_quot___closed__6 = _init_l_ProofWidgets_Jsx_jsxAttr_quot___closed__6();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr_quot___closed__6);
l_ProofWidgets_Jsx_jsxAttr_quot___closed__7 = _init_l_ProofWidgets_Jsx_jsxAttr_quot___closed__7();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr_quot___closed__7);
l_ProofWidgets_Jsx_jsxAttr_quot___closed__8 = _init_l_ProofWidgets_Jsx_jsxAttr_quot___closed__8();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr_quot___closed__8);
l_ProofWidgets_Jsx_jsxAttr_quot___closed__9 = _init_l_ProofWidgets_Jsx_jsxAttr_quot___closed__9();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr_quot___closed__9);
l_ProofWidgets_Jsx_jsxAttr_quot___closed__10 = _init_l_ProofWidgets_Jsx_jsxAttr_quot___closed__10();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr_quot___closed__10);
l_ProofWidgets_Jsx_jsxAttr_quot = _init_l_ProofWidgets_Jsx_jsxAttr_quot();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr_quot);
l_Lean_Parser_Category_jsxAttr = _init_l_Lean_Parser_Category_jsxAttr();
lean_mark_persistent(l_Lean_Parser_Category_jsxAttr);
l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__1 = _init_l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__1);
l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__2 = _init_l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__2();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__2);
l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__3 = _init_l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__3();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__3);
l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__4 = _init_l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__4();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__4);
l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__5 = _init_l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__5();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__5);
l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__6 = _init_l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__6();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__6);
l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__7 = _init_l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__7();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__7);
l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__8 = _init_l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__8();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__8);
l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__9 = _init_l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__9();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__9);
l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__10 = _init_l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__10();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_quot___closed__10);
l_ProofWidgets_Jsx_jsxAttrVal_quot = _init_l_ProofWidgets_Jsx_jsxAttrVal_quot();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_quot);
l_Lean_Parser_Category_jsxAttrVal = _init_l_Lean_Parser_Category_jsxAttrVal();
lean_mark_persistent(l_Lean_Parser_Category_jsxAttrVal);
l_ProofWidgets_Jsx_jsxAttrVal_____closed__1 = _init_l_ProofWidgets_Jsx_jsxAttrVal_____closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_____closed__1);
l_ProofWidgets_Jsx_jsxAttrVal_____closed__2 = _init_l_ProofWidgets_Jsx_jsxAttrVal_____closed__2();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_____closed__2);
l_ProofWidgets_Jsx_jsxAttrVal_____closed__3 = _init_l_ProofWidgets_Jsx_jsxAttrVal_____closed__3();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_____closed__3);
l_ProofWidgets_Jsx_jsxAttrVal_____closed__4 = _init_l_ProofWidgets_Jsx_jsxAttrVal_____closed__4();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_____closed__4);
l_ProofWidgets_Jsx_jsxAttrVal_____closed__5 = _init_l_ProofWidgets_Jsx_jsxAttrVal_____closed__5();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_____closed__5);
l_ProofWidgets_Jsx_jsxAttrVal_____closed__6 = _init_l_ProofWidgets_Jsx_jsxAttrVal_____closed__6();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_____closed__6);
l_ProofWidgets_Jsx_jsxAttrVal_____closed__7 = _init_l_ProofWidgets_Jsx_jsxAttrVal_____closed__7();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_____closed__7);
l_ProofWidgets_Jsx_jsxAttrVal_____closed__8 = _init_l_ProofWidgets_Jsx_jsxAttrVal_____closed__8();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_____closed__8);
l_ProofWidgets_Jsx_jsxAttrVal__ = _init_l_ProofWidgets_Jsx_jsxAttrVal__();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal__);
l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__1 = _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__1);
l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2 = _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__2);
l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__3 = _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__3();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__3);
l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4 = _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__4);
l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5 = _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__5);
l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__6 = _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__6();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__6);
l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__7 = _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__7();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__7);
l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__8 = _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__8();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__8);
l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__9 = _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__9();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__9);
l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__10 = _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__10();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__10);
l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11 = _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__11);
l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__12 = _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__12();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__12);
l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__13 = _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__13();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__13);
l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__14 = _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__14();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__14);
l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__15 = _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__15();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d___closed__15);
l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d = _init_l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttrVal_x7b___x7d);
l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__1 = _init_l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__1);
l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2 = _init_l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__2);
l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__3 = _init_l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__3();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__3);
l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__4 = _init_l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__4();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__4);
l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__5 = _init_l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__5();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__5);
l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6 = _init_l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__6);
l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__7 = _init_l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__7();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__7);
l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__8 = _init_l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__8();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__8);
l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__9 = _init_l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__9();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__9);
l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__10 = _init_l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__10();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr___x3d_____closed__10);
l_ProofWidgets_Jsx_jsxAttr___x3d__ = _init_l_ProofWidgets_Jsx_jsxAttr___x3d__();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr___x3d__);
l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__1 = _init_l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__1);
l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__2 = _init_l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__2();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__2);
l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__3 = _init_l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__3();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__3);
l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__4 = _init_l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__4();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__4);
l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__5 = _init_l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__5();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__5);
l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__6 = _init_l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__6();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__6);
l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__7 = _init_l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__7();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__7);
l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__8 = _init_l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__8();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d___closed__8);
l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d = _init_l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxAttr_x7b_x2e_x2e_x2e___x7d);
l_ProofWidgets_Jsx_jsxTextForbidden___closed__1 = _init_l_ProofWidgets_Jsx_jsxTextForbidden___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxTextForbidden___closed__1);
l_ProofWidgets_Jsx_jsxTextForbidden = _init_l_ProofWidgets_Jsx_jsxTextForbidden();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxTextForbidden);
l_ProofWidgets_Jsx_jsxText___lambda__1___closed__1 = _init_l_ProofWidgets_Jsx_jsxText___lambda__1___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxText___lambda__1___closed__1);
l_ProofWidgets_Jsx_jsxText___lambda__1___closed__2 = _init_l_ProofWidgets_Jsx_jsxText___lambda__1___closed__2();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxText___lambda__1___closed__2);
l_ProofWidgets_Jsx_jsxText___lambda__1___closed__3 = _init_l_ProofWidgets_Jsx_jsxText___lambda__1___closed__3();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxText___lambda__1___closed__3);
l_ProofWidgets_Jsx_jsxText___lambda__1___closed__4 = _init_l_ProofWidgets_Jsx_jsxText___lambda__1___closed__4();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxText___lambda__1___closed__4);
l_ProofWidgets_Jsx_jsxText___closed__1 = _init_l_ProofWidgets_Jsx_jsxText___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxText___closed__1);
l_ProofWidgets_Jsx_jsxText___closed__2 = _init_l_ProofWidgets_Jsx_jsxText___closed__2();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxText___closed__2);
l_ProofWidgets_Jsx_jsxText___closed__3 = _init_l_ProofWidgets_Jsx_jsxText___closed__3();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxText___closed__3);
l_ProofWidgets_Jsx_jsxText___closed__4 = _init_l_ProofWidgets_Jsx_jsxText___closed__4();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxText___closed__4);
l_ProofWidgets_Jsx_jsxText___closed__5 = _init_l_ProofWidgets_Jsx_jsxText___closed__5();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxText___closed__5);
l_ProofWidgets_Jsx_jsxText = _init_l_ProofWidgets_Jsx_jsxText();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxText);
l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__1 = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__1);
l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__2 = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__2();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__2);
l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__3 = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__3();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__3);
l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__4 = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__4();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__4);
l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__5 = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__5();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__5);
l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__6 = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__6();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__6);
l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__7 = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__7();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__7);
l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__8 = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__8();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__8);
l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__9 = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__9();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__9);
l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__10 = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__10();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__10);
l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__11 = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__11();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__11);
l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__12 = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__12();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__12);
l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__13 = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__13();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e___closed__13);
l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x2f_x3e);
l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__1 = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__1);
l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__2 = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__2();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__2);
l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__3 = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__3();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__3);
l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__4 = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__4();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__4);
l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__5 = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__5();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__5);
l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__6 = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__6();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__6);
l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__7 = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__7();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__7);
l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__8 = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__8();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__8);
l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__9 = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__9();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__9);
l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__10 = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__10();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__10);
l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__11 = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__11();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__11);
l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__12 = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__12();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__12);
l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__13 = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__13();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e___closed__13);
l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e = _init_l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxElement_x3c_____x3e___x3c_x2f___x3e);
l_ProofWidgets_Jsx_jsxChild_____closed__1 = _init_l_ProofWidgets_Jsx_jsxChild_____closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild_____closed__1);
l_ProofWidgets_Jsx_jsxChild_____closed__2 = _init_l_ProofWidgets_Jsx_jsxChild_____closed__2();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild_____closed__2);
l_ProofWidgets_Jsx_jsxChild_____closed__3 = _init_l_ProofWidgets_Jsx_jsxChild_____closed__3();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild_____closed__3);
l_ProofWidgets_Jsx_jsxChild_____closed__4 = _init_l_ProofWidgets_Jsx_jsxChild_____closed__4();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild_____closed__4);
l_ProofWidgets_Jsx_jsxChild__ = _init_l_ProofWidgets_Jsx_jsxChild__();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild__);
l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__1 = _init_l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__1);
l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__2 = _init_l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__2();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__2);
l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__3 = _init_l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__3();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__3);
l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__4 = _init_l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__4();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__4);
l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__5 = _init_l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__5();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__5);
l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__6 = _init_l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__6();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__6);
l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__7 = _init_l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__7();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d___closed__7);
l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d = _init_l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild_x7b_x2e_x2e_x2e___x7d);
l_ProofWidgets_Jsx_jsxChild_x7b___x7d___closed__1 = _init_l_ProofWidgets_Jsx_jsxChild_x7b___x7d___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild_x7b___x7d___closed__1);
l_ProofWidgets_Jsx_jsxChild_x7b___x7d___closed__2 = _init_l_ProofWidgets_Jsx_jsxChild_x7b___x7d___closed__2();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild_x7b___x7d___closed__2);
l_ProofWidgets_Jsx_jsxChild_x7b___x7d___closed__3 = _init_l_ProofWidgets_Jsx_jsxChild_x7b___x7d___closed__3();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild_x7b___x7d___closed__3);
l_ProofWidgets_Jsx_jsxChild_x7b___x7d = _init_l_ProofWidgets_Jsx_jsxChild_x7b___x7d();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild_x7b___x7d);
l_ProofWidgets_Jsx_jsxChild____1___closed__1 = _init_l_ProofWidgets_Jsx_jsxChild____1___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild____1___closed__1);
l_ProofWidgets_Jsx_jsxChild____1___closed__2 = _init_l_ProofWidgets_Jsx_jsxChild____1___closed__2();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild____1___closed__2);
l_ProofWidgets_Jsx_jsxChild____1___closed__3 = _init_l_ProofWidgets_Jsx_jsxChild____1___closed__3();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild____1___closed__3);
l_ProofWidgets_Jsx_jsxChild____1 = _init_l_ProofWidgets_Jsx_jsxChild____1();
lean_mark_persistent(l_ProofWidgets_Jsx_jsxChild____1);
l_ProofWidgets_Jsx_term_____closed__1 = _init_l_ProofWidgets_Jsx_term_____closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_term_____closed__1);
l_ProofWidgets_Jsx_term_____closed__2 = _init_l_ProofWidgets_Jsx_term_____closed__2();
lean_mark_persistent(l_ProofWidgets_Jsx_term_____closed__2);
l_ProofWidgets_Jsx_term_____closed__3 = _init_l_ProofWidgets_Jsx_term_____closed__3();
lean_mark_persistent(l_ProofWidgets_Jsx_term_____closed__3);
l_ProofWidgets_Jsx_term__ = _init_l_ProofWidgets_Jsx_term__();
lean_mark_persistent(l_ProofWidgets_Jsx_term__);
l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__1 = _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__1();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__1);
l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__2 = _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__2();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__2);
l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__3 = _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__3();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__3);
l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__4 = _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__4();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__4);
l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__5 = _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__5();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__5);
l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6 = _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__6);
l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__7 = _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__7();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__7);
l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__8 = _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__8();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__8);
l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__9 = _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__9();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__9);
l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__10 = _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__10();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__10);
l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__11 = _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__11();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__11);
l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__12 = _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__12();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__12);
l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__13 = _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__13();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__13);
l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__14 = _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__14();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__14);
l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__15 = _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__15();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__15);
l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__16 = _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__16();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__16);
l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__17 = _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__17();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__17);
l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__18 = _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__18();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__18);
l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__19 = _init_l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__19();
lean_mark_persistent(l_Array_forInUnsafe_loop___at_ProofWidgets_Jsx_transformTag___spec__1___closed__19);
l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__3___closed__1 = _init_l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__3___closed__1();
lean_mark_persistent(l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__3___closed__1);
l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__3___closed__2 = _init_l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__3___closed__2();
lean_mark_persistent(l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__3___closed__2);
l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__3___closed__3 = _init_l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__3___closed__3();
lean_mark_persistent(l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__3___closed__3);
l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__5___closed__1 = _init_l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__5___closed__1();
lean_mark_persistent(l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__5___closed__1);
l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__5___closed__2 = _init_l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__5___closed__2();
lean_mark_persistent(l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__5___closed__2);
l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__5___closed__3 = _init_l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__5___closed__3();
lean_mark_persistent(l_Array_mapMUnsafe_map___at_ProofWidgets_Jsx_transformTag___spec__5___closed__3);
l_ProofWidgets_Util_foldInlsM___at_ProofWidgets_Jsx_transformTag___spec__6___closed__1 = _init_l_ProofWidgets_Util_foldInlsM___at_ProofWidgets_Jsx_transformTag___spec__6___closed__1();
lean_mark_persistent(l_ProofWidgets_Util_foldInlsM___at_ProofWidgets_Jsx_transformTag___spec__6___closed__1);
l_ProofWidgets_Util_foldInlsM___at_ProofWidgets_Jsx_transformTag___spec__6___closed__2 = _init_l_ProofWidgets_Util_foldInlsM___at_ProofWidgets_Jsx_transformTag___spec__6___closed__2();
lean_mark_persistent(l_ProofWidgets_Util_foldInlsM___at_ProofWidgets_Jsx_transformTag___spec__6___closed__2);
l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__1 = _init_l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__1();
lean_mark_persistent(l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__1);
l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__2 = _init_l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__2();
lean_mark_persistent(l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__2);
l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__3 = _init_l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__3();
lean_mark_persistent(l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__3);
l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__4 = _init_l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__4();
lean_mark_persistent(l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__4);
l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__5 = _init_l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__5();
lean_mark_persistent(l_Array_foldlMUnsafe_fold___at_ProofWidgets_Jsx_transformTag___spec__11___closed__5);
l_ProofWidgets_Jsx_transformTag___lambda__2___closed__1 = _init_l_ProofWidgets_Jsx_transformTag___lambda__2___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_transformTag___lambda__2___closed__1);
l_ProofWidgets_Jsx_transformTag___lambda__2___closed__2 = _init_l_ProofWidgets_Jsx_transformTag___lambda__2___closed__2();
lean_mark_persistent(l_ProofWidgets_Jsx_transformTag___lambda__2___closed__2);
l_ProofWidgets_Jsx_transformTag___lambda__2___closed__3 = _init_l_ProofWidgets_Jsx_transformTag___lambda__2___closed__3();
lean_mark_persistent(l_ProofWidgets_Jsx_transformTag___lambda__2___closed__3);
l_ProofWidgets_Jsx_transformTag___lambda__2___closed__4 = _init_l_ProofWidgets_Jsx_transformTag___lambda__2___closed__4();
lean_mark_persistent(l_ProofWidgets_Jsx_transformTag___lambda__2___closed__4);
l_ProofWidgets_Jsx_transformTag___lambda__2___closed__5 = _init_l_ProofWidgets_Jsx_transformTag___lambda__2___closed__5();
lean_mark_persistent(l_ProofWidgets_Jsx_transformTag___lambda__2___closed__5);
l_ProofWidgets_Jsx_transformTag___lambda__2___closed__6 = _init_l_ProofWidgets_Jsx_transformTag___lambda__2___closed__6();
lean_mark_persistent(l_ProofWidgets_Jsx_transformTag___lambda__2___closed__6);
l_ProofWidgets_Jsx_transformTag___lambda__3___closed__1 = _init_l_ProofWidgets_Jsx_transformTag___lambda__3___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_transformTag___lambda__3___closed__1);
l_ProofWidgets_Jsx_transformTag___lambda__3___closed__2 = _init_l_ProofWidgets_Jsx_transformTag___lambda__3___closed__2();
lean_mark_persistent(l_ProofWidgets_Jsx_transformTag___lambda__3___closed__2);
l_ProofWidgets_Jsx_transformTag___lambda__3___closed__3 = _init_l_ProofWidgets_Jsx_transformTag___lambda__3___closed__3();
lean_mark_persistent(l_ProofWidgets_Jsx_transformTag___lambda__3___closed__3);
l_ProofWidgets_Jsx_transformTag___lambda__3___closed__4 = _init_l_ProofWidgets_Jsx_transformTag___lambda__3___closed__4();
lean_mark_persistent(l_ProofWidgets_Jsx_transformTag___lambda__3___closed__4);
l_ProofWidgets_Jsx_transformTag___lambda__3___closed__5 = _init_l_ProofWidgets_Jsx_transformTag___lambda__3___closed__5();
lean_mark_persistent(l_ProofWidgets_Jsx_transformTag___lambda__3___closed__5);
l_ProofWidgets_Jsx_transformTag___lambda__3___closed__6 = _init_l_ProofWidgets_Jsx_transformTag___lambda__3___closed__6();
lean_mark_persistent(l_ProofWidgets_Jsx_transformTag___lambda__3___closed__6);
l_ProofWidgets_Jsx_transformTag___lambda__3___closed__7 = _init_l_ProofWidgets_Jsx_transformTag___lambda__3___closed__7();
lean_mark_persistent(l_ProofWidgets_Jsx_transformTag___lambda__3___closed__7);
l_ProofWidgets_Jsx_transformTag___lambda__3___closed__8 = _init_l_ProofWidgets_Jsx_transformTag___lambda__3___closed__8();
lean_mark_persistent(l_ProofWidgets_Jsx_transformTag___lambda__3___closed__8);
l_ProofWidgets_Jsx_transformTag___lambda__3___closed__9 = _init_l_ProofWidgets_Jsx_transformTag___lambda__3___closed__9();
lean_mark_persistent(l_ProofWidgets_Jsx_transformTag___lambda__3___closed__9);
l_ProofWidgets_Jsx_transformTag___lambda__3___closed__10 = _init_l_ProofWidgets_Jsx_transformTag___lambda__3___closed__10();
lean_mark_persistent(l_ProofWidgets_Jsx_transformTag___lambda__3___closed__10);
l_ProofWidgets_Jsx_transformTag___lambda__3___closed__11 = _init_l_ProofWidgets_Jsx_transformTag___lambda__3___closed__11();
lean_mark_persistent(l_ProofWidgets_Jsx_transformTag___lambda__3___closed__11);
l_ProofWidgets_Jsx_transformTag___lambda__3___closed__12 = _init_l_ProofWidgets_Jsx_transformTag___lambda__3___closed__12();
lean_mark_persistent(l_ProofWidgets_Jsx_transformTag___lambda__3___closed__12);
l_ProofWidgets_Jsx_transformTag___lambda__3___closed__13 = _init_l_ProofWidgets_Jsx_transformTag___lambda__3___closed__13();
lean_mark_persistent(l_ProofWidgets_Jsx_transformTag___lambda__3___closed__13);
l_ProofWidgets_Jsx_transformTag___closed__1 = _init_l_ProofWidgets_Jsx_transformTag___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_transformTag___closed__1);
l_ProofWidgets_Jsx___aux__ProofWidgets__Data__Html______macroRules__ProofWidgets__Jsx__term____1___closed__1 = _init_l_ProofWidgets_Jsx___aux__ProofWidgets__Data__Html______macroRules__ProofWidgets__Jsx__term____1___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx___aux__ProofWidgets__Data__Html______macroRules__ProofWidgets__Jsx__term____1___closed__1);
l_String_anyAux___at_ProofWidgets_Jsx_delabHtmlText___spec__1___closed__1 = _init_l_String_anyAux___at_ProofWidgets_Jsx_delabHtmlText___spec__1___closed__1();
lean_mark_persistent(l_String_anyAux___at_ProofWidgets_Jsx_delabHtmlText___spec__1___closed__1);
l_ProofWidgets_Jsx_delabHtmlText___lambda__1___closed__1 = _init_l_ProofWidgets_Jsx_delabHtmlText___lambda__1___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_delabHtmlText___lambda__1___closed__1);
l_ProofWidgets_Jsx_delabHtmlText___closed__1 = _init_l_ProofWidgets_Jsx_delabHtmlText___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_delabHtmlText___closed__1);
l_ProofWidgets_Jsx_delabHtmlText___closed__2 = _init_l_ProofWidgets_Jsx_delabHtmlText___closed__2();
lean_mark_persistent(l_ProofWidgets_Jsx_delabHtmlText___closed__2);
l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__1___closed__1 = _init_l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__1___closed__1();
lean_mark_persistent(l_Lean_PrettyPrinter_Delaborator_SubExpr_withNaryArg___at_ProofWidgets_Jsx_delabHtmlElement_x27___spec__1___closed__1);
l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__1___closed__1 = _init_l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__1___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__1___closed__1);
l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__2___closed__1 = _init_l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__2___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__2___closed__1);
l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__3___closed__1 = _init_l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__3___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__3___closed__1);
l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__3___closed__2 = _init_l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__3___closed__2();
lean_mark_persistent(l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__3___closed__2);
l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__3___closed__3 = _init_l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__3___closed__3();
lean_mark_persistent(l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__3___closed__3);
l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__3___closed__4 = _init_l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__3___closed__4();
lean_mark_persistent(l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__3___closed__4);
l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__1 = _init_l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__1);
l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__2 = _init_l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__2();
lean_mark_persistent(l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__2);
l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__3 = _init_l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__3();
lean_mark_persistent(l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__3);
l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__4 = _init_l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__4();
lean_mark_persistent(l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__4);
l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__5 = _init_l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__5();
lean_mark_persistent(l_ProofWidgets_Jsx_delabHtmlElement_x27___lambda__6___closed__5);
l_ProofWidgets_Jsx_delabHtmlElement_x27___closed__1 = _init_l_ProofWidgets_Jsx_delabHtmlElement_x27___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_delabHtmlElement_x27___closed__1);
l_ProofWidgets_Jsx_delabJsxChildren___lambda__5___closed__1 = _init_l_ProofWidgets_Jsx_delabJsxChildren___lambda__5___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_delabJsxChildren___lambda__5___closed__1);
l_ProofWidgets_Jsx_delabJsxChildren___lambda__5___closed__2 = _init_l_ProofWidgets_Jsx_delabJsxChildren___lambda__5___closed__2();
lean_mark_persistent(l_ProofWidgets_Jsx_delabJsxChildren___lambda__5___closed__2);
l_ProofWidgets_Jsx_delabJsxChildren___lambda__5___closed__3 = _init_l_ProofWidgets_Jsx_delabJsxChildren___lambda__5___closed__3();
lean_mark_persistent(l_ProofWidgets_Jsx_delabJsxChildren___lambda__5___closed__3);
l_ProofWidgets_Jsx_delabJsxChildren___lambda__5___closed__4 = _init_l_ProofWidgets_Jsx_delabJsxChildren___lambda__5___closed__4();
lean_mark_persistent(l_ProofWidgets_Jsx_delabJsxChildren___lambda__5___closed__4);
l_ProofWidgets_Jsx_delabJsxChildren___closed__1 = _init_l_ProofWidgets_Jsx_delabJsxChildren___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_delabJsxChildren___closed__1);
l_ProofWidgets_Jsx_delabJsxChildren___closed__2 = _init_l_ProofWidgets_Jsx_delabJsxChildren___closed__2();
lean_mark_persistent(l_ProofWidgets_Jsx_delabJsxChildren___closed__2);
l_ProofWidgets_Jsx_delabJsxChildren___closed__3 = _init_l_ProofWidgets_Jsx_delabJsxChildren___closed__3();
lean_mark_persistent(l_ProofWidgets_Jsx_delabJsxChildren___closed__3);
l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__3___closed__1 = _init_l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__3___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__3___closed__1);
l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__3___closed__2 = _init_l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__3___closed__2();
lean_mark_persistent(l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__3___closed__2);
l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__3___closed__3 = _init_l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__3___closed__3();
lean_mark_persistent(l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___lambda__3___closed__3);
l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___closed__1 = _init_l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___closed__1();
lean_mark_persistent(l_ProofWidgets_Jsx_delabHtmlOfComponent_x27___closed__1);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
